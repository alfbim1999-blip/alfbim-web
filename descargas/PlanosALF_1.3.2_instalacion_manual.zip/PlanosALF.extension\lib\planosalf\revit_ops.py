# -*- coding: utf-8 -*-
"""Operaciones de PlanosALF sobre el modelo de Revit (API de Revit 2023-2027)."""
from __future__ import print_function, division

import copy
import os
import re

import clr  # noqa: F401
from Autodesk.Revit import DB
from System.Collections.Generic import List

from planosalf import acomodo, alf_salidas, core, dwg_imagenes, xlsx

try:  # cuadros de carga (tablas de tableros eléctricos)
    from Autodesk.Revit.DB.Electrical import PanelScheduleView, PanelScheduleSheetInstance
except Exception:  # pragma: no cover
    PanelScheduleView = PanelScheduleSheetInstance = None

_u = xlsx._u


# ============================================================================ utilidades

def eid_int(eid):
    """Valor numérico de un ElementId (Value en 2024+, IntegerValue antes)."""
    try:
        return int(eid.Value)
    except AttributeError:
        return int(eid.IntegerValue)


def nombre_de(el):
    try:
        return _u(el.Name)
    except Exception:
        pass
    try:
        return _u(DB.Element.Name.GetValue(el))
    except Exception:
        pass
    p = el.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
    return _u(p.AsString()) if p else u''


def bip(nombre):
    """BuiltInParameter por nombre (None si no existe en esta versión de Revit)."""
    return getattr(DB.BuiltInParameter, nombre, None)


def texto_param(p):
    if p is None or not p.HasValue:
        return u''
    try:
        if p.StorageType == DB.StorageType.String:
            return _u(p.AsString() or u'')
        return _u(p.AsValueString() or u'')
    except Exception:
        return u''


def es_si_no(p):
    try:
        return p.Definition.GetDataType() == DB.SpecTypeId.Boolean.YesNo
    except Exception:
        try:
            return p.Definition.ParameterType == DB.ParameterType.YesNo
        except Exception:
            return False


_SI = set([u'si', u'yes', u'1', u'x', u'true', u'verdadero', u's'])
_NO = set([u'no', u'0', u'false', u'falso', u'n', u''])


def escribir_param(p, texto):
    """Escribe un texto en el parámetro. Devuelve None si se escribió o el motivo del fallo."""
    if p is None:
        return u'no existe'
    if p.IsReadOnly:
        return u'es de solo lectura'
    borrar = core.normalizar(texto) == core.normalizar(core.CLAVE_BORRAR)
    st = p.StorageType
    try:
        if st == DB.StorageType.String:
            p.Set(u'' if borrar else _u(texto))
            return None
        if borrar:
            return u'no se puede vaciar (no es de texto)'
        if st == DB.StorageType.Integer:
            if es_si_no(p):
                n = core.normalizar(texto)
                if n in _SI:
                    p.Set(1)
                elif n in _NO:
                    p.Set(0)
                else:
                    return u'debe ser Sí o No'
                return None
            p.Set(int(round(float(_u(texto).replace(u',', u'.')))))
            return None
        if st == DB.StorageType.Double:
            if p.SetValueString(_u(texto)):
                return None
            p.Set(float(_u(texto).replace(u',', u'.')))
            return None
        return u'tipo de parámetro no admitido (elemento)'
    except Exception as ex:
        return u'valor no válido (%s)' % _u(ex)


def mismo_valor(p, texto):
    if core.normalizar(texto) == core.normalizar(core.CLAVE_BORRAR):
        return texto_param(p) == u''
    actual = texto_param(p)
    if actual == _u(texto):
        return True
    if p is not None and p.StorageType == DB.StorageType.Integer and es_si_no(p):
        n = core.normalizar(texto)
        return (p.AsInteger() == 1 and n in _SI) or (p.AsInteger() == 0 and n in _NO and n)
    if p is not None and p.StorageType != DB.StorageType.String:
        try:
            return abs(float(actual.replace(u',', u'.')) - float(_u(texto).replace(u',', u'.'))) < 1e-9
        except ValueError:
            return False
    return False


def buscar_param(el, nombre):
    """Parámetro por nombre exacto y luego sin tildes ni mayúsculas."""
    if el is None:
        return None
    p = el.LookupParameter(nombre)
    if p is not None:
        return p
    n = core.normalizar(nombre)
    for q in el.Parameters:
        try:
            if core.normalizar(q.Definition.Name) == n:
                return q
        except Exception:
            continue
    return None


ALIAS_LAMINA = core.ALIAS_LAMINA
ALIAS_PROYECTO = core.ALIAS_PROYECTO


def _por_alias(el, nombre, tabla):
    n = core.normalizar(nombre)
    for bname, alias in tabla:
        if n in alias:
            b = bip(bname)
            if b is not None:
                p = el.get_Parameter(b)
                if p is not None:
                    return p
    return None


def param_de_lamina(doc, lamina, rotulo, nombre):
    """Dónde se escribe una columna: lámina, rótulo de la lámina o Información del proyecto.

    Devuelve (parámetro, lugar) o (None, None)."""
    for el, lugar, exacto in ((lamina, u'lámina', True), (rotulo, u'rótulo', True)):
        if el is not None:
            p = el.LookupParameter(nombre)
            if p is not None:
                return p, lugar
    for el, lugar in ((lamina, u'lámina'), (rotulo, u'rótulo')):
        p = buscar_param(el, nombre)
        if p is not None:
            return p, lugar
    p = _por_alias(lamina, nombre, ALIAS_LAMINA)
    if p is not None:
        return p, u'lámina'
    info = doc.ProjectInformation
    p = buscar_param(info, nombre) or _por_alias(info, nombre, ALIAS_PROYECTO)
    if p is not None:
        return p, u'proyecto'
    return None, None


def param_de_proyecto(doc, nombre):
    info = doc.ProjectInformation
    return buscar_param(info, nombre) or _por_alias(info, nombre, ALIAS_PROYECTO)


class SilenciarAvisos(DB.IFailuresPreprocessor):
    """Quita los avisos (no los errores) para que no aparezcan cientos de ventanas al crear láminas."""

    def PreprocessFailures(self, accesor):
        try:
            for f in accesor.GetFailureMessages():
                if f.GetSeverity() == DB.FailureSeverity.Warning:
                    accesor.DeleteWarning(f)
        except Exception:
            pass
        return DB.FailureProcessingResult.Continue


def transaccion(doc, nombre):
    t = DB.Transaction(doc, nombre)
    opciones = t.GetFailureHandlingOptions()
    opciones.SetFailuresPreprocessor(SilenciarAvisos())
    t.SetFailureHandlingOptions(opciones)
    return t


# ============================================================================ consultas del modelo

def laminas(doc, incluir_marcadores=True):
    res = []
    for s in DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet):
        if s.IsTemplate:
            continue
        if s.IsPlaceholder and not incluir_marcadores:
            continue
        res.append(s)
    res.sort(key=lambda s: core.clave_natural(s.SheetNumber))
    return res


def rotulo_de(doc, lamina):
    for tb in DB.FilteredElementCollector(doc, lamina.Id).OfCategory(DB.BuiltInCategory.OST_TitleBlocks) \
            .WhereElementIsNotElementType():
        return tb
    return None


def texto_rotulo(simbolo):
    try:
        familia = _u(simbolo.FamilyName)
    except Exception:
        familia = _u(simbolo.Family.Name) if simbolo.Family else u''
    return u'%s : %s' % (familia, nombre_de(simbolo))


def rotulos(doc):
    """[(texto 'Familia : Tipo', FamilySymbol)] ordenados."""
    res = []
    for s in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks) \
            .WhereElementIsElementType():
        res.append((texto_rotulo(s), s))
    res.sort(key=lambda x: core.clave_natural(x[0]))
    return res


def buscar_rotulo(lista, texto):
    """Busca 'Familia : Tipo', solo 'Tipo' o solo 'Familia' (si es única). Devuelve (símbolo, error)."""
    texto = _u(texto).strip()
    if not texto:
        return None, u''
    n = core.normalizar(texto)
    for t, s in lista:
        if core.normalizar(t) == n:
            return s, u''
    candidatos = []
    for t, s in lista:
        fam, _, tipo = t.partition(u' : ')
        if core.normalizar(tipo) == n or core.normalizar(fam) == n:
            candidatos.append((t, s))
    if len(candidatos) == 1:
        return candidatos[0][1], u''
    if len(candidatos) > 1:
        return None, u'Rótulo «%s» ambiguo: escriba «Familia : Tipo» (%s)' % (texto, u'; '.join(t for t, _ in candidatos[:4]))
    return None, u'No existe el rótulo «%s» en el modelo (cárguelo o revise la hoja MODELO)' % texto


_TIPOS_COLOCABLES = None


def _tipos_colocables():
    global _TIPOS_COLOCABLES
    if _TIPOS_COLOCABLES is None:
        nombres = [u'FloorPlan', u'CeilingPlan', u'Elevation', u'ThreeD', u'Schedule', u'DraftingView', u'Section',
                   u'Detail', u'Legend', u'EngineeringPlan', u'AreaPlan', u'Rendering', u'Walkthrough',
                   u'ColumnSchedule', u'PanelSchedule', u'CostReport', u'LoadsReport', u'PresureLossReport']
        _TIPOS_COLOCABLES = set(getattr(DB.ViewType, n) for n in nombres if hasattr(DB.ViewType, n))
    return _TIPOS_COLOCABLES


def nombre_tipo_vista(doc, vista):
    try:
        t = doc.GetElement(vista.GetTypeId())
        if t is not None:
            return nombre_de(t)
    except Exception:
        pass
    return _u(str(vista.ViewType))


def es_tabla(vista):
    return isinstance(vista, DB.ViewSchedule)


def es_cuadro(vista):
    return PanelScheduleView is not None and isinstance(vista, PanelScheduleView)


def vista_multiple(vista):
    """Tablas, cuadros de carga y leyendas pueden estar en varias láminas."""
    return es_tabla(vista) or es_cuadro(vista) or vista.ViewType == DB.ViewType.Legend


def tabla_colocable(vista):
    if not es_tabla(vista):
        return False
    for attr in (u'IsTitleblockRevisionSchedule', u'IsInternalKeynoteSchedule'):
        try:
            if getattr(vista, attr):
                return False
        except Exception:
            pass
    return True


def vistas_colocables(doc):
    """Vistas, tablas y leyendas que se pueden poner en una lámina: [(vista, nombre_tipo)]."""
    tipos = _tipos_colocables()
    res = []
    for v in DB.FilteredElementCollector(doc).OfClass(DB.View):
        try:
            if v.IsTemplate or isinstance(v, DB.ViewSheet):
                continue
            if v.ViewType not in tipos:
                continue
            if es_tabla(v) and not tabla_colocable(v):
                continue
            if v.ViewType == DB.ViewType.ThreeD and getattr(v, 'IsAssemblyView', False):
                continue
        except Exception:
            continue
        res.append((v, nombre_tipo_vista(doc, v)))
    res.sort(key=lambda x: core.clave_natural(x[0].Name))
    return res


def vistas_en_laminas(doc):
    """ViewId (int) -> número de la lámina donde ya está (solo vistas de una sola ubicación)."""
    res = {}
    for vp in DB.FilteredElementCollector(doc).OfClass(DB.Viewport):
        s = doc.GetElement(vp.SheetId)
        if s is not None:
            res[eid_int(vp.ViewId)] = _u(s.SheetNumber)
    return res


def buscar_vista(colocables, texto):
    """'Nivel 1' o 'Nivel 1 [Plano de techo]'. Devuelve (vista, error)."""
    texto = _u(texto).strip()
    tipo = u''
    if texto.endswith(u']') and u'[' in texto:
        texto, _, tipo = texto[:-1].rpartition(u'[')
        texto = texto.strip()
    n = core.normalizar(texto)
    exactos = [(v, t) for v, t in colocables if _u(v.Name) == texto]
    candidatos = exactos or [(v, t) for v, t in colocables if core.normalizar(v.Name) == n]
    if tipo:
        candidatos = [(v, t) for v, t in candidatos if core.normalizar(t) == core.normalizar(tipo)]
    pedida = texto + (u' [%s]' % tipo if tipo else u'')
    if len(candidatos) == 1:
        return candidatos[0][0], u''
    if not candidatos:
        # etapa 5C: los niveles (y sus vistas) se renombraron: '(a) NFZ' → '00 NFZ Fondo de zapatas'
        lista = [(v, t) for v, t in colocables if not tipo or core.normalizar(t) == core.normalizar(tipo)]
        por_nivel = [lista[i] for i in core.vistas_por_nivel(texto, [_u(v.Name) for v, _ in lista])]
        if len(por_nivel) == 1:
            v = por_nivel[0][0]
            return v, u'No se encontró la vista «%s»: se usó «%s» (mismo nivel, nombre nuevo)' % (pedida, _u(v.Name))
        if por_nivel:
            return None, (u'No se encontró la vista «%s»; por su nivel hay %d: %s (escriba cuál en el Excel)'
                          % (pedida, len(por_nivel), u', '.join(u'«%s [%s]»' % (_u(v.Name), t) for v, t in por_nivel)))
        return None, u'No se encontró la vista «%s»' % pedida
    return None, (u'Hay %d vistas «%s»: escriba también el tipo, p. ej. «%s [%s]»'
                  % (len(candidatos), texto, texto, candidatos[0][1]))


def puede_colocar(doc, lamina_id, vista):
    if es_tabla(vista):
        return tabla_colocable(vista)
    if es_cuadro(vista) or vista.ViewType == DB.ViewType.Legend:
        return True
    try:
        return DB.Viewport.CanAddViewToSheet(doc, lamina_id, vista.Id)
    except Exception:
        return False


# ============================================================================ datos para Excel e índice

def info_proyecto(doc, solo_con_valor=False):
    """[(nombre, valor)] de la Información del proyecto (parámetros de texto editables)."""
    info = doc.ProjectInformation
    res = []
    vistos = set()
    preferidos = [b for b, _ in ALIAS_PROYECTO]
    for bname in preferidos:
        b = bip(bname)
        p = info.get_Parameter(b) if b is not None else None
        if p is not None and not p.IsReadOnly:
            nombre = _u(p.Definition.Name)
            vistos.add(core.normalizar(nombre))
            valor = texto_param(p)
            if valor or not solo_con_valor:
                res.append((nombre, valor, bname))
    otros = []
    for p in info.Parameters:
        try:
            if p.IsReadOnly or p.StorageType != DB.StorageType.String:
                continue
            nombre = _u(p.Definition.Name)
        except Exception:
            continue
        if core.normalizar(nombre) in vistos:
            continue
        if eid_int(p.Id) < 0:
            continue  # otros incorporados (p. ej. «Nombre del edificio» ya está arriba)
        vistos.add(core.normalizar(nombre))
        otros.append((nombre, texto_param(p), u''))
    otros.sort(key=lambda x: core.clave_natural(x[0]))
    return res + [o for o in otros if o[1] or not solo_con_valor]


COLUMNAS_INCORPORADAS = [
    (u'Dibujado por', u'SHEET_DRAWN_BY'),
    (u'Revisado por', u'SHEET_CHECKED_BY'),
    (u'Diseñado por', u'SHEET_DESIGNED_BY'),
    (u'Aprobado por', u'SHEET_APPROVED_BY'),
    (u'Fecha de emisión', u'SHEET_ISSUE_DATE'),
]


def _params_propios(el):
    """Parámetros editables de texto/número que NO son incorporados (compartidos o de proyecto/familia)."""
    res = []
    if el is None:
        return res
    for p in el.Parameters:
        try:
            if p.IsReadOnly or eid_int(p.Id) < 0:
                continue
            if p.StorageType == DB.StorageType.ElementId:
                continue
            res.append(p)
        except Exception:
            continue
    return res


def datos_laminas(doc, especialidades):
    """Láminas del modelo como dicts para el Excel (incluye parámetros propios de la lámina y del rótulo)."""
    hojas = [s for s in laminas(doc) if not s.IsPlaceholder]
    extra = []
    vistos = set(core.normalizar(c) for c, _ in COLUMNAS_INCORPORADAS)
    info_n = set(core.normalizar(x[0]) for x in info_proyecto(doc))
    datos = []
    en_lamina = {}
    for vp in DB.FilteredElementCollector(doc).OfClass(DB.Viewport):
        en_lamina.setdefault(eid_int(vp.SheetId), []).append(vp)
    # nombres de vista repetidos (p. ej. «Nivel 1» en planta y en techo): se escriben con su tipo
    conteo = {}
    for v, t in vistas_colocables(doc):
        n = core.normalizar(v.Name)
        conteo[n] = conteo.get(n, 0) + 1
    for s in hojas:
        tb = rotulo_de(doc, s)
        params = {}
        for col, bname in COLUMNAS_INCORPORADAS:
            b = bip(bname)
            p = s.get_Parameter(b) if b is not None else None
            params[col] = texto_param(p)
        for el in (s, tb):
            for p in _params_propios(el):
                nombre = _u(p.Definition.Name)
                n = core.normalizar(nombre)
                if n in info_n:
                    continue  # parámetros del proyecto: van en la hoja PROYECTO
                if n not in vistos:
                    vistos.add(n)
                    extra.append(nombre)
                if nombre not in params or not params[nombre]:
                    params[nombre] = texto_param(p)
        vistas = []
        for vp in sorted(en_lamina.get(eid_int(s.Id), []), key=lambda v: eid_int(v.Id)):
            v = doc.GetElement(vp.ViewId)
            if v is not None:
                if conteo.get(core.normalizar(v.Name), 0) > 1:
                    vistas.append(u'%s [%s]' % (_u(v.Name), nombre_tipo_vista(doc, v)))
                else:
                    vistas.append(_u(v.Name))
        datos.append(dict(especialidad=especialidades.de_numero(s.SheetNumber), numero=_u(s.SheetNumber),
                          nombre=_u(s.Name), rotulo=texto_rotulo(doc.GetElement(tb.GetTypeId())) if tb else u'',
                          vistas=u'; '.join(vistas), uid=_u(s.UniqueId), parametros=params))
    return datos, extra


def nombre_modelo(doc):
    """«V16_ARQ» (nombre del archivo del modelo, sin carpeta) o el título del documento."""
    n = alf_salidas.nombre_desde_archivo(ruta_modelo(doc))
    if not n:
        try:
            n = os.path.splitext(_u(doc.Title))[0]
        except Exception:
            n = u''
    return n


def datos_indice(doc, hojas, origen=None):
    res = []
    if origen is None:
        origen = nombre_modelo(doc)
    for s in hojas:
        b1 = bip(u'SHEET_CURRENT_REVISION')
        b2 = bip(u'SHEET_CURRENT_REVISION_DATE')
        res.append(dict(numero=_u(s.SheetNumber), nombre=_u(s.Name), uid=_u(s.UniqueId), origen=origen,
                        revision=texto_param(s.get_Parameter(b1)) if b1 is not None else u'',
                        fecha_revision=texto_param(s.get_Parameter(b2)) if b2 is not None else u''))
    return res


def laminas_del_indice(doc):
    """Láminas que van en el índice (las que tienen «Aparece en la lista de planos»)."""
    hojas = []
    b = bip(u'SHEET_SCHEDULED')
    for s in laminas(doc, incluir_marcadores=True):
        p = s.get_Parameter(b) if b is not None else None
        if p is not None and p.AsInteger() == 0:
            continue  # «Aparece en la lista de planos» desactivado
        hojas.append(s)
    return hojas


def documentos_vinculados(doc, raiz_proyecto=None):
    """Modelos de Revit vinculados y cargados que son del MISMO proyecto (su ficha es la misma o están dentro de la
    carpeta del proyecto): [(documento, nombre del modelo)]. Así el índice de la IIEE suma las láminas de la ARQ."""
    res = []
    vistos = set()
    try:
        instancias = list(DB.FilteredElementCollector(doc).OfClass(DB.RevitLinkInstance))
    except Exception:
        instancias = []
    for inst in instancias:
        try:
            ld = inst.GetLinkDocument()
        except Exception:
            ld = None
        if ld is None:
            continue
        ruta = ruta_modelo(ld)
        clave = core.clave_proyecto(ruta) if ruta else _u(ld.Title)
        if clave in vistos:
            continue
        vistos.add(clave)
        mismo = False
        if raiz_proyecto and ruta:
            mismo = alf_salidas.dentro_de(os.path.dirname(ruta), raiz_proyecto)
            if not mismo:
                f = alf_salidas.buscar(ruta)
                mismo = bool(f) and alf_salidas.dentro_de(os.path.dirname(f), raiz_proyecto)
        if mismo:
            res.append((ld, nombre_modelo(ld)))
    return res


def info_para_indice(doc, ficha=None):
    """Datos del proyecto para el índice, los nombres y el rótulo: primero la ficha «.alfproyecto», luego la
    Información del proyecto y al final el nombre del archivo del modelo. Nunca textos de ejemplo."""
    info = doc.ProjectInformation

    def val(bname):
        b = bip(bname)
        p = info.get_Parameter(b) if b is not None else None
        if p is None:
            return u''
        texto = texto_param(p)
        # Revit llena la Información del proyecto con el nombre del parámetro («Número de proyecto»): no sirve
        try:
            if core.normalizar(texto) == core.normalizar(p.Definition.Name):
                return u''
        except Exception:
            pass
        return u'' if alf_salidas.es_texto_de_ejemplo(texto) else texto

    if ficha is None:
        ficha = ficha_de(doc)

    def primero(*valores):
        for v in valores:
            v = _u(v).strip()
            if v and not alf_salidas.es_texto_de_ejemplo(v):
                return v
        return u''

    archivo = ruta_modelo(doc)
    return dict(proyecto=primero(ficha.nombre, val(u'PROJECT_NAME'), alf_salidas.nombre_desde_archivo(archivo)),
                numero=primero(ficha.codigo, ficha.cui, val(u'PROJECT_NUMBER')),
                cliente=primero(ficha.entidad, val(u'CLIENT_NAME')),
                direccion=primero(ficha.ubicacion_texto(), val(u'PROJECT_ADDRESS')),
                proyectista=primero(ficha.proyectista_texto(), val(u'PROJECT_AUTHOR')),
                organizacion=primero(ficha.organizacion, val(u'PROJECT_ORGANIZATION_NAME')))


# ============================================================================ ficha del proyecto (.alfproyecto)

GUID_FICHA = u'6c1f3d7e-2b8a-4c55-9a0e-a1f0b1e20b16'   # el mismo esquema que AlfCore.Revit.FichaRevit (C#)


def ruta_modelo(doc):
    """Ruta del modelo (la del central si es colaborativo); «» si no está guardado."""
    try:
        if doc.IsWorkshared and not doc.IsDetached:
            return _u(DB.ModelPathUtils.ConvertModelPathToUserVisiblePath(doc.GetWorksharingCentralModelPath()))
    except Exception:
        pass
    try:
        return _u(doc.PathName)
    except Exception:
        return u''


def ficha_guardada(doc):
    """La ficha que un complemento ALF_BIM (C#) guardó dentro del modelo, o None."""
    try:
        import System
        from Autodesk.Revit.DB.ExtensibleStorage import Schema
        sch = Schema.Lookup(System.Guid(GUID_FICHA))
        if sch is None:
            return None
        ent = doc.ProjectInformation.GetEntity(sch)
        if ent is None or not ent.IsValid():
            return None
        import json
        texto = ent.Get[System.String](u'json')
        return alf_salidas.Ficha.desde_dict(json.loads(_u(texto)))
    except Exception:
        return None


def ficha_desde_informacion(doc):
    """Ficha con los datos de la Información del proyecto (sin textos de ejemplo)."""
    info = doc.ProjectInformation

    def val(bname):
        b = bip(bname)
        p = info.get_Parameter(b) if b is not None else None
        t = texto_param(p).strip() if p is not None else u''
        return u'' if alf_salidas.es_texto_de_ejemplo(t) else t

    f = alf_salidas.Ficha(nombre=val(u'PROJECT_NAME'), codigo=val(u'PROJECT_NUMBER'), entidad=val(u'CLIENT_NAME'),
                          proyectista=val(u'PROJECT_AUTHOR').split(u'·')[0].strip(),
                          organizacion=val(u'PROJECT_ORGANIZATION_NAME'))
    if not f.nombre:
        f.nombre = alf_salidas.nombre_desde_archivo(ruta_modelo(doc))
    fecha = val(u'PROJECT_ISSUE_DATE')
    m = re.match(u'^(\\d{4})-(\\d{2})-(\\d{2})$', fecha) or re.match(u'^(\\d{1,2})[/.-](\\d{1,2})[/.-](\\d{4})$', fecha)
    if m:
        g = m.groups()
        f.fecha = u'%s-%s-%s' % (g[0], g[1], g[2]) if len(g[0]) == 4 else u'%s-%02d-%02d' % (g[2], int(g[1]), int(g[0]))
    return f


def ficha_de(doc):
    """La ficha del modelo: la «.alfproyecto» más cercana; si no hay, la guardada en el modelo; si no, la que sale
    de la Información del proyecto."""
    ruta = ruta_modelo(doc)
    f = alf_salidas.buscar_y_leer(ruta) if ruta else None
    return f or ficha_guardada(doc) or ficha_desde_informacion(doc)


def escribir_ficha(doc, f):
    """Escribe la ficha en la Información del proyecto (la leen los rótulos). Devuelve los avisos."""
    pares = [(u'PROJECT_NAME', f.nombre_o(ruta_modelo(doc))),
             (u'PROJECT_NUMBER', f.codigo.strip() or f.cui.strip()),
             (u'CLIENT_NAME', f.entidad),
             (u'PROJECT_ADDRESS', f.ubicacion_texto()),
             (u'PROJECT_AUTHOR', f.proyectista_texto()),
             (u'PROJECT_ORGANIZATION_NAME', f.organizacion),
             (u'PROJECT_ISSUE_DATE', f.fecha)]
    avisos = []
    info = doc.ProjectInformation
    t = transaccion(doc, u'PlanosALF: ficha del proyecto')
    t.Start()
    try:
        for bname, valor in pares:
            valor = _u(valor).strip()
            b = bip(bname)
            p = info.get_Parameter(b) if b is not None else None
            if p is None or p.IsReadOnly:
                continue
            actual = texto_param(p)
            # nunca deja un texto de ejemplo: si el dato falta y el actual es de ejemplo, lo vacía
            if not valor and not alf_salidas.es_texto_de_ejemplo(actual):
                continue
            if actual != valor:
                err = escribir_param(p, valor)
                if err:
                    avisos.append(u'%s: %s' % (_u(p.Definition.Name), err))
        _confirmar(t, u'ficha del proyecto')
    except Exception:
        _deshacer(t)
        raise
    return avisos


# vistas cuyo CAD importado es el CONTENIDO (detalles traídos de AutoCAD, leyendas): ahí no se oculta
_TIPOS_SIN_OCULTAR = None


def _tipos_sin_ocultar():
    global _TIPOS_SIN_OCULTAR
    if _TIPOS_SIN_OCULTAR is None:
        nombres = [u'DraftingView', u'Legend', u'Schedule', u'PanelSchedule', u'ColumnSchedule', u'DrawingSheet',
                   u'Report', u'CostReport', u'LoadsReport', u'PresureLossReport']
        _TIPOS_SIN_OCULTAR = set(getattr(DB.ViewType, n) for n in nombres if hasattr(DB.ViewType, n))
    return _TIPOS_SIN_OCULTAR


def importaciones_cad(doc, lamina):
    """Lo que hay que ocultar para que el CAD de referencia no salga en la exportación de la lámina.

    Solo en las vistas de modelo colocadas (plantas, cortes, elevaciones, 3D); no en la lámina ni en vistas de
    dibujo o leyendas, donde un DWG importado suele ser el propio detalle.
    Devuelve [(vista, [ids de ImportInstance visibles], ocultar_categorias_importadas)]: lo segundo cubre también
    los CAD que vienen dentro de un modelo de Revit vinculado (p. ej. el plano de la ARQ debajo de la IIEE)."""
    res = []
    vistas = []
    try:
        for vid in lamina.GetAllPlacedViews():
            v = doc.GetElement(vid)
            if v is not None and not v.IsTemplate and v.ViewType not in _tipos_sin_ocultar():
                vistas.append(v)
    except Exception:
        pass
    for v in vistas:
        ids = List[DB.ElementId]()
        try:
            for imp in DB.FilteredElementCollector(doc, v.Id).OfClass(DB.ImportInstance):
                try:
                    if not imp.IsHidden(v) and imp.CanBeHidden(v):
                        ids.Add(imp.Id)
                except Exception:
                    continue
        except Exception:
            pass
        categorias = False
        try:
            categorias = not v.AreImportCategoriesHidden
        except Exception:
            categorias = False
        if ids.Count or categorias:
            res.append((v, ids, categorias))
    return res


class _RegistroCad(object):
    """Lo que se tocó para exportar sin CAD (para dejarlo como estaba)."""

    def __init__(self):
        self.ocultos = []        # [(vista, ids)]
        self.categorias = []     # [vista o plantilla de vista] a las que se les ocultó «Categorías importadas»
        self.creados = []        # imágenes de prueba (pedidos de desarrollo) que hay que borrar al terminar
        self.n_cad = 0
        self.n_vistas = 0
        self.n_logos = 0


def _ocultar_cad(doc, pares, registro):
    plantillas = set()
    for v, ids, categorias in pares:
        tocada = False
        if ids.Count:
            try:
                v.HideElements(ids)
                registro.ocultos.append((v, ids))
                registro.n_cad += ids.Count
                tocada = True
            except Exception:
                pass
        if categorias:
            try:
                v.AreImportCategoriesHidden = True
                registro.categorias.append(v)
                tocada = True
            except Exception:
                # la controla su plantilla de vista: se cambia la plantilla (y se deja como estaba al terminar)
                try:
                    tpl = doc.GetElement(v.ViewTemplateId)
                    if tpl is not None and eid_int(tpl.Id) not in plantillas and not tpl.AreImportCategoriesHidden:
                        tpl.AreImportCategoriesHidden = True
                        plantillas.add(eid_int(tpl.Id))
                        registro.categorias.append(tpl)
                        tocada = True
                except Exception:
                    pass
        if tocada:
            registro.n_vistas += 1


def _restaurar_cad(doc, registro):
    """Deshace a mano lo que hizo _ocultar_cad (solo si el grupo de transacciones no se pudo deshacer)."""
    if not registro.ocultos and not registro.categorias and not registro.creados:
        return
    t = transaccion(doc, u'PlanosALF: volver a mostrar el CAD')
    t.Start()
    try:
        for v, ids in registro.ocultos:
            try:
                v.UnhideElements(ids)
            except Exception:
                pass
        for v in registro.categorias:
            try:
                v.AreImportCategoriesHidden = False
            except Exception:
                pass
        for eid in registro.creados:
            try:
                doc.Delete(eid)
            except Exception:
                pass
        t.Commit()
    except Exception:
        _deshacer(t)


def _es_error_de_transaccion(ex):
    texto = (_u(type(ex).__name__) + u' ' + _u(ex)).lower()
    return u'transaction' in texto or u'transacci' in texto


def datos_patron(doc, lamina, especialidades, info=None):
    """Valores para el patrón de nombre de archivo (datos del proyecto: ficha → Información del proyecto)."""
    import datetime
    i = info if info is not None else info_para_indice(doc)
    cod = especialidades.de_numero(lamina.SheetNumber)
    b1 = bip(u'SHEET_CURRENT_REVISION')
    b2 = bip(u'SHEET_CURRENT_REVISION_DATE')
    return {u'Numero': _u(lamina.SheetNumber), u'Nombre': _u(lamina.Name), u'Codigo': cod,
            u'Especialidad': especialidades.nombre(cod),
            u'Revision': texto_param(lamina.get_Parameter(b1)) if b1 is not None else u'',
            u'FechaRevision': texto_param(lamina.get_Parameter(b2)) if b2 is not None else u'',
            u'Proyecto': i[u'proyecto'], u'NumeroProyecto': i[u'numero'], u'Cliente': i[u'cliente'],
            u'Fecha': datetime.date.today().strftime(u'%Y-%m-%d')}


# ============================================================================ importar desde Excel

class Detalle(object):
    """Datos de Revit que se agregan a cada Accion del plan."""

    def __init__(self):
        self.lamina = None
        self.rotulo = None          # FamilySymbol para láminas nuevas
        self.rotulo_texto = u''
        self.params = []            # [(nombre, valor)] a escribir
        self.vistas = []            # [View]
        self.n_cambios_param = 0
        self.rotulo_uniforme = False  # el tamaño lo eligió «Mismo tamaño de lámina por especialidad» (no se cambia)


def detallar(doc, acciones, rotulos_lista, colocables, en_laminas, colocar_vistas=True):
    """Valida rótulos, parámetros y vistas de cada acción; agrega cambios, avisos y errores."""
    por_uid = {}
    for s in laminas(doc):
        por_uid[_u(s.UniqueId)] = s
    # vistas, leyendas y tablas que ya están en cada lámina (para no volver a colocarlas)
    en_cada = {}
    for vp in DB.FilteredElementCollector(doc).OfClass(DB.Viewport):
        en_cada.setdefault(eid_int(vp.SheetId), set()).add(eid_int(vp.ViewId))
    clases = [DB.ScheduleSheetInstance] + ([PanelScheduleSheetInstance] if PanelScheduleSheetInstance else [])
    for clase in clases:
        for si in DB.FilteredElementCollector(doc).OfClass(clase):
            try:
                vid = si.ScheduleId if hasattr(si, 'ScheduleId') else si.GetPanelScheduleView().Id
                en_cada.setdefault(eid_int(si.OwnerViewId), set()).add(eid_int(vid))
            except Exception:
                pass
    vistas_pedidas = {}
    for a in acciones:
        d = Detalle()
        a.detalle = d
        if a.tipo == core.Accion.ERROR:
            continue
        f = a.fila
        if a.uid:
            d.lamina = por_uid.get(a.uid)
        # rótulo
        if f.rotulo:
            sim, err = buscar_rotulo(rotulos_lista, f.rotulo)
            if a.tipo == core.Accion.CREAR:
                if err:
                    a.errores.append(err)
                    a.tipo = core.Accion.ERROR
                    continue
                d.rotulo, d.rotulo_texto = sim, texto_rotulo(sim)
            elif sim is not None and d.lamina is not None:
                tb = rotulo_de(doc, d.lamina)
                if tb is None or eid_int(tb.GetTypeId()) != eid_int(sim.Id):
                    a.avisos.append(u'El rótulo de una lámina existente no se cambia (cámbielo en Revit)')
        # parámetros
        tb = rotulo_de(doc, d.lamina) if d.lamina is not None else None
        for nombre, valor in f.parametros:
            d.params.append((nombre, valor))
            if d.lamina is None:
                continue
            p, lugar = param_de_lamina(doc, d.lamina, tb, nombre)
            if p is None:
                a.avisos.append(u'No existe el parámetro «%s» (en la lámina, su rótulo ni el proyecto)' % nombre)
            elif p.IsReadOnly:
                a.avisos.append(u'«%s» es de solo lectura' % nombre)
            elif not mismo_valor(p, valor):
                d.n_cambios_param += 1
                if lugar == u'proyecto':
                    a.avisos.append(u'«%s» es de la Información del proyecto (afecta a todas las láminas)' % nombre)
                a.cambios.append(u'%s: «%s» → «%s»' % (nombre, texto_param(p), u'' if core.normalizar(valor) ==
                                                        core.normalizar(core.CLAVE_BORRAR) else valor))
        # vistas
        if colocar_vistas:
            for texto in f.vistas:
                v, err = buscar_vista(colocables, texto)
                if err:
                    a.avisos.append(err)      # no encontrada, o encontrada por su nivel con el nombre nuevo
                if v is None:
                    continue
                vid = eid_int(v.Id)
                if d.lamina is not None and vid in en_cada.get(eid_int(d.lamina.Id), set()):
                    continue  # ya está en esta lámina
                multiple = vista_multiple(v)
                if vid in en_laminas and not multiple:
                    if en_laminas[vid] != a.numero_actual or a.tipo == core.Accion.CREAR:
                        a.avisos.append(u'La vista «%s» ya está en la lámina %s' % (v.Name, en_laminas[vid]))
                    continue
                if not multiple and vid in vistas_pedidas:
                    a.avisos.append(u'La vista «%s» ya se pidió en la fila %d' % (v.Name, vistas_pedidas[vid]))
                    continue
                vistas_pedidas[vid] = f.fila
                d.vistas.append(v)
                a.cambios.append(u'Colocar «%s»' % v.Name)
        if a.tipo == core.Accion.SIN_CAMBIOS and (d.n_cambios_param or d.vistas):
            a.tipo = core.Accion.ACTUALIZAR
    return acciones


def _crear_en_lamina(doc, lamina, v):
    """Coloca una vista, tabla o cuadro de tablero en la lámina. Devuelve el elemento colocado."""
    origen = DB.XYZ(0, 0, 0)
    if es_tabla(v):
        return DB.ScheduleSheetInstance.Create(doc, lamina.Id, v.Id, origen)
    if es_cuadro(v):
        return PanelScheduleSheetInstance.Create(doc, v.Id, lamina)
    return DB.Viewport.Create(doc, lamina.Id, v.Id, origen)


def _area_lamina(doc, lamina, franja_pct, margen_pct):
    """(área libre, hueco) de la lámina en pies de papel, según el rótulo colocado."""
    tb = rotulo_de(doc, lamina)
    bb = tb.get_BoundingBox(lamina) if tb is not None else None
    if bb is not None:
        x0, y0, x1, y1 = bb.Min.X, bb.Min.Y, bb.Max.X, bb.Max.Y
    else:  # sin rótulo: A1 horizontal (841 × 594 mm)
        x0, y0, x1, y1 = 0.0, 0.0, 841 / 304.8, 594 / 304.8
    ancho, alto = x1 - x0, y1 - y0
    return core.area_libre(ancho, alto, franja_pct, margen_pct, x0, y0), core.hueco_de(ancho, alto, margen_pct)


def _caja_outline(o):
    try:
        return o.MinimumPoint.X, o.MinimumPoint.Y, o.MaximumPoint.X, o.MaximumPoint.Y
    except Exception:
        return None


def _anotacion_activa(v):
    try:
        p = v.get_Parameter(DB.BuiltInParameter.VIEWER_ANNOTATION_CROP_ACTIVE)
        return p is not None and p.AsInteger() == 1
    except Exception:
        return False


def _plantilla_de(doc, v):
    """Nombre de la plantilla de vista asignada (u'' si no tiene)."""
    try:
        tid = v.ViewTemplateId
        if tid is None or eid_int(tid) < 0:
            return u''
        tpl = doc.GetElement(tid)
        return nombre_de(tpl) if tpl is not None else u''
    except Exception:
        return u''


def _motivo_sin_anotacion(doc, v):
    """Etapa 6A: por qué una vista no tiene el recorte de anotación activo (u'' si lo tiene), para los avisos."""
    try:
        if not v.CropBoxActive:
            return u'la región de recorte no está activa'
    except Exception:
        return u'la vista no tiene región de recorte'
    try:
        p = v.get_Parameter(DB.BuiltInParameter.VIEWER_ANNOTATION_CROP_ACTIVE)
    except Exception:
        p = None
    if p is None:
        return u'la vista no tiene recorte de anotación'
    try:
        if p.AsInteger() == 1:
            return u''
        if p.IsReadOnly:
            tpl = _plantilla_de(doc, v)
            return u'el recorte de anotación es de solo lectura' + (
                u' (¿lo controla la plantilla de vista «%s»?)' % tpl if tpl else u'')
    except Exception:
        pass
    return u'el recorte de anotación no está activo'


def _caja_y_origen(el, lamina):
    """((x0, y0, x1, y1), origen) que ocupa en la lámina y de dónde salió la medida (texto para los avisos).

    Con el recorte de anotación activo es el contorno real del viewport (GetBoxOutline: recorte + recorte de
    anotación) más su título (GetLabelOutline): el BoundingBox de un viewport cuenta también rejillas, marcas,
    anotaciones y el CAD importado «solo en esta vista» que ese recorte no deja ver. Sin él, el BoundingBox."""
    motivo = u''
    if isinstance(el, DB.Viewport):
        try:
            v = el.Document.GetElement(el.ViewId)
            if v is not None and v.CropBoxActive and _anotacion_activa(v):
                cajas = [_caja_outline(el.GetBoxOutline())]
                try:
                    cajas.append(_caja_outline(el.GetLabelOutline()))   # Revit 2022+
                except Exception:
                    pass
                c = acomodo.caja_union(cajas)
                if c is not None:
                    return c, u'el contorno del viewport (región de recorte + recorte de anotación + título)'
            if v is not None and not vista_multiple(v) and _escalable(v):
                motivo = _motivo_sin_anotacion(el.Document, v)
        except Exception:
            pass
    b = el.get_BoundingBox(lamina)
    if b is None:
        return None, u''
    origen = u'el bounding box del viewport (cuenta todo lo que se ve: anotaciones, rejillas enteras, CAD «solo en '
    origen += u'esta vista»%s)' % (u'; ' + motivo if motivo else u'')
    return (b.Min.X, b.Min.Y, b.Max.X, b.Max.Y), origen


def _caja_en_lamina(el, lamina):
    """(x0, y0, x1, y1) que ocupa en la lámina (ver _caja_y_origen)."""
    return _caja_y_origen(el, lamina)[0]


def _medida_y_origen(el, lamina):
    """((ancho, alto), origen) que ocupa en la lámina: región de recorte (o de anotaciones), anotaciones y título."""
    c, origen = _caja_y_origen(el, lamina)
    if c is None:
        return None, origen
    return (c[2] - c[0], c[3] - c[1]), origen


def _medida_en_lamina(el, lamina):
    """(ancho, alto) que ocupa en la lámina: región de recorte (o de anotaciones), anotaciones y título."""
    return _medida_y_origen(el, lamina)[0]


def _distribuir_en(doc, lamina, colocados, franja_pct, margen_pct):
    """Centra y reparte los elementos colocados en el área libre del rótulo. Devuelve si entran."""
    doc.Regenerate()
    area, hueco = _area_lamina(doc, lamina, franja_pct, margen_pct)
    medidas, centros_actuales = [], []
    for el in colocados:
        c = _caja_en_lamina(el, lamina)
        if c is None:
            medidas.append((0.3, 0.3))
            centros_actuales.append(DB.XYZ(0, 0, 0))
            continue
        medidas.append((c[2] - c[0], c[3] - c[1]))
        centros_actuales.append(DB.XYZ((c[0] + c[2]) / 2, (c[1] + c[3]) / 2, 0))
    centros, cabe = core.distribuir(area, medidas, hueco)
    for el, c, (px, py) in zip(colocados, centros_actuales, centros):
        mov = DB.XYZ(px - c.X, py - c.Y, 0)
        if mov.GetLength() > 1e-9:
            DB.ElementTransformUtils.MoveElement(doc, el.Id, mov)
    return cabe


def colocar(doc, lamina, vistas, franja_pct=20.0, margen_pct=3.0, nueva=False, acomodar=None):
    """Coloca vistas/tablas/leyendas dentro del área libre del rótulo: en filas, centradas y con el espacio libre
    repartido por igual (core.distribuir). En una lámina que ya tenía vistas solo se ordenan las nuevas.

    Etapa 5C: si en una lámina NUEVA no entran y `acomodar` (dict, ver aplicar_plan) lo permite, se ajusta la región
    de recorte de las vistas que encierran mucho vacío (CAD oculto, marcas lejanas) y luego se elige, en este orden,
    una lámina más grande, una escala menor o repartir en otra lámina (acomodo.acomodar). Devuelve avisos."""
    avisos = []
    colocados, vistas_ok = [], []
    ya_tenia = False
    if not nueva:
        try:
            ya_tenia = lamina.GetAllPlacedViews().Count > 0
        except Exception:
            ya_tenia = False
    for v in vistas:
        try:
            if not puede_colocar(doc, lamina.Id, v):
                avisos.append(u'Revit no permite colocar «%s» en esta lámina' % v.Name)
                continue
            colocados.append(_crear_en_lamina(doc, lamina, v))
            vistas_ok.append(v)
        except Exception as ex:
            avisos.append(u'No se pudo colocar «%s»: %s' % (v.Name, _u(ex)))
    if not colocados:
        return avisos
    cabe = _distribuir_en(doc, lamina, colocados, franja_pct, margen_pct)
    if not cabe and nueva and acomodar is not None:
        # en una subtransacción: si algo falla, la lámina queda como estaba (con el aviso de siempre)
        st = DB.SubTransaction(doc)
        st.Start()
        try:
            avisos.extend(_acomodar(doc, lamina, colocados, vistas_ok, franja_pct, margen_pct, acomodar))
            st.Commit()
            cabe = True
        except Exception as ex:
            try:
                st.RollBack()
            except Exception:
                pass
            acomodar[u'extras'] = []
            avisos.append(u'No se pudo acomodar las vistas solo (%s)' % _u(ex))
    if not cabe:
        sin_recorte = []
        for v in vistas_ok:
            try:
                if not vista_multiple(v) and not v.CropBoxActive:
                    sin_recorte.append(_u(v.Name))
            except Exception:
                pass
        if sin_recorte:
            avisos.append(u'Las vistas no entran en el área libre del rótulo: «%s» no tiene la región de recorte '
                          u'activa (actívela para que solo ocupe el dibujo)' % u'», «'.join(sin_recorte))
        else:
            avisos.append(u'Las vistas no entran en el área libre del rótulo: revise sus escalas o recortes, o use '
                          u'un rótulo más grande')
    if ya_tenia:
        avisos.append(u'La lámina ya tenía vistas: revise la posición de las nuevas')
    return avisos


# ============================================================================ etapa 5C: acomodo automático

_CATS_FUERA = None


def _categorias_fuera():
    """Categorías que no son el dibujo (marcas de vistas, cámaras, puntos base, cajas de referencia, vínculos)."""
    global _CATS_FUERA
    if _CATS_FUERA is None:
        nombres = (u'OST_Cameras', u'OST_Viewers', u'OST_Elev', u'OST_ElevationMarks', u'OST_Sections',
                   u'OST_SectionHeads', u'OST_Callouts', u'OST_CalloutHeads', u'OST_CLines', u'OST_VolumeOfInterest',
                   u'OST_ProjectBasePoint', u'OST_SharedBasePoint', u'OST_SectionBox', u'OST_RvtLinks',
                   u'OST_ReferenceViewer', u'OST_Matchline', u'OST_SunPath', u'OST_ImportObjectStyles',
                   u'OST_RasterImages', u'OST_IOSGeoSite', u'OST_InternalOriginPoint')
        res = set()
        for n in nombres:
            bic = getattr(DB.BuiltInCategory, n, None)
            if bic is not None:
                try:
                    res.add(int(bic))
                except Exception:
                    pass
        _CATS_FUERA = res
    return _CATS_FUERA


def _escalable(v):
    """Plantas, cortes, elevaciones, detalles y 3D isométricos (no tablas, leyendas, vistas de dibujo ni perspectivas)."""
    try:
        if vista_multiple(v) or es_tabla(v) or es_cuadro(v) or v.ViewType in _tipos_sin_ocultar():
            return False
        if isinstance(v, DB.View3D) and v.IsPerspective:
            return False
        return int(v.Scale) > 0
    except Exception:
        return False


_DATUMS = None


def _categorias_datum():
    global _DATUMS
    if _DATUMS is None:
        _DATUMS = set()
        for n in (u'OST_Levels', u'OST_Grids', u'OST_GridChains'):
            bic = getattr(DB.BuiltInCategory, n, None)
            if bic is not None:
                try:
                    _DATUMS.add(int(bic))
                except Exception:
                    pass
    return _DATUMS


def extension_del_dibujo(doc, v):
    """(xmin, ymin, xmax, ymax) del dibujo de la vista en las coordenadas de su región de recorte, sin CAD importado,
    vínculos de Revit, marcas ni elementos sueltos lejos del conjunto (acomodo.extension_robusta). En vistas 3D solo
    cuenta el modelo (sin niveles ni rejillas, que en 3D tienen extensiones enormes). None si no se puede."""
    try:
        cb = v.CropBox
        inv = cb.Transform.Inverse
    except Exception:
        return None
    es_3d = isinstance(v, DB.View3D)
    solo_modelo = es_3d or isinstance(v, DB.ViewPlan)   # en plantas las rejillas se recortan (recorte de anotación)
    fuera = _categorias_fuera()
    datums = _categorias_datum()
    cajas = []
    for el in DB.FilteredElementCollector(doc, v.Id).WhereElementIsNotElementType():
        try:
            if isinstance(el, (DB.ImportInstance, DB.RevitLinkInstance)) or el.Category is None:
                continue
            cat = eid_int(el.Category.Id)
            if cat in fuera:
                continue
            if solo_modelo and (cat in datums or el.Category.CategoryType != DB.CategoryType.Model):
                continue
            bb = el.get_BoundingBox(v)
            if bb is None:
                continue
            tr = bb.Transform
            xs, ys = [], []
            for x in (bb.Min.X, bb.Max.X):
                for y in (bb.Min.Y, bb.Max.Y):
                    for z in (bb.Min.Z, bb.Max.Z):
                        p = inv.OfPoint(tr.OfPoint(DB.XYZ(x, y, z)))
                        xs.append(p.X)
                        ys.append(p.Y)
            cajas.append((min(xs), min(ys), max(xs), max(ys)))
        except Exception:
            continue
    return acomodo.extension_robusta(cajas, limitar_tamano=es_3d)


def ajustar_recorte(doc, v):
    """Región de recorte ajustada al dibujo (con un margen) si la vista no la tiene activa o si la que tiene encierra
    mucho vacío (p. ej. un CAD importado que se oculta al exportar). Devuelve el tamaño del dibujo en metros
    (ancho, alto) si cambió la vista, o None."""
    if not _escalable(v):
        return None
    caja = extension_del_dibujo(doc, v)
    if caja is None:
        return None
    planta = isinstance(v, DB.ViewPlan)
    if planta:
        # solo el modelo + margen para que asomen las rejillas; sus burbujas van en el recorte de anotación
        x0, y0, x1, y1 = acomodo.recorte_de_planta(caja)
    else:
        x0, y0, x1, y1 = caja
        m = 0.03 * max(x1 - x0, y1 - y0) + 1.0   # 1 pie de modelo + 3 %: las cabezas de niveles respiran
        x0, y0, x1, y1 = x0 - m, y0 - m, x1 + m, y1 + m
    if x1 - x0 <= 1e-6 or y1 - y0 <= 1e-6:
        return None
    cb = v.CropBox
    if v.CropBoxActive:
        cx0, cy0, cx1, cy1 = cb.Min.X, cb.Min.Y, cb.Max.X, cb.Max.Y
        tol = 1.0
        if x0 < cx0 - tol or y0 < cy0 - tol or x1 > cx1 + tol or y1 > cy1 + tol:
            return None           # el recorte corta el dibujo a propósito (planta parcial): no se toca
        if (x1 - x0) * (y1 - y0) > 0.6 * (cx1 - cx0) * (cy1 - cy0):
            return None           # el recorte ya es justo
        x0, y0, x1, y1 = max(x0, cx0), max(y0, cy0), min(x1, cx1), min(y1, cy1)
    try:
        nuevo = DB.BoundingBoxXYZ()
        nuevo.Transform = cb.Transform
        nuevo.Min = DB.XYZ(x0, y0, cb.Min.Z)
        nuevo.Max = DB.XYZ(x1, y1, cb.Max.Z)
        v.CropBox = nuevo
        v.CropBoxActive = True
    except Exception:
        return None
    # etapa 6A: Revit deja el «Recorte de anotación» en solo lectura mientras la región de recorte no está activa, y
    # eso no se actualiza hasta regenerar. En un modelo NUEVO (vista sin recorte) el recorte de anotación no se
    # activaba y la vista se medía con el BoundingBox (rejillas enteras y el CAD «solo en esta vista»).
    try:
        doc.Regenerate()
    except Exception:
        pass
    if planta:
        activar_recorte_anotacion(doc, v)
    return (x1 - x0) * 0.3048, (y1 - y0) * 0.3048


OFFSET_ANOTACION_MM = 15.0   # recorte de anotación de las plantas: lo justo para las burbujas de las rejillas


def activar_recorte_anotacion(doc, v):
    """Recorte de anotación activo con un margen pequeño (15 mm de papel): rejillas, marcas y textos que salen del
    recorte no agrandan la vista en la lámina. Devuelve True si quedó activo.

    Etapa 6A: si el parámetro está en solo lectura (la región de recorte se acaba de activar y Revit aún no regeneró)
    se regenera y se vuelve a intentar; y se comprueba que de verdad quedó activo."""
    def parametro():
        return v.get_Parameter(DB.BuiltInParameter.VIEWER_ANNOTATION_CROP_ACTIVE)

    try:
        p = parametro()
        if p is not None and p.IsReadOnly and p.AsInteger() != 1:
            doc.Regenerate()
            p = parametro()
        if p is None or (p.IsReadOnly and p.AsInteger() != 1):
            return False
        if p.AsInteger() != 1:
            p.Set(1)
            doc.Regenerate()
            p = parametro()
            if p is None or p.AsInteger() != 1:
                return False
    except Exception:
        return False
    papel = OFFSET_ANOTACION_MM / 304.8
    try:
        gestor = v.GetCropRegionShapeManager()

        def poner(valor):
            for lado in (u'Left', u'Right', u'Top', u'Bottom'):
                setattr(gestor, lado + u'AnnotationCropOffset', valor)
            doc.Regenerate()

        poner(papel)
        # ¿en qué unidades quedó? se mide el desfase en el modelo y, si hace falta, se corrige
        try:
            cb = v.CropBox
            inv = cb.Transform.Inverse
            xs = []
            for curva in gestor.GetAnnotationCropShape():
                xs.append(inv.OfPoint(curva.GetEndPoint(0)).X)
            if xs:
                corregido = acomodo.offset_anotacion(papel, abs(cb.Min.X - min(xs)), int(v.Scale))
                if corregido:
                    poner(corregido)
        except Exception:
            pass
    except Exception:
        pass
    return True


def _medir_escalas(doc, lamina, el, v, escalas):
    """{escala: (ancho, alto)} medidos de verdad en la lámina (se cambia la escala, se mide y se repone)."""
    res = {}
    actual = int(v.Scale)
    m = _medida_en_lamina(el, lamina)
    if m:
        res[actual] = m
    try:
        for e in escalas:
            try:
                v.Scale = int(e)
            except Exception:
                break          # la escala la controla la plantilla de vista
            doc.Regenerate()
            m = _medida_en_lamina(el, lamina)
            if m:
                res[int(e)] = m
    finally:
        if int(v.Scale) != actual:
            v.Scale = actual
            doc.Regenerate()
    return res


def _mover_a_lamina(doc, el, v, lamina):
    """Pasa una vista/tabla de su lámina a otra (Revit no mueve viewports entre láminas: se quita y se coloca)."""
    doc.Delete(el.Id)
    return _crear_en_lamina(doc, lamina, v)


def _cambiar_rotulo(doc, lamina, simbolo):
    tb = rotulo_de(doc, lamina)
    if tb is None or simbolo is None or eid_int(tb.GetTypeId()) == eid_int(simbolo.Id):
        return
    if not simbolo.IsActive:
        simbolo.Activate()
    tb.ChangeTypeId(simbolo.Id)
    doc.Regenerate()


def _ocultar_cad_para_medir(doc, vistas):
    """Etapa 6A: oculta (dentro de la subtransacción del acomodo) el CAD importado de las vistas de modelo, que se
    oculta igual al exportar: así una vista se mide como saldrá en el PDF/DWG aunque Revit no deje activar su recorte
    de anotación (un CAD importado «solo en esta vista» solo lo recorta el recorte de anotación). Devuelve
    [(vista, ids)] para volver a mostrarlo."""
    res = []
    for v in vistas:
        try:
            if not _escalable(v):
                continue
            ids = List[DB.ElementId]()
            for imp in DB.FilteredElementCollector(doc, v.Id).OfClass(DB.ImportInstance):
                try:
                    if not imp.IsHidden(v) and imp.CanBeHidden(v):
                        ids.Add(imp.Id)
                except Exception:
                    continue
            if ids.Count:
                v.HideElements(ids)
                res.append((v, ids))
        except Exception:
            continue
    return res


def _mostrar_cad(doc, ocultos):
    for v, ids in ocultos:
        try:
            v.UnhideElements(ids)
        except Exception:
            pass
    if ocultos:
        try:
            doc.Regenerate()
        except Exception:
            pass


def _acomodar(doc, lamina, colocados, vistas, franja_pct, margen_pct, opc):
    """Lámina nueva cuyas vistas no entran. opc: dict(rotulos=[(texto, FamilySymbol)], maxima=int,
    cambiar_tamano, ajustar_recorte, repartir, especialidad, nombre, numeros=función(n) → [números], extras=[] (aquí
    se agregan las láminas nuevas del reparto)). Devuelve avisos que explican lo que se hizo.

    Etapa 6A: se mide sin el CAD importado (se oculta al exportar; aquí solo mientras se mide y se reparte)."""
    ocultos = _ocultar_cad_para_medir(doc, vistas)
    try:
        return _acomodar_medido(doc, lamina, colocados, vistas, franja_pct, margen_pct, opc)
    finally:
        _mostrar_cad(doc, ocultos)


def _acomodar_medido(doc, lamina, colocados, vistas, franja_pct, margen_pct, opc):
    avisos = []
    # 0. medir bien: región de recorte ajustada al dibujo (sin el CAD que se oculta al exportar)
    if opc.get(u'ajustar_recorte', True):
        ajustadas, sin_anotacion = [], []
        for i, v in enumerate(vistas):
            m = ajustar_recorte(doc, v)
            hecho = u''
            if m:
                hecho = u'«%s» (%.1f × %.1f m)' % (_u(v.Name), m[0], m[1])
            elif isinstance(v, DB.ViewPlan) and _escalable(v) and v.CropBoxActive and not _anotacion_activa(v):
                # planta con recorte justo pero sin recorte de anotación: las rejillas largas la agrandan
                if activar_recorte_anotacion(doc, v):
                    hecho = u'«%s» (recorte de anotación)' % _u(v.Name)
            if hecho:
                ajustadas.append(hecho)
                # etapa 6A: se vuelve a colocar (la lámina es nueva: su viewport se acaba de crear) para que su caja
                # sea la del recorte nuevo y no la de la vista sin recorte con la que se colocó
                doc.Regenerate()
                colocados[i] = _mover_a_lamina(doc, colocados[i], v, lamina)
            if isinstance(v, DB.ViewPlan) and _escalable(v) and v.CropBoxActive and not _anotacion_activa(v):
                sin_anotacion.append(u'«%s» (%s)' % (_u(v.Name), _motivo_sin_anotacion(doc, v)))
        if sin_anotacion:
            avisos.append(u'No se pudo activar el recorte de anotación de %s: se mide con el bounding box del '
                          u'viewport, sin el CAD importado (se oculta al exportar).' % u', '.join(sin_anotacion))
        if ajustadas:
            texto = (u'Se ajustó la región de recorte de %s al dibujo (sin CAD importado ni elementos sueltos lejanos; '
                     u'en plantas y 3D solo el modelo, y en plantas recorte de anotación de 15 mm para las burbujas)'
                     % u', '.join(ajustadas))
            if _distribuir_en(doc, lamina, colocados, franja_pct, margen_pct):
                return avisos + [texto + u': ahora las vistas entran.']
            avisos.append(texto + u'.')
    tb = rotulo_de(doc, lamina)
    actual_sim = doc.GetElement(tb.GetTypeId()) if tb is not None else None
    if actual_sim is None:
        return avisos + [u'Las vistas no entran y la lámina no tiene rótulo: elija un rótulo más grande.']
    actual = texto_rotulo(actual_sim)
    serie = core.serie_de_rotulo(actual)
    tamanos, simbolos = [], {}
    for t, s_ in opc.get(u'rotulos') or []:
        if t == actual or (serie and core.serie_de_rotulo(t) == serie):
            m = tamano_rotulo(s_)
            if m and t not in simbolos:
                tamanos.append((t, m[0], m[1]))
                simbolos[t] = s_
    if actual not in simbolos:
        m = tamano_rotulo(actual_sim)
        if not m:
            bb = tb.get_BoundingBox(lamina)
            m = (bb.Max.X - bb.Min.X, bb.Max.Y - bb.Min.Y) if bb is not None else (841 / 304.8, 594 / 304.8)
        tamanos.append((actual, m[0], m[1]))
        simbolos[actual] = actual_sim
    maxima = int(opc.get(u'maxima') or 100)
    plan = []
    for el, v in zip(colocados, vistas):
        if _escalable(v):
            esc = int(v.Scale)
            medidas = _medir_escalas(doc, lamina, el, v, acomodo.escalas_siguientes(esc, maxima))
            escalable = len(medidas) > 1 or not acomodo.escalas_siguientes(esc, maxima)
            origen = _medida_y_origen(el, lamina)[1]
            plan.append(acomodo.Vista(v.Name, medidas or (0.3, 0.3), esc, escalable, ALTO_TITULO_VISTA, origen))
        else:
            m, origen = _medida_y_origen(el, lamina)
            plan.append(acomodo.Vista(v.Name, m or (0.3, 0.3), origen=origen))
    prop = acomodo.acomodar(plan, tamanos, actual, franja_pct, margen_pct, maxima,
                            cambiar_tamano=bool(opc.get(u'cambiar_tamano', True)), cambiar_escala=True,
                            repartir=bool(opc.get(u'repartir', True)), especialidad=opc.get(u'especialidad', u''),
                            unidad_mm=304.8)
    if not prop.cambia:
        return avisos + [prop.texto]
    # aplicar: tamaño, escalas y reparto
    for i, e in prop.escalas.items():
        vistas[i].Scale = int(e)
    _cambiar_rotulo(doc, lamina, simbolos.get(prop.tamanos[0]))
    hojas = [(lamina, [colocados[i] for i in prop.grupos[0]])]
    if len(prop.grupos) > 1:
        numeros = opc[u'numeros'](len(prop.grupos) - 1)
        for k, g in enumerate(prop.grupos[1:]):
            sim = simbolos.get(prop.tamanos[k + 1]) or actual_sim
            if not sim.IsActive:
                sim.Activate()
            otra = DB.ViewSheet.Create(doc, sim.Id)
            otra.SheetNumber = numeros[k]
            otra.Name = opc.get(u'nombre') or _u(lamina.Name)
            doc.Regenerate()
            hojas.append((otra, [_mover_a_lamina(doc, colocados[i], vistas[i], otra) for i in g]))
            opc.setdefault(u'extras', []).append(otra)
    ok = all([_distribuir_en(doc, h, els, franja_pct, margen_pct) for h, els in hojas])
    texto = prop.texto
    if len(hojas) > 1:
        texto += u' Láminas: %s.' % u', '.join(_u(h.SheetNumber) for h, _ in hojas)
    if not ok:
        texto += u' Aun así no entran del todo: revise la región de recorte de las vistas.'
    return avisos + [texto]


# ============================================================================ tamaño de lámina uniforme

ALTO_TITULO_VISTA = 22 / 304.8   # el título de la vista (debajo del dibujo) en pies de papel


def tamano_rotulo(simbolo):
    """(ancho, alto) del rótulo en pies de papel: parámetros «Ancho/Alto de hoja» del tipo o el tamaño ISO del
    nombre (A0…A4). None si no se sabe."""
    for bw, bh in ((u'SHEET_WIDTH', u'SHEET_HEIGHT'),):
        try:
            pw, ph = simbolo.get_Parameter(bip(bw)), simbolo.get_Parameter(bip(bh))
            if pw is not None and ph is not None and pw.AsDouble() > 0 and ph.AsDouble() > 0:
                return pw.AsDouble(), ph.AsDouble()
        except Exception:
            pass
    iso = core.tamano_iso(texto_rotulo(simbolo))
    if iso:
        return iso[1] / 304.8, iso[2] / 304.8
    return None


def medida_vista(vista):
    """(ancho, alto) que ocupará la vista en la lámina (pies de papel), o None si Revit no lo da."""
    try:
        o = vista.Outline
        w, h = o.Max.U - o.Min.U, o.Max.V - o.Min.V
        if w > 0 and h > 0:
            return w, h + (0 if vista_multiple(vista) else ALTO_TITULO_VISTA)
    except Exception:
        pass
    return None


def uniformar_rotulos(doc, acciones, simbolo_defecto, rotulos_lista, especialidades, franja_pct=20.0,
                      margen_pct=3.0):
    """Láminas NUEVAS sin rótulo en el Excel: un solo tamaño por especialidad.

    - Si la especialidad ya tiene láminas en el modelo, el rótulo que más usan (todas iguales).
    - Si no, el rótulo por defecto o, si sus vistas no entran, el más chico de la MISMA serie (ALF_BIM A0…A3) donde
      entran las vistas de todas sus láminas nuevas.
    Devuelve los avisos para la ventana de salida."""
    avisos = []
    nuevas = [a for a in acciones if a.tipo == core.Accion.CREAR and a.detalle is not None and
              a.detalle.rotulo is None]
    if not nuevas or simbolo_defecto is None:
        return avisos
    por_texto = dict((t, s) for t, s in rotulos_lista)
    usados = {}      # código -> {id del tipo de rótulo: cantidad}
    tipos = {}       # id -> ElementId
    for s in laminas(doc, incluir_marcadores=False):
        tb = rotulo_de(doc, s)
        if tb is None:
            continue
        cod = especialidades.de_numero(s.SheetNumber)
        tid = eid_int(tb.GetTypeId())
        tipos[tid] = tb.GetTypeId()
        usados.setdefault(cod, {})
        usados[cod][tid] = usados[cod].get(tid, 0) + 1
    texto_def = texto_rotulo(simbolo_defecto)
    serie = core.serie_de_rotulo(texto_def)
    candidatos = []
    if serie:
        for t, s in rotulos_lista:
            if core.serie_de_rotulo(t) == serie:
                m = tamano_rotulo(s)
                if m:
                    candidatos.append((t, m[0], m[1]))
    grupos = {}
    for a in nuevas:
        cod = a.especialidad or especialidades.de_numero(a.numero)
        grupos.setdefault(cod, []).append(a)
    for cod, lista in sorted(grupos.items(), key=lambda x: (especialidades.orden(x[0]), x[0])):
        etiqueta = cod or u'(sin especialidad)'
        if usados.get(cod):
            tid = max(usados[cod].items(), key=lambda x: x[1])[0]
            sim = doc.GetElement(tipos[tid])
            if sim is not None:
                for a in lista:
                    a.detalle.rotulo, a.detalle.rotulo_texto = sim, texto_rotulo(sim)
                    a.detalle.rotulo_uniforme = True
                avisos.append(u'%s: %d lámina(s) nuevas con «%s», el rótulo de las que ya tiene la especialidad'
                              % (etiqueta, len(lista), texto_rotulo(sim)))
                continue
        elegido = texto_def
        if len(candidatos) > 1:
            necesidades = []
            for a in lista:
                vistas = [medida_vista(v) for v in a.detalle.vistas]
                necesidades.append([m for m in vistas if m])
            # una vista que no entra ni en el más grande (p. ej. sin región de recorte) no decide el tamaño
            grande = max(candidatos, key=lambda c: c[1] * c[2])
            area_g = core.area_libre(grande[1], grande[2], franja_pct, margen_pct)
            ancho_g, alto_g = area_g[2] - area_g[0], area_g[3] - area_g[1]
            necesidades = [[m for m in n if m[0] <= ancho_g and m[1] <= alto_g] for n in necesidades]
            clave, todas = core.elegir_tamano(candidatos, necesidades, franja_pct, margen_pct, minimo=texto_def)
            if clave:
                elegido = clave
            if not todas:
                avisos.append(u'%s: las vistas de alguna lámina no entran ni en «%s»' % (etiqueta, elegido))
        sim = por_texto.get(elegido, simbolo_defecto)
        for a in lista:
            a.detalle.rotulo, a.detalle.rotulo_texto = sim, texto_rotulo(sim)
            a.detalle.rotulo_uniforme = True
        avisos.append(u'%s: %d lámina(s) nuevas con «%s» (mismo tamaño en toda la especialidad)'
                      % (etiqueta, len(lista), texto_rotulo(sim)))
    return avisos


def _escribir_params(doc, lam, params):
    avisos = []
    tb = rotulo_de(doc, lam)
    for nombre, valor in params:
        p, lugar = param_de_lamina(doc, lam, tb, nombre)
        if p is None:
            avisos.append(u'No existe «%s»' % nombre)
            continue
        if mismo_valor(p, valor):
            continue
        err = escribir_param(p, valor)
        if err:
            avisos.append(u'«%s» %s' % (nombre, err))
    return avisos


def _opciones_acomodo(doc, a, opciones, planificados):
    """Opciones del acomodo automático de una lámina nueva (etapa 5C)."""
    cod = a.especialidad or core.Especialidades(opciones.get(u'especialidades')).de_numero(a.numero)

    def numeros(n):
        existentes = [_u(s.SheetNumber) for s in laminas(doc)] + list(planificados)
        return acomodo.numeros_extra(a.numero, n, existentes, opciones.get(u'reparto_numeracion', u'sufijo'),
                                     opciones.get(u'separador', u'-'), int(opciones.get(u'digitos', 2)))
    return dict(rotulos=opciones.get(u'rotulos') or [], especialidad=cod, nombre=a.nombre,
                maxima=acomodo.escala_maxima(cod, opciones.get(u'escala_maxima')),
                cambiar_tamano=not a.detalle.rotulo_uniforme, ajustar_recorte=opciones.get(u'ajustar_recorte', True),
                repartir=opciones.get(u'repartir', True), numeros=numeros, extras=[])


class Cancelado(Exception):
    """El usuario canceló: se deshace todo lo hecho."""


class ErrorPlanos(Exception):
    """Error con mensaje para el usuario (en español)."""


def _confirmar(t, que):
    estado = t.Commit()
    if estado != DB.TransactionStatus.Committed:
        raise ErrorPlanos(u'Revit no aceptó los cambios (%s). No se modificó el modelo.' % que)


def _deshacer(t, tg=None):
    try:
        if t is not None and t.HasStarted() and not t.HasEnded():
            t.RollBack()
    except Exception:
        pass
    try:
        if tg is not None and tg.HasStarted() and not tg.HasEnded():
            tg.RollBack()
    except Exception:
        pass


def aplicar_plan(doc, acciones, opciones, progreso=None):
    """Aplica el plan. opciones: dict(crear, actualizar, vistas, rotulo_defecto (FamilySymbol o None),
    franja_pct, margen_pct, proyecto [(nombre, valor)]). Devuelve (resultados, avisos_proyecto).

    resultados: [(accion, lamina o None, [avisos], error)]. Si el usuario cancela se lanza Cancelado y no queda
    ningún cambio en el modelo (todo es un solo grupo de transacciones)."""
    resultados = []
    avisos_proyecto = []
    tg = DB.TransactionGroup(doc, u'PlanosALF: láminas desde Excel')
    tg.Start()
    t = None
    try:
        # 1) Información del proyecto
        if opciones.get(u'proyecto'):
            t = transaccion(doc, u'PlanosALF: información del proyecto')
            t.Start()
            for nombre, valor in opciones[u'proyecto']:
                p = param_de_proyecto(doc, nombre)
                if p is None:
                    avisos_proyecto.append(u'No existe el parámetro del proyecto «%s»' % nombre)
                    continue
                if mismo_valor(p, valor):
                    continue
                err = escribir_param(p, valor)
                if err:
                    avisos_proyecto.append(u'«%s»: %s' % (nombre, err))
            _confirmar(t, u'información del proyecto')

        elegidas = [a for a in acciones if a.aplicar and (
            (a.tipo == core.Accion.CREAR and opciones.get(u'crear', True)) or
            (a.tipo == core.Accion.ACTUALIZAR and opciones.get(u'actualizar', True)))]
        total = len(elegidas)

        # 2) números: primero temporales (permite intercambiar E-01 y E-02), luego los definitivos
        t = transaccion(doc, u'PlanosALF: crear y actualizar láminas')
        t.Start()
        renumerar_ = [a for a in elegidas if a.tipo == core.Accion.ACTUALIZAR and a.detalle.lamina is not None
                      and a.numero != a.numero_actual]
        planificados = set(_u(a.numero).upper() for a in acciones if a.numero)
        for i, a in enumerate(renumerar_):
            a.detalle.lamina.SheetNumber = u'PLANOSALF-TMP-%d-%s' % (i, a.numero_actual)
        hechos = 0
        for a in elegidas:
            if progreso and progreso(hechos, total):
                raise Cancelado()
            hechos += 1
            d = a.detalle
            # los avisos del plan (vista no encontrada, número asignado…) también van al resultado y a la respuesta
            avisos = list(a.avisos)
            nueva = None
            try:
                if a.tipo == core.Accion.CREAR:
                    sim = d.rotulo or opciones.get(u'rotulo_defecto')
                    if sim is not None and not sim.IsActive:
                        sim.Activate()
                    nueva = DB.ViewSheet.Create(doc, sim.Id if sim is not None else DB.ElementId.InvalidElementId)
                    nueva.SheetNumber = a.numero
                    nueva.Name = a.nombre
                    lam = d.lamina = nueva
                    doc.Regenerate()
                else:
                    lam = d.lamina
                    if a.numero != _u(lam.SheetNumber):
                        lam.SheetNumber = a.numero
                    if a.nombre and a.nombre != _u(lam.Name):
                        lam.Name = a.nombre
                avisos.extend(_escribir_params(doc, lam, d.params))
                aco = None
                if nueva is not None and opciones.get(u'acomodar', True):
                    aco = _opciones_acomodo(doc, a, opciones, planificados)
                if opciones.get(u'vistas', True) and d.vistas:
                    avisos.extend(colocar(doc, lam, d.vistas, opciones.get(u'franja_pct', 20.0),
                                          opciones.get(u'margen_pct', 3.0), nueva=nueva is not None, acomodar=aco))
                resultados.append((a, lam, avisos, u''))
                # láminas que salieron de repartir las vistas (A-04a…): mismos datos del rótulo
                for otra in (aco or {}).get(u'extras') or []:
                    extra = copy.copy(a)
                    extra.numero, extra.nombre = _u(otra.SheetNumber), _u(otra.Name)
                    extra.detalle = Detalle()
                    extra.detalle.lamina = otra
                    av = _escribir_params(doc, otra, d.params)
                    resultados.append((extra, otra, [u'Lámina nueva: las vistas de %s se repartieron' % a.numero] +
                                       av, u''))
                    planificados.add(extra.numero.upper())
            except Exception as ex:
                if nueva is not None:   # no dejar una lámina «Sin nombre» a medio crear
                    try:
                        doc.Delete(nueva.Id)
                    except Exception:
                        pass
                    d.lamina = None
                resultados.append((a, None if nueva is not None else d.lamina, avisos, _u(ex)))
        # 3) ningún número temporal puede quedar: se devuelve el número original o se deshace todo
        quedan = []
        for a in renumerar_:
            lam = a.detalle.lamina
            if _u(lam.SheetNumber).startswith(u'PLANOSALF-TMP-'):
                try:
                    lam.SheetNumber = a.numero_actual
                except Exception:
                    quedan.append(a.numero_actual)
        if quedan:
            raise ErrorPlanos(u'No se pudo devolver su número a: %s (otra lámina ya lo usa). No se modificó el '
                              u'modelo; revise los números del Excel.' % u', '.join(quedan))
        _confirmar(t, u'láminas')
        t = None
        tg.Assimilate()
    except Exception:
        _deshacer(t, tg)
        raise
    return resultados, avisos_proyecto


# ============================================================================ renumerar

def renumerar(doc, cambios, param_total=u'', especialidades=None):
    """cambios: [(uid, actual, nuevo)]. Todo o nada: si una lámina no se puede renumerar, no cambia ninguna.
    Devuelve (hechos, errores, avisos)."""
    por_uid = dict((_u(s.UniqueId), s) for s in laminas(doc))
    errores = []
    avisos = []
    hechos = 0
    t = transaccion(doc, u'PlanosALF: renumerar láminas')
    t.Start()
    try:
        pendientes = [(por_uid.get(uid), actual, nuevo) for uid, actual, nuevo in cambios if actual != nuevo]
        for s, actual, nuevo in pendientes:
            if s is None:
                errores.append(u'%s: la lámina ya no existe' % actual)
        if not errores:
            for i, (s, actual, nuevo) in enumerate(pendientes):
                s.SheetNumber = u'PLANOSALF-TMP-%d-%s' % (i, actual)
            for s, actual, nuevo in pendientes:
                try:
                    s.SheetNumber = nuevo
                    hechos += 1
                except Exception as ex:
                    errores.append(u'%s → %s: %s' % (actual, nuevo, _u(ex)))
        if errores:
            _deshacer(t)
            return 0, errores, avisos
        if param_total and especialidades is not None:
            conteo = {}
            hojas = [s for s in laminas(doc) if not s.IsPlaceholder]
            for s in hojas:
                cod = especialidades.de_numero(s.SheetNumber)
                conteo[cod] = conteo.get(cod, 0) + 1
            afectadas = set(especialidades.de_numero(n) for _, _, n in cambios)
            sin_param = 0
            for s in hojas:
                cod = especialidades.de_numero(s.SheetNumber)
                if cod not in afectadas:
                    continue
                p, lugar = param_de_lamina(doc, s, rotulo_de(doc, s), param_total)
                if p is None or lugar == u'proyecto':
                    sin_param += 1
                    continue
                total = _u(str(conteo.get(cod, 0)))
                if not mismo_valor(p, total):
                    err = escribir_param(p, total)
                    if err:
                        avisos.append(u'%s: «%s» %s' % (s.SheetNumber, param_total, err))
            if sin_param:
                avisos.append(u'%d lámina(s) no tienen el parámetro «%s» (ni en su rótulo)' % (sin_param, param_total))
        _confirmar(t, u'renumerar')
    except Exception:
        _deshacer(t)
        raise
    return hechos, errores, avisos


# ============================================================================ exportar

def opciones_pdf(cfg):
    o = DB.PDFExportOptions()

    def poner(attr, valor):
        try:
            setattr(o, attr, valor)
        except Exception:
            pass

    color = {u'color': u'Color', u'grises': u'GrayScale', u'negro': u'BlackLine'}.get(cfg.get(u'color_pdf'), u'Color')
    poner(u'ColorDepth', getattr(DB.ColorDepthType, color))
    calidad = {u'baja': u'Low', u'media': u'Medium', u'alta': u'High',
               u'presentacion': u'Presentation'}.get(cfg.get(u'calidad_pdf'), u'High')
    poner(u'RasterQuality', getattr(DB.RasterQualityType, calidad))
    try:
        ppp = {u'Low': u'DPI144', u'Medium': u'DPI300', u'High': u'DPI600', u'Presentation': u'DPI1200'}[calidad]
        poner(u'ExportQuality', getattr(DB.PDFExportQualityType, ppp))
    except Exception:
        pass
    poner(u'PaperFormat', DB.ExportPaperFormat.Default)
    poner(u'ZoomType', DB.ZoomType.Zoom)
    poner(u'ZoomPercentage', 100)
    poner(u'HideCropBoundaries', bool(cfg.get(u'ocultar_recortes', True)))
    poner(u'HideReferencePlane', bool(cfg.get(u'ocultar_ref', True)))
    poner(u'HideScopeBoxes', bool(cfg.get(u'ocultar_cajas', True)))
    poner(u'HideUnreferencedViewTags', bool(cfg.get(u'ocultar_etiquetas', True)))
    poner(u'StopOnError', False)
    return o


def opciones_dwg(doc, cfg):
    o = None
    nombre = cfg.get(u'config_dwg') or u''
    if nombre:
        try:
            o = DB.DWGExportOptions.GetPredefinedOptions(doc, nombre)
        except Exception:
            o = None
    if o is None:
        o = DB.DWGExportOptions()
    try:
        o.MergedViews = bool(cfg.get(u'dwg_unido', True))
    except Exception:
        pass
    version = u'R' + _u(cfg.get(u'version_dwg') or u'2018')
    if hasattr(DB.ACADVersion, version):
        try:
            o.FileVersion = getattr(DB.ACADVersion, version)
        except Exception:
            pass
    return o


def configuraciones_dwg(doc):
    try:
        return sorted(_u(n) for n in DB.BaseExportOptions.GetPredefinedSetupNames(doc))
    except Exception:
        return []


def _preparar_destino(ruta, sobrescribir):
    """Devuelve la ruta final (con (2) si no se sobrescribe) o lanza IOError si está abierta/bloqueada."""
    if not os.path.exists(ruta):
        return ruta
    if sobrescribir:
        try:
            os.remove(ruta)
            return ruta
        except OSError:
            raise IOError(u'El archivo está abierto en otro programa: %s' % os.path.basename(ruta))
    base, ext = os.path.splitext(ruta)
    i = 2
    while os.path.exists(u'%s (%d)%s' % (base, i, ext)):
        i += 1
    return u'%s (%d)%s' % (base, i, ext)


def exportar_pdf(doc, ids, carpeta, nombre, opciones, sobrescribir=True):
    """Exporta una o varias láminas a UN PDF combinado con el nombre dado. Devuelve la ruta."""
    if not os.path.isdir(carpeta):
        os.makedirs(carpeta)
    ruta = _preparar_destino(os.path.join(carpeta, nombre + u'.pdf'), sobrescribir)
    opciones.Combine = True
    opciones.FileName = os.path.splitext(os.path.basename(ruta))[0]
    lista = List[DB.ElementId]()
    for i in ids:
        lista.Add(i)
    ok = doc.Export(carpeta, lista, opciones)
    if not ok or not os.path.exists(ruta):
        raise IOError(u'Revit no generó el PDF')
    return ruta


def _quitar_pcp(carpeta, base):
    # Revit deja un .pcp (registro de capas) junto a cada DWG: no forma parte del entregable
    pcp = os.path.join(carpeta, base + u'.pcp')
    if os.path.exists(pcp):
        try:
            os.remove(pcp)
        except OSError:
            pass


def _imagenes_en(carpeta):
    """{nombre: fecha} de las imágenes sueltas de una carpeta."""
    res = {}
    try:
        for x in os.listdir(carpeta):
            if core.es_imagen(x):
                try:
                    res[x] = os.path.getmtime(os.path.join(carpeta, x))
                except OSError:
                    pass
    except OSError:
        pass
    return res


def exportar_dwg(doc, lamina_id, carpeta, nombre, opciones, sobrescribir=True, revisar_imagenes=True,
                 revisiones=None):
    """Exporta una lámina a DWG. Devuelve la ruta del DWG.

    Revit no incrusta las imágenes (logos del rótulo, fotos): las escribe como archivos aparte junto al DWG y el DWG
    guarda su ruta (IMAGEDEF). AutoCAD las busca en esa ruta y luego en la carpeta del DWG, así que se quedan junto
    al DWG (la subcarpeta «_imagenes» de la 1.2.0 las dejaba donde AutoCAD no las busca). Con `revisar_imagenes` se
    lee el DWG y se copia junto a él cualquier imagen que pida y no esté; el resultado se agrega a `revisiones`."""
    if not os.path.isdir(carpeta):
        os.makedirs(carpeta)
    ruta = _preparar_destino(os.path.join(carpeta, nombre + u'.dwg'), sobrescribir)
    lista = List[DB.ElementId]()
    lista.Add(lamina_id)
    base = os.path.splitext(os.path.basename(ruta))[0]
    antes = _imagenes_en(carpeta)
    ok = doc.Export(carpeta, base, lista, opciones)
    if not ok or not os.path.exists(ruta):
        raise IOError(u'Revit no generó el DWG')
    _quitar_pcp(carpeta, base)
    if revisar_imagenes:
        despues = _imagenes_en(carpeta)
        escritas = sorted(x for x, t in despues.items() if antes.get(x) != t)
        res = dwg_imagenes.revisar(ruta, buscar_en=[carpeta, os.path.join(carpeta, core.CARPETA_IMAGENES)])
        res[u'escritas_por_revit'] = escritas
        if revisiones is not None:
            revisiones.append(res)
    return ruta


def imagenes_de_dwg(carpeta):
    """Cantidad de imágenes sueltas junto a los DWG de una carpeta."""
    return len(_imagenes_en(carpeta))


def _poner_logo_prueba(doc, lamina, ruta_logo, registro):
    """Solo para pedidos de desarrollo: pone una imagen en el recuadro «LOGO DEL CONSULTOR» del rótulo ALF_BIM
    (se deshace al terminar la exportación) para comprobar que el DWG la muestra."""
    tb = rotulo_de(doc, lamina)
    bb = tb.get_BoundingBox(lamina) if tb is not None else None
    if bb is None:
        raise ErrorPlanos(u'la lámina %s no tiene rótulo' % _u(lamina.SheetNumber))
    w, h = bb.Max.X - bb.Min.X, bb.Max.Y - bb.Min.Y
    tipo = DB.ImageType.Create(doc, DB.ImageTypeOptions(ruta_logo, False, DB.ImageTypeSource.Import))
    registro.creados.append(tipo.Id)
    punto = DB.XYZ(bb.Min.X + 0.953 * w, bb.Min.Y + 0.33 * h, 0)
    inst = DB.ImageInstance.Create(doc, lamina, tipo.Id, DB.ImagePlacementOptions(punto, DB.BoxPlacement.Center))
    registro.creados.insert(0, inst.Id)
    try:
        inst.Width = 0.034 * w
    except Exception:
        pass
    registro.n_logos += 1


def exportar_sin_cad(doc, laminas_lista, funcion, estadistica=None, logo=None, ocultar=True):
    """Ejecuta `funcion()` (una exportación) con los CAD importados/vinculados ocultos en las vistas de las láminas
    (también los que llegan dentro de un modelo de Revit vinculado) y después deja el modelo EXACTAMENTE como
    estaba: todo va en un grupo de transacciones que se deshace (no queda nada en el historial). Si Revit no permite
    exportar dentro del grupo, oculta, exporta y vuelve a mostrar con dos transacciones.

    Los textos de los DWG de referencia salen en RomanS/Arial: ocultarlos deja el PDF con las fuentes del rótulo.
    estadistica: dict donde se suman 'cad' (CAD ocultos), 'vistas' (vistas tocadas) y 'logos'.
    ocultar: False = no se oculta el CAD (solo el logo de prueba).
    logo: ruta de una imagen de prueba que se pone en el rótulo mientras se exporta (pedidos de desarrollo)."""
    pares = []
    if ocultar:
        for s in laminas_lista:
            pares += importaciones_cad(doc, s)
    if not pares and not logo:
        return funcion()
    registro = _RegistroCad()

    def preparar(reg):
        _ocultar_cad(doc, pares, reg)
        if logo:
            for s in laminas_lista:
                _poner_logo_prueba(doc, s, logo, reg)

    def sumar():
        if estadistica is not None:
            estadistica[u'cad'] = estadistica.get(u'cad', 0) + registro.n_cad
            estadistica[u'vistas'] = estadistica.get(u'vistas', 0) + registro.n_vistas
            estadistica[u'logos'] = estadistica.get(u'logos', 0) + registro.n_logos

    tg = DB.TransactionGroup(doc, u'PlanosALF: exportar sin CAD')
    tg.Start()
    t = None
    reintentar = False
    try:
        t = transaccion(doc, u'PlanosALF: preparar la exportación')
        t.Start()
        preparar(registro)
        _confirmar(t, u'ocultar CAD')
        t = None
        try:
            ruta = funcion()
            sumar()
            return ruta
        except Exception as ex:
            if not _es_error_de_transaccion(ex):
                raise
            reintentar = True
    finally:
        if t is not None:
            _deshacer(t)
        deshecho = False
        try:
            if tg.HasStarted() and not tg.HasEnded():
                deshecho = tg.RollBack() == DB.TransactionStatus.RolledBack
        except Exception:
            deshecho = False
        if not deshecho:
            _restaurar_cad(doc, registro)
    if reintentar:
        registro = _RegistroCad()
        t = transaccion(doc, u'PlanosALF: preparar la exportación')
        t.Start()
        try:
            preparar(registro)
            _confirmar(t, u'ocultar CAD')
        except Exception:
            _deshacer(t)
            raise
        try:
            ruta = funcion()
            sumar()
            return ruta
        finally:
            _restaurar_cad(doc, registro)
