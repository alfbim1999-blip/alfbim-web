# -*- coding: utf-8 -*-
"""Lógica de PlanosALF que no depende de Revit (se prueba fuera de Revit).

- Especialidades y prefijos de lámina (E-, IE-, IS-…), numeración y orden natural.
- Lectura de la hoja LÁMINAS del Excel y plan de creación/actualización.
- Plan de renumeración sin choques.
- Nombres de archivo estandarizados para PDF/DWG.

ALF_BIM — Ing. Anderson Irigoín C.
"""
from __future__ import print_function, division

import re

try:
    import unicodedata
except ImportError:  # pragma: no cover (algunas versiones de IronPython)
    unicodedata = None

from planosalf import xlsx

_u = xlsx._u

# ============================================================================ textos

def normalizar(texto):
    """Minúsculas, sin tildes ni signos: 'Número de lámina' -> 'numerodelamina'."""
    texto = _u(texto).strip().lower()
    if unicodedata is not None:
        texto = unicodedata.normalize('NFKD', texto)
        texto = u''.join(c for c in texto if not unicodedata.combining(c))
    else:
        for a, b in zip(u'áéíóúàèìòùäëïöüâêîôûñç', u'aeiouaeiouaeiouaeiounc'):
            texto = texto.replace(a, b)
    return re.sub(u'[^a-z0-9]', u'', texto)


def clave_natural(texto):
    """Clave de orden natural: 'E-2' antes que 'E-10'."""
    partes = re.split(u'(\\d+)', _u(texto).upper())
    res = []
    for p in partes:
        if p.isdigit():
            res.append((1, int(p), u''))
        elif p:
            res.append((0, 0, p))
    return res


# ============================================================================ especialidades

ESPECIALIDADES_PERU = [
    (u'U', u'Ubicación y localización'),
    (u'T', u'Topografía'),
    (u'PP', u'Plano perimétrico'),
    (u'A', u'Arquitectura'),
    (u'D', u'Detalles arquitectónicos'),
    (u'E', u'Estructuras'),
    (u'IS', u'Instalaciones sanitarias'),
    (u'ACI', u'Agua contra incendio'),
    (u'IE', u'Instalaciones eléctricas'),
    (u'IM', u'Instalaciones mecánicas'),
    (u'IC', u'Instalaciones de comunicaciones'),
    (u'GN', u'Instalaciones de gas'),
    (u'SE', u'Señalización'),
    (u'EV', u'Seguridad y evacuación'),
    (u'EQ', u'Equipamiento'),
]


class Especialidades(object):
    """Tabla de especialidades: código (prefijo) -> nombre, en el orden del expediente."""

    def __init__(self, pares=None):
        self.pares = []
        for codigo, nombre in (pares if pares is not None else ESPECIALIDADES_PERU):
            codigo = _u(codigo).strip().upper()
            if codigo and codigo not in [c for c, _ in self.pares]:
                self.pares.append((codigo, _u(nombre).strip()))

    def codigos(self):
        return [c for c, _ in self.pares]

    def nombre(self, codigo):
        codigo = _u(codigo).strip().upper()
        for c, n in self.pares:
            if c == codigo:
                return n
        return u''

    def orden(self, codigo):
        codigo = _u(codigo).strip().upper()
        for i, (c, _) in enumerate(self.pares):
            if c == codigo:
                return i
        return len(self.pares)

    def codigo_de_texto(self, texto):
        """Acepta el código ('IE') o el nombre ('Instalaciones eléctricas')."""
        t = _u(texto).strip()
        if not t:
            return u''
        if t.upper() in self.codigos():
            return t.upper()
        n = normalizar(t)
        for c, nombre in self.pares:
            if normalizar(nombre) == n:
                return c
        # 'IE - Instalaciones eléctricas'
        m = re.match(u'^([A-Za-zÑñ]+)\\s*[-–:]', t)
        if m and m.group(1).upper() in self.codigos():
            return m.group(1).upper()
        return t.upper() if re.match(u'^[A-Za-zÑñ]{1,5}$', t) else u''

    def de_numero(self, numero):
        """Código de especialidad de un número de lámina ('IE-01' -> 'IE'). Prefiere el código más largo."""
        numero = _u(numero).strip().upper()
        if not numero:
            return u''
        mejor = u''
        for c in self.codigos():
            if numero.startswith(c):
                resto = numero[len(c):]
                if (not resto or not resto[0].isalpha()) and len(c) > len(mejor):
                    mejor = c
        if mejor:
            return mejor
        m = re.match(u'^([A-ZÑ]+)(?![A-ZÑ])', numero)
        return m.group(1) if m else u''


def separar_numero(numero, separador=u'-'):
    """'IE-05' -> ('IE', 5, 2); 'E-101A' -> ('E', 101, 3); '1001' -> ('', 1001, 4). Sin número: (texto, None, 0)."""
    numero = _u(numero).strip()
    m = re.match(u'^(.*?)(\\d+)([^\\d]*)$', numero)
    if not m:
        return numero, None, 0
    prefijo = m.group(1)
    if separador and prefijo.endswith(separador):
        prefijo = prefijo[:-len(separador)]
    prefijo = prefijo.rstrip(u' -_.')
    return prefijo, int(m.group(2)), len(m.group(2))


def formatear_numero(prefijo, n, digitos=2, separador=u'-'):
    prefijo = _u(prefijo).strip()
    cuerpo = _u(str(int(n))).zfill(max(1, int(digitos)))
    return u'%s%s%s' % (prefijo, separador if prefijo else u'', cuerpo)


# parámetros incorporados de la Información del proyecto: nombre del parámetro de Revit (BuiltInParameter) y
# nombres aceptados en el Excel (normalizados), en español (Revit en español usa «Nombre de proyecto») e inglés
ALIAS_PROYECTO = [
    (u'PROJECT_NAME', [u'nombredelproyecto', u'nombredeproyecto', u'proyecto', u'nombreproyecto', u'projectname']),
    (u'PROJECT_NUMBER', [u'numerodelproyecto', u'numerodeproyecto', u'codigodelproyecto', u'numeroproyecto',
                         u'projectnumber']),
    (u'CLIENT_NAME', [u'nombredelcliente', u'nombredecliente', u'cliente', u'entidad', u'propietario', u'clientname']),
    (u'PROJECT_ADDRESS', [u'direcciondelproyecto', u'direcciondeproyecto', u'direccion', u'ubicacion',
                          u'projectaddress']),
    (u'PROJECT_STATUS', [u'estadodelproyecto', u'estadodeproyecto', u'estado', u'projectstatus']),
    (u'PROJECT_ISSUE_DATE', [u'fechadeemisiondelproyecto', u'fechadeemisiondeproyecto', u'projectissuedate']),
    (u'PROJECT_ORGANIZATION_NAME', [u'nombredelaorganizacion', u'nombredeorganizacion', u'organizacion',
                                    u'organizationname']),
    (u'PROJECT_ORGANIZATION_DESCRIPTION', [u'descripciondelaorganizacion', u'descripciondeorganizacion',
                                           u'organizationdescription']),
    (u'PROJECT_BUILDING_NAME', [u'nombredeledificio', u'edificio', u'buildingname']),
    (u'PROJECT_AUTHOR', [u'autor', u'author']),
]

ALIAS_LAMINA = [
    (u'SHEET_DRAWN_BY', [u'dibujadopor', u'dibujo', u'dibujante', u'drawnby', u'cad']),
    (u'SHEET_CHECKED_BY', [u'comprobadopor', u'revisadopor', u'reviso', u'revisor', u'checkedby']),
    (u'SHEET_DESIGNED_BY', [u'disenadopor', u'diseno', u'disenador', u'proyectista', u'designedby']),
    (u'SHEET_APPROVED_BY', [u'aprobadopor', u'aprobo', u'approvedby']),
    (u'SHEET_ISSUE_DATE', [u'fechadeemision', u'fechadeemisiondehoja', u'fechadeemisiondelahoja', u'fecha',
                           u'fechadelamina', u'sheetissuedate']),
]


def clave_alias(nombre, tabla):
    """BuiltInParameter (texto) al que corresponde un nombre de columna, o ''."""
    n = normalizar(nombre)
    for clave, alias in tabla:
        if n in alias:
            return clave
    return u''


# ============================================================================ nombres de archivo

PATRONES_ARCHIVO = [
    u'{Numero}',
    u'{Numero} - {Nombre}',
    u'{NumeroProyecto}_{Numero}',
    u'{Numero}_{Revision}',
    u'{NumeroProyecto}_{Numero} - {Nombre}',
]

CAMPOS_PATRON = [
    (u'Numero', u'Número de la lámina (E-01)'),
    (u'Nombre', u'Nombre de la lámina'),
    (u'Codigo', u'Código de la especialidad (E, IE, IS…)'),
    (u'Especialidad', u'Nombre de la especialidad'),
    (u'Revision', u'Revisión actual de la lámina'),
    (u'FechaRevision', u'Fecha de la revisión actual'),
    (u'Proyecto', u'Nombre del proyecto'),
    (u'NumeroProyecto', u'Número o código del proyecto'),
    (u'Cliente', u'Cliente o entidad'),
    (u'Fecha', u'Fecha de hoy (aaaa-mm-dd)'),
]

_INVALIDOS = re.compile(u'[<>:"/\\\\|?*\x00-\x1f]')
_RESERVADOS = set([u'CON', u'PRN', u'AUX', u'NUL'] + [u'COM%d' % i for i in range(1, 10)] +
                  [u'LPT%d' % i for i in range(1, 10)])


def limpiar_nombre_archivo(nombre, maximo=150):
    nombre = _INVALIDOS.sub(u'_', _u(nombre))
    nombre = re.sub(u'\\s+', u' ', nombre).strip().rstrip(u'.').strip()
    if nombre.upper() in _RESERVADOS:
        nombre = u'_' + nombre
    if len(nombre) > maximo:
        nombre = nombre[:maximo].rstrip(u' ._-')
    return nombre or u'Lamina'


def aplicar_patron(patron, datos):
    """Reemplaza {Campo} por su valor (sin distinguir mayúsculas ni tildes); quita separadores sobrantes."""
    datos_n = dict((normalizar(k), _u(v)) for k, v in datos.items())

    def repl(m):
        return datos_n.get(normalizar(m.group(1)), u'')

    texto = re.sub(u'\\{([^{}]+)\\}', repl, _u(patron))
    texto = re.sub(u'(\\s*-\\s*){2,}', u' - ', texto)
    texto = re.sub(u'_{2,}', u'_', texto)
    texto = re.sub(u'_\\s*-\\s*|\\s*-\\s*_', u'_', texto)
    texto = texto.strip(u' -_.')
    return limpiar_nombre_archivo(texto)


def nombres_unicos(nombres):
    """Agrega ' (2)', ' (3)'… a los nombres repetidos (sin distinguir mayúsculas)."""
    vistos = {}
    res = []
    for n in nombres:
        clave = n.lower()
        if clave in vistos:
            vistos[clave] += 1
            nuevo = u'%s (%d)' % (n, vistos[clave])
            while nuevo.lower() in vistos:
                vistos[clave] += 1
                nuevo = u'%s (%d)' % (n, vistos[clave])
            vistos[nuevo.lower()] = 1
            res.append(nuevo)
        else:
            vistos[clave] = 1
            res.append(n)
    return res


# ============================================================================ Excel de láminas

# columnas fijas de la hoja LÁMINAS (clave interna, encabezado de la plantilla, alias normalizados)
COLUMNAS = [
    (u'orden', u'N.º', [u'n', u'no', u'nro', u'ndeorden', u'orden']),
    (u'especialidad', u'Especialidad', [u'especialidad', u'codigodeespecialidad', u'disciplina']),
    (u'numero', u'Número de lámina', [u'numerodelamina', u'numero', u'numerodehoja', u'nlamina', u'nodelamina',
                                       u'codigodelamina', u'sheetnumber', u'numerodeplano']),
    (u'nombre', u'Nombre de lámina', [u'nombredelamina', u'nombre', u'nombredehoja', u'titulodelamina',
                                       u'sheetname', u'nombredelplano']),
    (u'rotulo', u'Rótulo (familia : tipo)', [u'rotulofamiliatipo', u'rotulo', u'titleblock']),
    (u'vistas', u'Vistas a colocar', [u'vistasacolocar', u'vistas', u'views']),
    (u'uid', u'Id Revit (no editar)', [u'idrevitnoeditar', u'idrevit', u'uniqueid']),
]

# Un parámetro cuyo nombre coincide con una columna fija (p. ej. «Especialidad» del rótulo) va con este prefijo
PREFIJO_PARAMETRO = u'Parámetro: '


def nombre_parametro(encabezado):
    """'Parámetro: Especialidad' -> 'Especialidad'; None si no es una columna de parámetro con prefijo."""
    texto = _u(encabezado).strip()
    if u':' in texto and normalizar(texto.split(u':', 1)[0]) in (u'parametro', u'param'):
        return texto.split(u':', 1)[1].strip()
    return None


def encabezado_parametro(nombre):
    """Encabezado de la columna de un parámetro: con prefijo si chocaría con una columna fija."""
    return (PREFIJO_PARAMETRO + nombre) if clave_columna(nombre) else nombre


CLAVE_BORRAR = u'(borrar)'

# caracteres que Revit no admite en el número ni en el nombre de una lámina
PROHIBIDOS_NUMERO = u'{}[]|;<>?`~'
PROHIBIDOS_NOMBRE = u'\\:{}[]|;<>?`~'


def caracteres_prohibidos(texto, prohibidos):
    return u''.join(sorted(set(c for c in _u(texto) if c in prohibidos)))


def clave_columna(encabezado):
    n = normalizar(encabezado)
    if not n or nombre_parametro(encabezado) is not None:
        return None
    for clave, _, alias in COLUMNAS:
        if n in [normalizar(a) for a in alias]:
            return clave
    return None


def buscar_hoja(hojas, nombres):
    objetivos = [normalizar(n) for n in nombres]
    for h in hojas:
        if normalizar(h.nombre) in objetivos:
            return h
    return None


class FilaExcel(object):
    def __init__(self, fila):
        self.fila = fila            # número de fila en Excel (base 1)
        self.especialidad = u''
        self.numero = u''
        self.nombre = u''
        self.rotulo = u''
        self.vistas = []
        self.uid = u''
        self.parametros = []        # [(nombre, valor_texto)] en el orden del Excel

    def vacia(self):
        return not (self.numero or self.nombre or self.uid)


# ============================================================================ etapa 5C: vistas por su nivel

def _palabras(texto):
    return [p for p in (normalizar(w) for w in re.split(u'\\s+', _u(texto).strip())) if p]


def sin_etiqueta(texto):
    """'(a) NFZ' → 'NFZ' (la letra entre paréntesis que algunas plantillas ponen delante del nivel)."""
    return re.sub(u'^\\([A-Za-z0-9]{1,3}\\)\\s*', u'', _u(texto).strip())


def vistas_por_nivel(texto, nombres):
    """Índices de `nombres` que son la vista pedida con la nomenclatura nueva de niveles de CadRevitALF/CheckerALF:
    número de orden, el código del nivel y su descripción ('(a) NFZ' → '00 NFZ Fondo de zapatas';
    'N1' → '01 N1 Primer Nivel'). Compara palabra por palabra, así 'N1' no toma '11 N10 …'."""
    variantes = []
    for t in (_u(texto).strip(), sin_etiqueta(texto)):
        p = _palabras(t)
        if p and p not in variantes:
            variantes.append(p)
    res = []
    for i, nombre in enumerate(nombres):
        m = re.match(u'^\\d{1,3}\\s+(.+)$', _u(nombre).strip())
        if not m:
            continue
        resto = _palabras(m.group(1))
        if any(resto[:len(v)] == v for v in variantes):
            res.append(i)
    return res


def leer_hoja_laminas(hoja, formato_fecha=u'%d/%m/%Y'):
    """Devuelve (filas, columnas_parametro, avisos). Busca la fila de encabezados en las 15 primeras filas."""
    fila_enc = None
    for i, fila in enumerate(hoja.filas[:15]):
        claves = [clave_columna(v) for v in fila if v is not None]
        if u'numero' in claves and u'nombre' in claves:
            fila_enc = i
            break
    if fila_enc is None:
        raise xlsx.ExcelError(u'En la hoja «%s» no se encontraron las columnas «Número de lámina» y «Nombre de '
                              u'lámina». Use la plantilla de PlanosALF (botón «Plantilla Excel»).' % hoja.nombre)
    encabezados = hoja.filas[fila_enc]
    columnas = {}
    parametros = []
    avisos = []
    for c, v in enumerate(encabezados):
        texto = xlsx.valor_a_texto(v)
        if not texto:
            continue
        clave = clave_columna(texto)
        if clave and clave not in columnas:
            columnas[clave] = c
        elif clave:
            avisos.append(u'La columna «%s» está repetida: se usa la primera (para escribir un parámetro con ese '
                          u'nombre, titule la columna «%s%s»).' % (texto, PREFIJO_PARAMETRO, texto))
        else:
            parametros.append((c, nombre_parametro(texto) or texto))
    filas = []
    for i in range(fila_enc + 1, len(hoja.filas)):
        datos = hoja.filas[i]

        def valor(clave):
            c = columnas.get(clave)
            if c is None or c >= len(datos):
                return u''
            return xlsx.valor_a_texto(datos[c], formato_fecha)

        f = FilaExcel(i + 1)
        f.especialidad = valor(u'especialidad')
        f.numero = valor(u'numero')
        f.nombre = valor(u'nombre')
        f.rotulo = valor(u'rotulo')
        f.uid = valor(u'uid')
        vistas = valor(u'vistas')
        f.vistas = [v.strip() for v in re.split(u'[;\\n]', vistas) if v.strip()]
        for c, nombre in parametros:
            if c < len(datos):
                texto = xlsx.valor_a_texto(datos[c], formato_fecha)
                if texto:
                    f.parametros.append((nombre, texto))
        if f.vacia():
            if f.especialidad and not f.numero and not f.nombre:
                continue  # fila de la plantilla solo con la especialidad elegida
            if any(x is not None and xlsx.valor_a_texto(x) for x in datos):
                if f.parametros or f.rotulo or f.vistas:
                    avisos.append(u'Fila %d: tiene datos pero no tiene número ni nombre de lámina; se omite.' % (i + 1))
            continue
        filas.append(f)
    return filas, [n for _, n in parametros], avisos


def leer_hoja_proyecto(hoja, formato_fecha=u'%d/%m/%Y'):
    """Pares (parámetro, valor) de la hoja PROYECTO: columnas «Parámetro» y «Valor» (debajo de su encabezado)."""
    res = []
    if hoja is None:
        return res
    inicio, c_nom, c_val = 0, 0, 1
    for i, fila in enumerate(hoja.filas[:15]):
        claves = [normalizar(xlsx.valor_a_texto(v)) for v in fila]
        if u'parametro' in claves and u'valor' in claves:
            inicio, c_nom, c_val = i + 1, claves.index(u'parametro'), claves.index(u'valor')
            break
    for fila in hoja.filas[inicio:]:
        if not fila or len(fila) <= max(c_nom, c_val):
            continue
        nombre = xlsx.valor_a_texto(fila[c_nom])
        valor = xlsx.valor_a_texto(fila[c_val], formato_fecha)
        if nombre and valor:
            res.append((nombre, valor))
    return res


def leer_hoja_especialidades(hoja):
    if hoja is None:
        return None
    inicio = 0
    for i, fila in enumerate(hoja.filas[:15]):
        if fila and normalizar(xlsx.valor_a_texto(fila[0])) in (u'codigo', u'prefijo'):
            inicio = i + 1
            break
    pares = []
    for fila in hoja.filas[inicio:]:
        if not fila or len(fila) < 2:
            continue
        codigo = xlsx.valor_a_texto(fila[0])
        nombre = xlsx.valor_a_texto(fila[1])
        if re.match(u'^[A-Za-zÑñ]{1,5}$', codigo):
            pares.append((codigo.upper(), nombre or codigo.upper()))
    return pares or None


# ============================================================================ plan de importación

class Accion(object):
    CREAR = u'Crear'
    ACTUALIZAR = u'Actualizar'
    SIN_CAMBIOS = u'Sin cambios'
    ERROR = u'Error'

    def __init__(self, fila):
        self.fila = fila
        self.tipo = Accion.SIN_CAMBIOS
        self.uid = u''
        self.numero_actual = u''
        self.numero = u''
        self.nombre_actual = u''
        self.nombre = u''
        self.especialidad = u''
        self.cambios = []       # textos 'Nombre: A -> B'
        self.errores = []
        self.avisos = []
        self.aplicar = True

    def resumen(self):
        partes = list(self.errores) + list(self.cambios) + list(self.avisos)
        return u' · '.join(partes)


def por_uid_numero_cambia(existente, filas, asignados):
    """¿La fila que tomó esta lámina por su Id le pone otro número? (entonces su número actual queda libre)."""
    fila = asignados.get(existente[u'uid'])
    for f in filas:
        if f.fila == fila and f.uid == existente[u'uid']:
            return bool(f.numero) and f.numero.upper() != _u(existente[u'numero']).upper()
    return False


def planificar(filas, existentes, especialidades, separador=u'-', digitos=2):
    """Plan de creación/actualización.

    filas: [FilaExcel]
    existentes: [dict(uid=, numero=, nombre=)] láminas del modelo
    Devuelve [Accion] en el orden del Excel. Los cambios de parámetros, rótulo y vistas los agrega revit_ops.
    """
    por_uid = dict((e[u'uid'], e) for e in existentes)
    por_numero = {}
    for e in existentes:
        por_numero.setdefault(_u(e[u'numero']).upper(), e)

    acciones = []
    asignados = {}  # uid de lámina existente -> fila que la toma
    # 1) destino de cada fila: primero por Id Revit (reserva esas láminas) y luego por número entre las libres
    destinos = {}
    for f in filas:
        if f.uid and f.uid in por_uid:
            e = por_uid[f.uid]
            if e[u'uid'] in asignados:
                destinos[id(f)] = (None, u'La lámina %s ya la toma la fila %d' % (e[u'numero'], asignados[e[u'uid']]))
            else:
                asignados[e[u'uid']] = f.fila
                destinos[id(f)] = (e, u'')
    for f in filas:
        a = Accion(f)
        a.especialidad = especialidades.codigo_de_texto(f.especialidad) if f.especialidad else u''
        destino, error = destinos.get(id(f), (None, u''))
        if error:
            a.errores.append(error)
            a.tipo = Accion.ERROR
        elif destino is None:
            if f.uid:
                a.avisos.append(u'El Id Revit no existe en este modelo (¿Excel de otro proyecto?): se busca por número')
            if f.numero:
                e = por_numero.get(f.numero.upper())
                if e is not None:
                    if e[u'uid'] in asignados:
                        if asignados[e[u'uid']] != f.fila and por_uid_numero_cambia(e, filas, asignados):
                            e = None  # su lámina actual cambia de número en otra fila: esta fila es nueva
                        else:
                            a.errores.append(u'La lámina %s ya la toma la fila %d' % (e[u'numero'],
                                                                                     asignados[e[u'uid']]))
                            a.tipo = Accion.ERROR
                            e = None
                    else:
                        asignados[e[u'uid']] = f.fila
                    destino = e
        if destino is not None and a.tipo != Accion.ERROR:
            a.uid = destino[u'uid']
            a.numero_actual = destino[u'numero']
            a.nombre_actual = destino[u'nombre']
        acciones.append(a)

    # 1b) filas sin número ni Id Revit: se reconocen por nombre dentro de su especialidad, para que volver a
    #     importar el mismo Excel no duplique las láminas que se numeraron solas la primera vez.
    for a in acciones:
        f = a.fila
        if a.tipo == Accion.ERROR or a.uid or f.numero or not f.nombre or not a.especialidad:
            continue
        clave = normalizar(f.nombre)
        for e in existentes:
            if e[u'uid'] in asignados:
                continue
            if normalizar(e[u'nombre']) == clave and especialidades.de_numero(e[u'numero']) == a.especialidad:
                asignados[e[u'uid']] = f.fila
                a.uid = e[u'uid']
                a.numero_actual = e[u'numero']
                a.nombre_actual = e[u'nombre']
                a.avisos.append(u'Reconocida por su nombre: lámina %s del modelo' % e[u'numero'])
                break

    # 2) números finales
    ocupados = {}  # NUMERO.upper() -> descripción de quién lo ocupa
    for a in acciones:
        if a.tipo == Accion.ERROR:
            continue
        num = a.fila.numero or a.numero_actual
        if num:
            clave = num.upper()
            if clave in ocupados:
                a.errores.append(u'Número repetido: %s ya está en %s' % (num, ocupados[clave]))
                a.tipo = Accion.ERROR
            else:
                ocupados[clave] = u'la fila %d' % a.fila.fila
                a.numero = num
    for e in existentes:
        if e[u'uid'] not in asignados:
            clave = _u(e[u'numero']).upper()
            if clave in ocupados:
                # una fila quiere un número que tiene otra lámina del modelo que no está en el Excel
                for a in acciones:
                    if a.numero.upper() == clave and a.tipo != Accion.ERROR:
                        a.errores.append(u'Ya existe la lámina %s «%s» en el modelo (no está en el Excel)'
                                         % (e[u'numero'], e[u'nombre']))
                        a.tipo = Accion.ERROR
            ocupados.setdefault(clave, u'el modelo')

    # 3) numeración automática (filas sin número): siguiente número libre de su especialidad
    maximos = {}
    for clave in ocupados:
        pref, n, dig = separar_numero(clave, separador)
        if n is not None:
            k = pref.upper()
            maximos[k] = max(maximos.get(k, 0), n)
    for a in acciones:
        if a.tipo == Accion.ERROR or a.numero:
            continue
        if not a.especialidad:
            a.errores.append(u'Sin número de lámina: escriba el número o la especialidad para numerarla sola')
            a.tipo = Accion.ERROR
            continue
        n = maximos.get(a.especialidad, 0) + 1
        nuevo = formatear_numero(a.especialidad, n, digitos, separador)
        while nuevo.upper() in ocupados:
            n += 1
            nuevo = formatear_numero(a.especialidad, n, digitos, separador)
        maximos[a.especialidad] = n
        ocupados[nuevo.upper()] = u'la fila %d' % a.fila.fila
        a.numero = nuevo
        a.avisos.append(u'Número asignado: %s' % nuevo)

    # 4) tipo de acción y cambios de número/nombre
    for a in acciones:
        if a.tipo == Accion.ERROR:
            continue
        malos = caracteres_prohibidos(a.numero, PROHIBIDOS_NUMERO)
        malos_nombre = caracteres_prohibidos(a.fila.nombre, PROHIBIDOS_NOMBRE)
        if malos or malos_nombre:
            if malos:
                a.errores.append(u'El número tiene caracteres que Revit no admite: %s' % u' '.join(malos))
            if malos_nombre:
                a.errores.append(u'El nombre tiene caracteres que Revit no admite: %s' % u' '.join(malos_nombre))
            a.tipo = Accion.ERROR
            continue
        if not a.especialidad:
            a.especialidad = especialidades.de_numero(a.numero)
        elif especialidades.de_numero(a.numero) and especialidades.de_numero(a.numero) != a.especialidad:
            a.avisos.append(u'El número %s no empieza con el código de la especialidad %s' % (a.numero, a.especialidad))
        if not a.uid:
            a.tipo = Accion.CREAR
            a.nombre = a.fila.nombre
            if not a.nombre:
                a.errores.append(u'Falta el nombre de la lámina')
                a.tipo = Accion.ERROR
            continue
        a.nombre = a.fila.nombre or a.nombre_actual
        if a.numero != a.numero_actual:
            a.cambios.append(u'Número: %s → %s' % (a.numero_actual, a.numero))
        if a.nombre != a.nombre_actual:
            a.cambios.append(u'Nombre: «%s» → «%s»' % (a.nombre_actual, a.nombre))
        a.tipo = Accion.ACTUALIZAR if a.cambios else Accion.SIN_CAMBIOS
    return acciones


# ============================================================================ renumeración

def planificar_renumeracion(seleccion, todos, inicio=1, incremento=1, digitos=2, separador=u'-',
                            prefijo=None, especialidades=None):
    """Nuevos números para las láminas seleccionadas (en el orden dado).

    seleccion: [(uid, numero_actual)] en el orden final deseado.
    todos: [(uid, numero)] todas las láminas del modelo.
    prefijo: texto (p. ej. 'IE') para usar uno solo; None = conservar la especialidad de cada lámina y numerar
             cada especialidad por separado desde 'inicio'.
    Devuelve (cambios [(uid, actual, nuevo)], errores [texto]).
    """
    if especialidades is None:
        especialidades = Especialidades()
    contadores = {}
    cambios = []
    for uid, actual in seleccion:
        if prefijo is None:
            pref = especialidades.de_numero(actual)
            if not pref:
                pref, _, _ = separar_numero(actual, separador)
        else:
            pref = _u(prefijo).strip().upper()
        clave = pref.upper()
        n = contadores.get(clave, int(inicio))
        contadores[clave] = n + int(incremento)
        cambios.append((uid, actual, formatear_numero(pref, n, digitos, separador)))
    errores = []
    malos = caracteres_prohibidos(u'%s%s' % (prefijo or u'', separador), PROHIBIDOS_NUMERO)
    if malos:
        errores.append(u'El prefijo o el separador tienen caracteres que Revit no admite: %s' % u' '.join(malos))
    elegidos = set(uid for uid, _ in seleccion)
    otros = dict((_u(num).upper(), num) for uid, num in todos if uid not in elegidos)
    vistos = {}
    for uid, actual, nuevo in cambios:
        clave = nuevo.upper()
        if clave in otros:
            errores.append(u'%s → %s: ese número ya lo tiene otra lámina que no está seleccionada (%s)'
                           % (actual, nuevo, otros[clave]))
        if clave in vistos:
            errores.append(u'%s → %s: número repetido en la selección' % (actual, nuevo))
        vistos[clave] = uid
    return cambios, errores


# ============================================================================ índice de planos

def agrupar_por_especialidad(laminas, especialidades):
    """laminas: [dict(numero=, nombre=, ...)] -> [(codigo, nombre_especialidad, [laminas ordenadas])]."""
    grupos = {}
    for l in laminas:
        cod = especialidades.de_numero(l[u'numero'])
        grupos.setdefault(cod, []).append(l)
    res = []
    for cod in sorted(grupos, key=lambda c: (especialidades.orden(c), c)):
        lista = sorted(grupos[cod], key=lambda l: clave_natural(l[u'numero']))
        res.append((cod, especialidades.nombre(cod) or (u'Láminas %s' % cod if cod else u'Otras láminas'), lista))
    return res


# ============================================================================ plan de exportación (PDF / DWG)

def subcarpeta_especialidad(codigo, especialidades, con_subcarpetas=True):
    """«E - Estructuras» (o «» sin subcarpetas o sin prefijo)."""
    if not con_subcarpetas or not codigo:
        return u''
    return limpiar_nombre_archivo(u'%s - %s' % (codigo, especialidades.nombre(codigo) or u'Láminas'))


def plan_exportacion(items, uids_elegidos, opciones, especialidades, base=u''):
    """Archivos de una exportación.

    items: TODAS las láminas exportables, en orden: [dict(uid, numero, codigo, datos_patron)].
    uids_elegidos: las que se exportan ahora. opciones: dict(pdf, dwg, subcarpetas, modo_pdf, patron_archivo).
    base: base del nombre de los PDF combinados («V16» → «V16_Planos», «V16_E - Estructuras»).

    Devuelve (tareas, esperados):
    - tareas: [(tipo, [items], subcarpeta, nombre sin extensión)] solo de las elegidas;
    - esperados: {uid: {'PDF': ruta relativa, 'DWG': ruta relativa}} de TODAS (para el índice acumulativo: una
      lámina exportada antes sigue en el índice con su archivo si el archivo está en la carpeta).
    Los nombres repetidos se resuelven con todas las láminas, así un archivo se llama igual en cada exportación.
    """
    elegidos = set(uids_elegidos)
    con_sub = bool(opciones.get(u'subcarpetas', True))
    patron = opciones.get(u'patron_archivo') or u'{Numero}'
    base = _u(base).strip()

    def con_base(sufijo):
        if base and not sufijo.lower().startswith(base.lower()):
            return limpiar_nombre_archivo(u'%s_%s' % (base, sufijo), 150)
        return limpiar_nombre_archivo(sufijo, 150)

    nombres = {}
    por_carpeta = {}
    for i in items:
        por_carpeta.setdefault(subcarpeta_especialidad(i[u'codigo'], especialidades, con_sub), []).append(i)
    for sub, lista in por_carpeta.items():
        unicos = nombres_unicos([aplicar_patron(patron, i[u'datos_patron']) for i in lista])
        for i, n in zip(lista, unicos):
            nombres[i[u'uid']] = n

    def rel(sub, nombre, ext):
        return (sub + u'\\' if sub else u'') + nombre + ext

    tareas = []
    esperados = dict((i[u'uid'], {}) for i in items)
    sel = [i for i in items if i[u'uid'] in elegidos]
    if opciones.get(u'pdf'):
        modo = opciones.get(u'modo_pdf')
        if modo == u'especialidad':
            grupos = []
            for i in items:
                if not grupos or grupos[-1][0] != i[u'codigo']:
                    grupos.append((i[u'codigo'], []))
                grupos[-1][1].append(i)
            for cod, lista in grupos:
                n = con_base((u'%s - %s' % (cod, especialidades.nombre(cod))) if cod else u'Otras láminas')
                sub = subcarpeta_especialidad(cod, especialidades, con_sub)
                for i in lista:
                    esperados[i[u'uid']][u'PDF'] = rel(sub, n, u'.pdf')
                lista_sel = [i for i in lista if i[u'uid'] in elegidos]
                if lista_sel:
                    tareas.append((u'PDF', lista_sel, sub, n))
        elif modo == u'uno':
            n = con_base(u'Planos')
            for i in sel:
                esperados[i[u'uid']][u'PDF'] = rel(u'', n, u'.pdf')
            if sel:
                tareas.append((u'PDF', sel, u'', n))
        else:
            for i in items:
                sub = subcarpeta_especialidad(i[u'codigo'], especialidades, con_sub)
                esperados[i[u'uid']][u'PDF'] = rel(sub, nombres[i[u'uid']], u'.pdf')
                if i[u'uid'] in elegidos:
                    tareas.append((u'PDF', [i], sub, nombres[i[u'uid']]))
    if opciones.get(u'dwg'):
        for i in items:
            sub = subcarpeta_especialidad(i[u'codigo'], especialidades, con_sub)
            esperados[i[u'uid']][u'DWG'] = rel(sub, nombres[i[u'uid']], u'.dwg')
            if i[u'uid'] in elegidos:
                tareas.append((u'DWG', [i], sub, nombres[i[u'uid']]))
    return tareas, esperados


# ============================================================================ ficha del proyecto → Información del proyecto

def valores_ficha(ficha, archivo=None):
    """{BuiltInParameter: valor} que la ficha «.alfproyecto» da a la Información del proyecto (solo los que tiene)."""
    if ficha is None:
        return {}
    pares = [(u'PROJECT_NAME', ficha.nombre_o(archivo) if _u(ficha.nombre).strip() else u''),
             (u'PROJECT_NUMBER', _u(ficha.codigo).strip() or _u(ficha.cui).strip()),
             (u'CLIENT_NAME', ficha.entidad),
             (u'PROJECT_ADDRESS', ficha.ubicacion_texto()),
             (u'PROJECT_AUTHOR', ficha.proyectista_texto()),
             (u'PROJECT_ORGANIZATION_NAME', ficha.organizacion),
             (u'PROJECT_ISSUE_DATE', ficha.fecha)]
    from planosalf import alf_salidas
    return dict((b, _u(v).strip()) for b, v in pares
                if _u(v).strip() and not alf_salidas.es_texto_de_ejemplo(v))


def completar_info_con_ficha(info, valores):
    """info: [(nombre, valor, bip)] de la Información del proyecto. Los vacíos (o con texto de ejemplo) se llenan
    con los datos de la ficha; así la hoja PROYECTO del Excel lleva los datos de la ficha para el rótulo."""
    from planosalf import alf_salidas
    res = []
    usados = set()
    for x in info or []:
        x = tuple(x) + (u'',) * (3 - len(x))
        nombre, valor, clave = x[0], x[1], x[2]
        if clave in valores and (not _u(valor).strip() or alf_salidas.es_texto_de_ejemplo(valor)):
            valor = valores[clave]
        if clave:
            usados.add(clave)
        res.append((nombre, valor, clave))
    return res


# ============================================================================ etapa 5A: carpeta de exportación del proyecto

CARPETA_PLANOS = u'Planos PDF-DWG'
CARPETA_IMAGENES = u'_imagenes'          # imágenes que Revit escribe con los DWG (logos del rótulo, fotos)
EXTENSIONES_IMAGEN = (u'.png', u'.jpg', u'.jpeg', u'.bmp', u'.tif', u'.tiff', u'.gif')


def es_carpeta_de_planos(nombre):
    """«11_Planos», «Planos PDF-DWG», «PLANOS» → True (sin importar números de orden, tildes ni mayúsculas).
    «00_PLANOS_CAD» (los planos de AutoCAD de partida) → False."""
    n = re.sub(u'^\\d+', u'', normalizar(nombre))
    return n.startswith(u'planos') and u'cad' not in n


def clave_proyecto(raiz):
    """Clave con la que se recuerda la carpeta de exportación de cada proyecto (carpeta de la ficha o del modelo)."""
    import os
    if not raiz:
        return u''
    try:
        return _u(os.path.normcase(os.path.abspath(_u(raiz)))).rstrip(u'\\/')
    except Exception:
        return _u(raiz)


def carpeta_exportacion_defecto(raiz, recordada=u'', ultima=u''):
    """Carpeta donde se proponen los PDF/DWG y el índice. Nunca la de otra obra:

    1) la última usada EN ESTE proyecto (si todavía existe);
    2) la última usada en general, solo si está dentro de la carpeta de este proyecto;
    3) una subcarpeta de planos del proyecto que ya exista («11_Planos», «Planos PDF-DWG»);
    4) «<carpeta del proyecto>\\Planos PDF-DWG» (se crea al exportar)."""
    import os
    from planosalf import alf_salidas
    raiz = _u(raiz)
    if recordada and os.path.isdir(_u(recordada)):
        return _u(recordada)
    if ultima and os.path.isdir(_u(ultima)) and alf_salidas.dentro_de(_u(ultima), raiz):
        return _u(ultima)
    try:
        subs = sorted(_u(d) for d in os.listdir(raiz) if os.path.isdir(os.path.join(raiz, d)) and
                      es_carpeta_de_planos(d))
    except Exception:
        subs = []
    if subs:
        def prioridad(d):
            n = re.sub(u'^\\d+', u'', normalizar(d))
            return (0 if normalizar(d) == normalizar(CARPETA_PLANOS) else 1 if n == u'planos' else 2, d)
        return os.path.join(raiz, sorted(subs, key=prioridad)[0])
    return os.path.join(raiz, CARPETA_PLANOS)


def recordar_proyecto(cfg, raiz, **datos):
    """Guarda en la configuración datos de UN proyecto (carpeta de exportación, especialidades del Excel)."""
    import datetime
    clave = clave_proyecto(raiz)
    if not clave:
        return
    proyectos = dict(cfg.get(u'proyectos') or {})
    p = dict(proyectos.get(clave) or {})
    p.update(datos)
    p[u'usado'] = datetime.datetime.now().strftime(u'%Y-%m-%d %H:%M:%S')
    proyectos[clave] = p
    if len(proyectos) > 40:   # solo los 40 proyectos usados más recientemente
        orden = sorted(proyectos, key=lambda k: _u((proyectos[k] or {}).get(u'usado', u'')), reverse=True)
        proyectos = dict((k, proyectos[k]) for k in orden[:40])
    cfg[u'proyectos'] = proyectos


def datos_proyecto(cfg, raiz):
    return dict((cfg.get(u'proyectos') or {}).get(clave_proyecto(raiz)) or {})


# ============================================================================ etapa 5A: índice acumulativo

def _clave_numero(numero):
    return _u(numero).strip().upper()


def leer_indice(hojas):
    """Filas de un índice de planos de PlanosALF ya guardado (para fusionarlo con la exportación nueva).

    hojas: [xlsx.Hoja]. Devuelve [dict(numero, nombre, revision, fecha_revision, archivos={PDF, DWG}, origen, uid)].
    La hoja oculta ORIGEN dice de qué modelo salió cada lámina (índices de la 1.2.0 en adelante)."""
    h = buscar_hoja(hojas, [u'ÍNDICE DE PLANOS', u'INDICE DE PLANOS', u'Índice'])
    if h is None:
        visibles = [x for x in hojas if not getattr(x, u'oculta', False)]
        h = visibles[0] if visibles else None
    if h is None:
        return []
    columnas = {u'lamina': u'numero', u'numerodelamina': u'numero', u'nombredelalamina': u'nombre',
                u'nombredelamina': u'nombre', u'revision': u'revision', u'fechaderevision': u'fecha_revision',
                u'archivopdf': u'PDF', u'archivodwg': u'DWG'}
    fila_enc, mapa = None, {}
    for i, fila in enumerate(h.filas[:30]):
        m = {}
        for c, v in enumerate(fila):
            clave = columnas.get(normalizar(xlsx.valor_a_texto(v)))
            if clave and clave not in m:
                m[clave] = c
        if u'numero' in m and u'nombre' in m:
            fila_enc, mapa = i, m
            break
    if fila_enc is None:
        return []
    origen = {}
    ho = buscar_hoja(hojas, [u'ORIGEN'])
    if ho is not None:
        for fila in ho.filas[1:]:
            vals = [xlsx.valor_a_texto(v) for v in fila] + [u'', u'', u'']
            if vals[0]:
                origen[_clave_numero(vals[0])] = (vals[1], vals[2])
    res = []
    for fila in h.filas[fila_enc + 1:]:
        def val(clave):
            c = mapa.get(clave)
            return xlsx.valor_a_texto(fila[c]) if c is not None and c < len(fila) else u''
        numero = val(u'numero')
        if not numero:
            continue    # títulos de especialidad, total y pie
        o, uid = origen.get(_clave_numero(numero), (u'', u''))
        archivos = {}
        for t in (u'PDF', u'DWG'):
            if val(t):
                archivos[t] = val(t)
        res.append(dict(numero=numero, nombre=val(u'nombre'), revision=val(u'revision'),
                        fecha_revision=val(u'fecha_revision'), archivos=archivos, origen=o, uid=uid))
    return res


def fusionar_indice(actuales, previos, origenes_actuales=()):
    """Índice acumulativo de un expediente con varios modelos (ARQ, EST, IISS, IIEE…).

    actuales: láminas de los modelos que se leen ahora (el modelo abierto primero, luego sus vínculos), cada una con
              «origen» (nombre del modelo) y «uid».
    previos:  láminas del índice que ya estaba en la carpeta (leer_indice).
    Gana siempre lo actual. De lo anterior queda lo que NO es de los modelos leídos ahora (si una lámina se borró o
    se renumeró en el modelo, su fila vieja se va) y cuyo número no se repite. El orden lo da después
    agrupar_por_especialidad (orden de la hoja ESPECIALIDADES)."""
    res, numeros, uids = [], set(), set()
    for f in actuales:
        k = _clave_numero(f.get(u'numero'))
        if not k or k in numeros:
            continue
        numeros.add(k)
        if f.get(u'uid'):
            uids.add(f[u'uid'])
        res.append(f)
    origenes = set(normalizar(o) for o in origenes_actuales if normalizar(o))
    for f in previos:
        k = _clave_numero(f.get(u'numero'))
        if not k or k in numeros:
            continue
        if f.get(u'uid') and f[u'uid'] in uids:
            continue
        if f.get(u'origen') and normalizar(f[u'origen']) in origenes:
            continue
        numeros.add(k)
        res.append(f)
    return res


def columnas_de_archivo(filas, pedidas=()):
    """Columnas «Archivo PDF/DWG» del índice: las de esta exportación y las que ya traía el índice anterior."""
    cols = [c for c in (u'PDF', u'DWG') if c in pedidas]
    for f in filas:
        for c in (u'PDF', u'DWG'):
            if c not in cols and (f.get(u'archivos') or {}).get(c):
                cols.append(c)
    return [c for c in (u'PDF', u'DWG') if c in cols]


# ============================================================================ etapa 5A: vistas en láminas nuevas

TAMANOS_ISO_MM = {u'A0': (1189.0, 841.0), u'A1': (841.0, 594.0), u'A2': (594.0, 420.0), u'A3': (420.0, 297.0),
                  u'A4': (297.0, 210.0)}


def tamano_iso(texto):
    """'ALF_BIM A1 : A1 horizontal' → ('A1', 841, 594) en mm (horizontal); None si no dice A0…A4."""
    m = re.search(u'(?<![A-Za-z0-9])A([0-4])(?![0-9])', _u(texto), re.IGNORECASE)
    if not m:
        return None
    k = u'A' + m.group(1)
    w, h = TAMANOS_ISO_MM[k]
    return k, w, h


def serie_de_rotulo(texto):
    """'ALF_BIM A1 : A1' → 'alfbima#a#': los rótulos de la misma serie solo cambian el tamaño."""
    return normalizar(re.sub(u'(?<![A-Za-z0-9])A[0-4](?![0-9])', u'A#', _u(texto), flags=re.IGNORECASE)) \
        if tamano_iso(texto) else u''


def area_libre(ancho, alto, franja_pct=20.0, margen_pct=3.0, x0=0.0, y0=0.0):
    """Área donde van las vistas: el rótulo menos el margen y la franja del cajetín (a la derecha)."""
    margen = max(0.0, float(margen_pct)) / 100.0 * min(ancho, alto)
    franja = max(0.0, float(franja_pct)) / 100.0 * ancho
    return (x0 + margen, y0 + margen, x0 + ancho - margen - franja, y0 + alto - margen)


def hueco_de(ancho, alto, margen_pct=3.0):
    """Separación mínima entre vistas."""
    return max(0.0, float(margen_pct)) / 100.0 * min(ancho, alto) * 0.6


def _filas(orden, medidas, ancho, hueco):
    filas, actual, usado = [], [], 0.0
    for i in orden:
        w = medidas[i][0]
        necesario = usado + (hueco if actual else 0.0) + w
        if actual and necesario > ancho + 1e-9:
            filas.append(actual)
            actual, necesario = [], w
        actual.append(i)
        usado = necesario
    if actual:
        filas.append(actual)
    return filas


def _medir(filas, medidas, hueco):
    altos = [max(medidas[i][1] for i in f) for f in filas]
    anchos = [sum(medidas[i][0] for i in f) + hueco * (len(f) - 1) for f in filas]
    return altos, anchos


def distribuir(area, medidas, hueco=0.0):
    """Coloca rectángulos (ancho, alto) en filas dentro de `area` (x0, y0, x1, y1).

    El espacio libre se reparte por igual entre las filas y entre las vistas de cada fila, así el conjunto queda
    centrado y distribuido. Si no entran en el orden dado, prueba de la más alta a la más baja.
    Devuelve (centros [(x, y)] en el orden de `medidas`, cabe)."""
    if not medidas:
        return [], True
    x0, y0, x1, y1 = area
    ancho, alto = max(0.0, x1 - x0), max(0.0, y1 - y0)
    ordenes = [list(range(len(medidas)))]
    por_alto = sorted(range(len(medidas)), key=lambda i: (-medidas[i][1], i))
    if por_alto != ordenes[0]:
        ordenes.append(por_alto)
    mejor = None
    for orden in ordenes:
        filas = _filas(orden, medidas, ancho, hueco)
        altos, anchos = _medir(filas, medidas, hueco)
        total = sum(altos) + hueco * (len(filas) - 1)
        exceso = max(total / alto if alto else 99.0, max(anchos) / ancho if ancho else 99.0)
        if mejor is None or exceso < mejor[0] - 1e-9:
            mejor = (exceso, filas, altos, anchos)
        if exceso <= 1.0 + 1e-9:
            break
    exceso, filas, altos, anchos = mejor
    cabe = exceso <= 1.0 + 1e-9
    centros = [None] * len(medidas)
    n = len(filas)
    libre_v = alto - sum(altos)
    if cabe and libre_v >= hueco * (n + 1):
        sep_v = libre_v / (n + 1)
        y = y1 - sep_v
    else:   # justo o no entra: separación mínima, centrado si entra, desde arriba si no
        sep_v = hueco
        total = sum(altos) + hueco * (n - 1)
        y = y1 - max(0.0, (alto - total) / 2.0)
    for f, h_fila, w_fila in zip(filas, altos, anchos):
        libre_h = ancho - sum(medidas[i][0] for i in f)
        if libre_h >= hueco * (len(f) + 1):
            sep_h = libre_h / (len(f) + 1)
            x = x0 + sep_h
        else:
            sep_h = hueco
            # una fila más ancha que el área se sale por la izquierda (fuera de la hoja), nunca sobre el rótulo
            x = x0 + (ancho - w_fila) / 2.0 if w_fila <= ancho else x1 - w_fila
        for i in f:
            w, h = medidas[i]
            centros[i] = (x + w / 2.0, y - h_fila / 2.0)
            x += w + sep_h
        y -= h_fila + sep_v
    return centros, cabe


def caben(ancho, alto, medidas, franja_pct=20.0, margen_pct=3.0):
    return distribuir(area_libre(ancho, alto, franja_pct, margen_pct), medidas,
                      hueco_de(ancho, alto, margen_pct))[1]


def elegir_tamano(candidatos, laminas, franja_pct=20.0, margen_pct=3.0, minimo=None):
    """Un solo tamaño de lámina para toda una especialidad.

    candidatos: [(clave, ancho, alto)] de la misma serie de rótulos (p. ej. ALF_BIM A3…A0).
    laminas: [[(ancho, alto) de cada vista]] de las láminas nuevas de la especialidad.
    minimo: clave del rótulo elegido por el usuario (nunca se propone uno más chico).
    Devuelve (clave, entran_todas). Si no entran ni en el más grande, el más grande."""
    if not candidatos:
        return None, False
    lista = sorted(candidatos, key=lambda c: c[1] * c[2])
    if minimo is not None:
        base = [c for c in lista if c[0] == minimo]
        if base:
            area_min = base[0][1] * base[0][2]
            lista = [c for c in lista if c[1] * c[2] >= area_min - 1e-9]
    for clave, w, h in lista:
        if all(caben(w, h, vistas, franja_pct, margen_pct) for vistas in laminas if vistas):
            return clave, True
    return lista[-1][0], False


def es_imagen(nombre):
    return _u(nombre).lower().endswith(EXTENSIONES_IMAGEN)
