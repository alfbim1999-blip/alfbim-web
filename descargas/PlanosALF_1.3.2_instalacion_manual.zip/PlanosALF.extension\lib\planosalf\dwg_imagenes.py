# -*- coding: utf-8 -*-
"""Etapa 5C: imágenes (logos, fotos) que un DWG exportado por Revit espera encontrar.

Revit no incrusta las imágenes en el DWG: escribe cada una como archivo aparte y el DWG guarda su ruta en un objeto
IMAGEDEF. AutoCAD/DWG TrueView la buscan en esa ruta y, si no está, en la carpeta del DWG. Este módulo lee el DWG
(formato R2004 y posteriores: AC1018 2004, AC1024 2010, AC1027 2013, AC1032 2018; sin librerías), dice qué imágenes
pide y si el archivo está donde se buscará, y copia junto al DWG las que falten.

Corre igual en IronPython 2.7 (pyRevit) y en Python 3 (pruebas y verificación en la PC):
    python dwg_imagenes.py "<carpeta o DWG>" [...]      → lista y código de salida 1 si falta alguna imagen
No depende de los demás módulos de PlanosALF.
"""
from __future__ import print_function, division

import os
import re
import shutil
import sys

try:
    unicode
except NameError:  # Python 3
    unicode = str

VERSIONES = {'AC1018': u'2004', 'AC1024': u'2010', 'AC1027': u'2013', 'AC1032': u'2018'}
OTRAS = {'AC1015': u'2000', 'AC1021': u'2007', 'AC1014': u'R14'}
EXTENSIONES = (u'.png', u'.jpg', u'.jpeg', u'.bmp', u'.tif', u'.tiff', u'.gif')
_NO_RUTA = u'<>"|?*'
# texturas internas de AutoCAD que aparecen en todos los DWG (estilos visuales): no son imágenes del dibujo
_NO_IMAGENES = (u'strokes_ogs.tif',)


class ErrorDwg(Exception):
    pass


# ---------------------------------------------------------------------------- lectura de bajo nivel

def _leer(ruta):
    with open(ruta, 'rb') as f:
        d = f.read()
    try:
        return bytearray(d)
    except TypeError:    # pragma: no cover (IronPython con texto)
        return bytearray([ord(c) for c in d])


def _u32(b, p):
    return b[p] | (b[p + 1] << 8) | (b[p + 2] << 16) | (b[p + 3] << 24)


def _i32(b, p):
    v = _u32(b, p)
    return v - 0x100000000 if v & 0x80000000 else v


def _u64(b, p):
    return _u32(b, p) | (_u32(b, p + 4) << 32)


def _encabezado(b):
    """Los 0x6C bytes cifrados desde 0x80 (generador congruencial con semilla 1)."""
    out = bytearray(0x6C)
    semilla = 1
    for i in range(0x6C):
        semilla = (semilla * 0x343FD + 0x269EC3) & 0xFFFFFFFF
        out[i] = b[0x80 + i] ^ ((semilla >> 16) & 0xFF)
    return out


def descomprimir(d, tam):
    """Descompresión LZ77 de las secciones R2004+ (especificación abierta del formato DWG, §4.7)."""
    d = bytearray(d)
    n = len(d)
    out = bytearray()
    pos = [0]

    def rb():
        v = d[pos[0]]
        pos[0] += 1
        return v

    def litlen():
        x = rb()
        if 1 <= x <= 0x0F:
            return x + 3, 0
        if x == 0:
            t = 0x0F
            x = rb()
            while x == 0:
                t += 0xFF
                x = rb()
            return t + x + 3, 0
        return 0, x

    def largo():
        t = 0
        x = rb()
        if x == 0:
            t = 0xFF
            x = rb()
            while x == 0:
                t += 0xFF
                x = rb()
        return t + x

    def dos():
        a = rb()
        c = rb()
        return (a >> 2) | (c << 6), a & 3

    lit, op = litlen()
    out.extend(d[pos[0]:pos[0] + lit])
    pos[0] += lit
    while pos[0] < n and len(out) < tam:
        if op == 0:
            op = rb()
        if op >= 0x40:
            nb = ((op & 0xF0) >> 4) - 1
            off = (rb() << 2) | ((op & 0x0C) >> 2)
            lit = op & 3
            op = 0
            if not lit:
                lit, op = litlen()
        elif op == 0x11:
            break
        elif 0x10 <= op <= 0x3F:
            if op >= 0x21:
                nb = op - 0x1E
            elif op == 0x20:
                nb = largo() + 0x21
            elif op == 0x10:
                nb = largo() + 9
            else:
                nb = (op & 0x0F) + 2
            off, lit = dos()
            if op <= 0x1F:
                off += 0x3FFF
            op = 0
            if not lit:
                lit, op = litlen()
        else:
            raise ErrorDwg(u'dato comprimido inválido (0x%02x)' % op)
        src = len(out) - off - 1
        if src < 0:
            raise ErrorDwg(u'referencia inválida en la descompresión')
        if off + 1 >= nb:
            out.extend(out[src:src + nb])
        else:
            for i in range(nb):
                out.append(out[src + i])
        out.extend(d[pos[0]:pos[0] + lit])
        pos[0] += lit
    return out[:tam]


def _pagina_sistema(b, dir_):
    dsize, csize, ctipo = _u32(b, dir_ + 4), _u32(b, dir_ + 8), _u32(b, dir_ + 12)
    datos = b[dir_ + 20:dir_ + 20 + csize]
    return descomprimir(datos, dsize) if ctipo == 2 else datos


def secciones(ruta, solo=None):
    """{nombre: bytearray} de las secciones del DWG (solo las pedidas si `solo`). Lanza ErrorDwg si no se puede."""
    b = _leer(ruta)
    version = bytes(b[:6]).decode('ascii', 'replace')
    if version not in VERSIONES:
        raise ErrorDwg(u'formato %s (AutoCAD %s) no se lee: exporte en 2004, 2010, 2013 o 2018'
                       % (version, OTRAS.get(version, u'?')))
    h = _encabezado(b)
    if bytes(h[:11]) != b'AcFssFcAJMB':
        raise ErrorDwg(u'encabezado del DWG no reconocido')
    mapa = _pagina_sistema(b, _u64(h, 0x54) + 0x100)
    id_secciones = _u32(h, 0x5C)
    paginas = {}
    dir_ = 0x100
    i = 0
    while i + 8 <= len(mapa):
        num, tam = _i32(mapa, i), _u32(mapa, i + 4)
        i += 8
        if num < 0:
            i += 16
        else:
            paginas[num] = dir_
        dir_ += tam
    if id_secciones not in paginas:
        raise ErrorDwg(u'mapa de secciones no encontrado')
    sm = _pagina_sistema(b, paginas[id_secciones])
    res = {}
    p = 20
    for _ in range(_i32(sm, 0)):
        tam = _u64(sm, p)
        npag = _i32(sm, p + 8)
        maxd = _u32(sm, p + 12)
        comp = _i32(sm, p + 20)
        nombre = bytes(sm[p + 32:p + 96]).split(b'\0')[0].decode('latin-1')
        p += 96
        trozos = []
        for _ in range(npag):
            trozos.append((_i32(sm, p), _u64(sm, p + 8)))
            p += 16
        if not nombre or (solo and nombre not in solo):
            continue
        out = bytearray(tam)
        for num, inicio in trozos:
            if num not in paginas:
                continue
            a = paginas[num]
            mascara = 0x4164536B ^ (a & 0xFFFFFFFF)
            csize = _u32(b, a + 8) ^ mascara
            datos = b[a + 32:a + 32 + csize]
            dec = descomprimir(datos, maxd) if comp == 2 else datos
            k = min(len(dec), max(0, tam - inicio))
            out[inicio:inicio + k] = dec[:k]
        res[nombre] = out
    return version, res


# ---------------------------------------------------------------------------- textos en el flujo de bits

def _patrones(texto, desplazamiento):
    """Bytes interiores de `texto` (UTF-16LE y 8 bits) empezando `desplazamiento` bits dentro de un byte."""
    res = []
    for cod in ('utf-16-le', 'latin-1'):
        p = bytearray(texto.encode(cod))
        if desplazamiento == 0:
            res.append((cod, p))
        else:
            s = desplazamiento
            res.append((cod, bytearray([((p[k] << (8 - s)) & 0xFF) | (p[k + 1] >> s) for k in range(len(p) - 1)])))
    return res


def _byte_en_bit(b, bit):
    q, s = bit >> 3, bit & 7
    if q < 0 or q >= len(b):
        return None
    if s == 0:
        return b[q]
    if q + 1 >= len(b):
        return None
    return ((b[q] << s) & 0xFF) | (b[q + 1] >> (8 - s))


def buscar_texto(b, texto):
    """[(bit de inicio, codificación)] donde aparece `texto` en el flujo de bits (en cualquier bit)."""
    res = []
    for s in range(8):
        for cod, pat in _patrones(texto, s):
            if not pat:
                continue
            i = b.find(pat)
            while i >= 0:
                res.append(((i - (1 if s else 0)) * 8 + s, cod))
                i = b.find(pat, i + 1)
    return res


def _caracter(b, bit, cod):
    if cod == 'latin-1':
        v = _byte_en_bit(b, bit)
        return v, 8
    lo, hi = _byte_en_bit(b, bit), _byte_en_bit(b, bit + 8)
    if lo is None or hi is None:
        return None, 16
    return lo | (hi << 8), 16


def _ruta_alrededor(b, bit, cod, extension):
    """Texto de ruta que termina con `extension` (que empieza en `bit`): hacia atrás mientras sean caracteres de
    ruta. En UTF-16 (R2007+) usa el largo guardado delante del texto para no tomar basura."""
    paso = 16 if cod != 'latin-1' else 8
    fin = bit + paso * len(extension)
    chars = []
    pos = bit - paso
    candidatos = []
    while len(chars) < 400:
        v, _ = _caracter(b, pos, cod)
        # rutas de Windows con letras latinas (español): un carácter fuera de ese rango ya no es de la ruta
        if v is None or v < 0x20 or v > 0x17F or (0x7F <= v < 0xA0) or unichr_(v) in _NO_RUTA:
            break
        chars.append(unichr_(v))
        pos -= paso
        if cod != 'latin-1':
            largo, _ = _caracter(b, pos, cod)
            n = len(chars) + len(extension)
            if largo in (n, n + 1):
                candidatos.append(len(chars))
    texto = u''.join(reversed(chars)) + extension
    # 1.º desde la unidad (C:\) o la carpeta de red (\\): la última que aparezca (lo de antes es basura o el largo)
    unidades = list(re.finditer(u'[A-Za-z]:[\\\\/]', texto))
    if unidades:
        return texto[unidades[-1].start():], fin
    red = texto.find(u'\\\\')
    if red >= 0:
        return texto[red:], fin
    # 2.º ruta relativa: el largo guardado delante del texto (UTF-16, R2007+); el más largo que coincida
    if candidatos:
        return texto[len(texto) - candidatos[-1] - len(extension):], fin
    return texto, fin


def es_ruta(texto):
    """¿Parece una ruta de archivo? Descarta el NOMBRE del IMAGEDEF que pone Revit («Imagen ráster : logo.png»):
    los dos puntos solo pueden ir en la unidad (C:) y el nombre no puede llevar caracteres prohibidos."""
    t = texto.strip()
    if not t or t != texto:
        return False
    if u':' in (t[2:] if re.match(u'^[A-Za-z]:[\\\\/]', t) else t):
        return False
    nombre = re.split(u'[\\\\/]', t)[-1]
    return bool(nombre) and not any(c in nombre for c in _NO_RUTA)


def unichr_(v):
    try:
        return unichr(v)
    except NameError:   # Python 3
        return chr(v)


def tiene_imagenes(ruta):
    """¿El DWG define imágenes (clase IMAGEDEF)?"""
    _, sec = secciones(ruta, solo=('AcDb:Classes',))
    return bool(buscar_texto(sec.get('AcDb:Classes') or bytearray(), u'IMAGEDEF'))


def rutas_de_imagenes(ruta):
    """Rutas de imagen que guarda el DWG (tal como están: absolutas o relativas a la carpeta del DWG)."""
    version, sec = secciones(ruta, solo=('AcDb:Classes', 'AcDb:AcDbObjects'))
    if not buscar_texto(sec.get('AcDb:Classes') or bytearray(), u'IMAGEDEF'):
        return version, []
    obj = sec.get('AcDb:AcDbObjects') or bytearray()
    vistas = []
    for ext in EXTENSIONES:
        for variante in (ext, ext.upper()):
            for bit, cod in buscar_texto(obj, variante):
                texto, _ = _ruta_alrededor(obj, bit, cod, variante)
                nombre = re.split(u'[\\\\/]', texto)[-1]
                if nombre.lower() in _NO_IMAGENES or not es_ruta(texto):
                    continue
                if len(nombre) > len(variante) and texto not in vistas:
                    vistas.append(texto)
    return version, vistas


def ubicar(ruta_dwg, guardada):
    """(ruta donde AutoCAD la encontrará o None, ruta junto al DWG). Busca en la ruta guardada (absoluta o relativa a
    la carpeta del DWG) y luego en la carpeta del DWG, como AutoCAD."""
    carpeta = os.path.dirname(os.path.abspath(ruta_dwg))
    g = guardada.replace(u'/', os.sep).replace(u'\\', os.sep)
    nombre = re.split(u'[\\\\/]', guardada)[-1]
    junto = os.path.join(carpeta, nombre)
    absoluta = bool(re.match(u'^([A-Za-z]:[\\\\/]|\\\\\\\\)', guardada))
    candidatos = [] if absoluta and os.sep == '/' else [g if absoluta else os.path.normpath(os.path.join(carpeta, g))]
    candidatos.append(junto)
    for c in candidatos:
        if os.path.isfile(c):
            return c, junto
    return None, junto


def revisar(ruta_dwg, buscar_en=(), copiar=True):
    """Revisa las imágenes de un DWG. Las que no están donde se buscarán se copian junto al DWG desde `buscar_en`
    (carpetas donde Revit pudo dejarlas). Devuelve dict(version, imagenes, encontradas, copiadas, faltan, error)."""
    res = dict(dwg=os.path.basename(ruta_dwg), version=u'', imagenes=[], encontradas=0, copiadas=[], faltan=[],
               error=u'')
    try:
        version, rutas = rutas_de_imagenes(ruta_dwg)
    except Exception as ex:   # formato que no se lee: se informa, no se detiene la exportación
        res[u'error'] = unicode(ex)
        return res
    res[u'version'] = VERSIONES.get(version, version)
    res[u'imagenes'] = rutas
    for g in rutas:
        donde, junto = ubicar(ruta_dwg, g)
        if donde:
            res[u'encontradas'] += 1
            continue
        nombre = os.path.basename(junto)
        origen = None
        for c in buscar_en:
            if c and os.path.isfile(os.path.join(c, nombre)):
                origen = os.path.join(c, nombre)
                break
        if origen and copiar:
            shutil.copy2(origen, junto)
            res[u'copiadas'].append(nombre)
            res[u'encontradas'] += 1
        else:
            res[u'faltan'].append(nombre)
    return res


# ---------------------------------------------------------------------------- uso desde la consola

def _dwgs(rutas):
    for r in rutas:
        if os.path.isdir(r):
            for d, _, archivos in os.walk(r):
                for a in sorted(archivos):
                    if a.lower().endswith('.dwg'):
                        yield os.path.join(d, a)
        elif r.lower().endswith('.dwg'):
            yield r


def main(argv=None):
    """--exigir-imagenes: código 1 también si ningún DWG trae imágenes (prueba del logo)."""
    argv = list(sys.argv[1:] if argv is None else argv)
    exigir = u'--exigir-imagenes' in argv
    argv = [a for a in argv if a != u'--exigir-imagenes']
    if not argv:
        print(u'Uso: python dwg_imagenes.py [--exigir-imagenes] <carpeta o DWG> [...]')
        return 2
    total = con = falta = ilegibles = 0
    for ruta in _dwgs(argv):
        total += 1
        r = revisar(ruta, copiar=False)
        rel = os.path.basename(ruta)
        if r[u'error']:
            ilegibles += 1
            print(u'[??] %s: %s' % (rel, r[u'error']))
            continue
        if not r[u'imagenes']:
            print(u'[--] %s (AutoCAD %s): sin imágenes' % (rel, r[u'version']))
            continue
        con += 1
        estado = u'OK' if not r[u'faltan'] else u'FALTA'
        if r[u'faltan']:
            falta += 1
        print(u'[%s] %s (AutoCAD %s): %d imagen(es)' % (estado, rel, r[u'version'], len(r[u'imagenes'])))
        for g in r[u'imagenes']:
            donde, junto = ubicar(ruta, g)
            nombre = re.split(u'[\\\\/]', g)[-1]
            print(u'      %s  ->  %s' % (nombre, u'está' if donde else u'NO ESTÁ junto al DWG ni en su ruta'))
    print(u'DWG revisados: %d · con imágenes: %d · con imágenes que faltan: %d · no leídos: %d'
          % (total, con, falta, ilegibles))
    if exigir and not con:
        print(u'Ningún DWG trae imágenes (se pidió al menos uno con el logo).')
    return 1 if (falta or ilegibles or (exigir and not con)) else 0


if __name__ == '__main__':
    sys.exit(main())
