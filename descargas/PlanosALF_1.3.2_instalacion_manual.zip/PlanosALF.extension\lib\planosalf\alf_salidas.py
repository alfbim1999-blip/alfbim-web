# -*- coding: utf-8 -*-
"""Ficha de proyecto común y regla de salidas de la línea ALF_BIM, para pyRevit (IronPython 2.7 y CPython 3).

Es el equivalente pequeño de `00_ALF_CORE\\python\\alf_core` (ficha.py + salidas.py + los diálogos de qt.py), que no
corre en IronPython 2.7 (usa pathlib, dataclasses, f-strings y anotaciones). Mismas reglas y mismos resultados:
la prueba `tests\\test_salidas_2b.py` compara este módulo con la copia canónica.

- Ficha «.alfproyecto» (JSON UTF-8): buscarla en la carpeta del modelo y en las superiores, leerla y guardarla.
- Nombre propuesto limpio («V16_Índice de planos.xlsx»), carpeta propuesta (la del proyecto), sin rutas de la PC.
- Autor de los metadatos: el proyectista de la ficha o «ALF_BIM».
- Preguntas con botones «Sí» / «No» en español y «¿Abrir el archivo?» antes de abrir nada (solo dentro de Revit).
"""
from __future__ import print_function, division

import io
import json
import os
import re
import sys

try:
    import unicodedata
except ImportError:  # pragma: no cover (algunas versiones de IronPython)
    unicodedata = None

PY3 = sys.version_info[0] >= 3
if PY3:
    text_type = str
else:  # IronPython 2.7
    text_type = unicode  # noqa: F821

FORMATO = u'ALF_BIM.alfproyecto'
VERSION_ESQUEMA = 1
EXTENSION = u'.alfproyecto'
VERSION_NUCLEO = u'1.0.0'   # versión de alf_core con la que se comprobó la equivalencia


def _u(valor):
    if valor is None:
        return u''
    if isinstance(valor, text_type):
        return valor
    if isinstance(valor, bytes):
        try:
            return valor.decode('utf-8')
        except Exception:
            return valor.decode('latin-1')
    try:
        return text_type(valor)
    except Exception:  # pragma: no cover
        return str(valor).decode('utf-8')


# ============================================================================ ficha
_CAMPOS = [
    (u'nombre', u''), (u'codigo', u''), (u'cui', u''), (u'entidad', u''), (u'propietario', u''),
    (u'propietario_reservado', False), (u'departamento', u''), (u'provincia', u''), (u'distrito', u''),
    (u'localidad', u''), (u'altitud_msnm', None), (u'sistema_contratacion', u''), (u'proyectista', u''),
    (u'cip', u''), (u'organizacion', u''), (u'logo', u''), (u'fecha', u''), (u'moneda', u'PEN'),
]
NOMBRES_CAMPOS = [c for c, _ in _CAMPOS]


class Ficha(object):
    """Datos del proyecto. Texto vacío = no se sabe (se usa el nombre del archivo); nunca textos de ejemplo."""

    def __init__(self, **datos):
        for campo, defecto in _CAMPOS:
            setattr(self, campo, datos.get(campo, defecto))
        self.ruta = datos.get(u'ruta')   # dónde se leyó (no se guarda)

    def __repr__(self):
        return u'Ficha(%s, %s)' % (self.codigo, self.nombre)

    # ------------------------------------------------------------------ textos para las salidas
    def ubicacion_texto(self, con_localidad=True):
        partes = [self.localidad if con_localidad else u'', self.distrito, self.provincia, self.departamento]
        return u', '.join(_u(p).strip() for p in partes if _u(p).strip())

    def propietario_texto(self):
        if self.propietario_reservado or es_texto_de_ejemplo(self.propietario):
            return u''
        return _u(self.propietario).strip()

    def proyectista_texto(self):
        n = _u(self.proyectista).strip()
        if not n or es_texto_de_ejemplo(n):
            return u''
        cip = _u(self.cip).strip()
        return u'%s · CIP %s' % (n, cip) if cip else n

    def autor(self):
        n = _u(self.proyectista).strip()
        return n if n and not es_texto_de_ejemplo(n) else u'ALF_BIM'

    def nombre_o(self, archivo):
        if _u(self.nombre).strip() and not es_texto_de_ejemplo(self.nombre):
            return _u(self.nombre).strip()
        return nombre_desde_archivo(archivo)

    def codigo_o(self, archivo):
        if _u(self.codigo).strip() and not es_texto_de_ejemplo(self.codigo):
            return _u(self.codigo).strip()
        return nombre_desde_archivo(archivo)

    def vacia(self):
        return not any(_u(getattr(self, c)).strip() for c in (u'nombre', u'codigo', u'entidad', u'departamento',
                                                               u'proyectista', u'organizacion'))

    # ------------------------------------------------------------------ JSON
    def a_dict(self):
        d = {u'formato': FORMATO, u'version_esquema': VERSION_ESQUEMA}
        for campo, _ in _CAMPOS:
            d[campo] = getattr(self, campo)
        return d

    @classmethod
    def desde_dict(cls, d):
        if not isinstance(d, dict):
            raise ValueError(u'la ficha no es un objeto JSON')
        if d.get(u'formato') not in (None, FORMATO):
            raise ValueError(u'no es una ficha de proyecto ALF_BIM (formato «%s»)' % _u(d.get(u'formato')))
        ver = d.get(u'version_esquema', 1)
        if not isinstance(ver, int) or ver > VERSION_ESQUEMA:
            raise ValueError(u'la ficha es de una versión de esquema más nueva (%s); actualice el programa' % _u(ver))
        f = cls()
        for campo, _ in _CAMPOS:
            if campo not in d:
                continue
            v = d[campo]
            if campo == u'altitud_msnm':
                v = _numero(v)
            elif campo == u'propietario_reservado':
                v = bool(v)
            else:
                v = u'' if v is None else _u(v)
            setattr(f, campo, v)
        return f


_EJEMPLOS = [
    u'\\(nombre\\)', u'\\bnombre del proyecto\\b', u'^\\s*reservado\\s*$', u'\\bde prueba\\b',
    u'^\\s*proyecto\\s*\\d*\\s*$', u'^\\s*sin nombre\\s*$', u'^\\s*\\(?sin t[ií]tulo\\)?\\s*$', u'^\\s*untitled\\s*$',
    u'\\bmetradosalf\\b', u'\\bejemplo\\b', u'^\\s*x+\\s*$', u'^\\s*-+\\s*$', u'^\\s*\\.\\.\\.\\s*$', u'^\\s*n/?a\\s*$',
    u'^\\s*0{3,}\\s*$', u'\\bnombre del propietario\\b', u'\\bcui 0+\\b', u'^\\s*entidad\\s*$', u'^\\s*proyectista\\s*$',
    u'\\(nombre del proyectista\\)',
]
_RX_EJEMPLOS = [re.compile(p, re.IGNORECASE | re.UNICODE) for p in _EJEMPLOS]


def es_texto_de_ejemplo(texto):
    """True si el texto es de relleno («VIVIENDA MULTIFAMILIAR (nombre)», «RESERVADO», «Proyecto1»…)."""
    t = _u(texto).strip()
    if not t:
        return False
    return any(rx.search(t) for rx in _RX_EJEMPLOS)


def _nombre_final(ruta):
    return re.split(u'[\\\\/]', _u(ruta))[-1]


def nombre_desde_archivo(archivo):
    """«…\\V16_ARQ.rvt» → «V16_ARQ» (sin la carpeta); «Proyecto1» → «»."""
    if not archivo:
        return u''
    stem = os.path.splitext(_nombre_final(archivo))[0].strip()
    if re.match(u'(?i)proyecto\\s*\\d*$', stem):
        return u''
    return stem


def _numero(v):
    if v is None or v == u'':
        return None
    try:
        return float(_u(v).replace(u',', u'.').replace(u' ', u''))
    except ValueError:
        return None


def leer(ruta):
    """Lee una ficha. Lanza ValueError (en español) si el archivo no es válido."""
    try:
        with io.open(ruta, 'r', encoding='utf-8-sig') as f:
            texto = f.read()
    except (IOError, OSError) as ex:
        raise ValueError(u'no se pudo leer la ficha «%s» (%s)' % (_nombre_final(ruta), _u(ex)))
    try:
        datos = json.loads(texto)
    except ValueError:
        raise ValueError(u'la ficha «%s» no es un JSON válido' % _nombre_final(ruta))
    f = Ficha.desde_dict(datos)
    f.ruta = _u(ruta)
    return f


def guardar(ficha, ruta):
    """Guarda la ficha (UTF-8 sin BOM, indentada). Devuelve la ruta."""
    ruta = _u(ruta)
    if not ruta.lower().endswith(EXTENSION):
        ruta = os.path.splitext(ruta)[0] + EXTENSION
    carpeta = os.path.dirname(ruta)
    if carpeta and not os.path.isdir(carpeta):
        os.makedirs(carpeta)
    texto = json.dumps(ficha.a_dict(), ensure_ascii=False, indent=2, sort_keys=False)
    tmp = ruta + u'.tmp'
    with io.open(tmp, 'w', encoding='utf-8', newline=u'\n') as f:
        f.write(_u(texto) + u'\n')
    if os.path.exists(ruta):
        os.remove(ruta)
    os.rename(tmp, ruta)
    ficha.ruta = ruta
    return ruta


def _norm(s):
    s = _u(s)
    if unicodedata is not None:
        try:
            s = unicodedata.normalize('NFD', s)
            s = u''.join(c for c in s if unicodedata.category(c) != 'Mn')
        except Exception:
            pass
    return s.lower().strip()


def _carpeta_usuario():
    try:
        return os.path.normcase(os.path.abspath(os.path.expanduser(u'~')))
    except Exception:
        return None


def buscar(desde, niveles=6):
    """La ficha más cercana: en la carpeta `desde` (o la de ese archivo) y en sus superiores (hasta 6 niveles).
    Si hay varias en una carpeta, gana la que se llama como el archivo o como la carpeta; si no, la primera."""
    if not desde:
        return None
    p = _u(desde)
    archivo = p if (os.path.splitext(p)[1] and not os.path.isdir(p)) else None
    carpeta = os.path.dirname(p) if archivo is not None else p
    tope = _carpeta_usuario()
    for _ in range(max(niveles, 1)):
        if os.path.isdir(carpeta):
            try:
                fichas = sorted(x for x in os.listdir(carpeta)
                                if x.lower().endswith(EXTENSION) and os.path.isfile(os.path.join(carpeta, x)))
            except OSError:
                fichas = []
            if fichas:
                preferidos = []
                if archivo:
                    preferidos.append(os.path.splitext(_nombre_final(archivo))[0])
                preferidos.append(_nombre_final(carpeta.rstrip(u'\\/')))
                for pref in preferidos:
                    if pref:
                        for x in fichas:
                            if _norm(os.path.splitext(x)[0]) == _norm(pref):
                                return os.path.join(carpeta, x)
                return os.path.join(carpeta, fichas[0])
        try:
            if tope is not None and os.path.normcase(os.path.abspath(carpeta)) == tope:
                break
        except Exception:
            pass
        c = carpeta.rstrip(u'\\/')
        superior = os.path.dirname(c) if c else carpeta
        if not superior or superior.rstrip(u'\\/') == c:
            break
        carpeta = superior
    return None


def buscar_y_leer(desde, niveles=6):
    r = buscar(desde, niveles)
    if r is None:
        return None
    try:
        return leer(r)
    except ValueError:
        return None


def ficha_o_vacia(desde):
    if desde:
        f = buscar_y_leer(desde)
        if f is not None:
            return f
    return Ficha()


def validar(f):
    """(errores, avisos) en español, como alf_core.ficha.validar (lo esencial)."""
    errores, avisos = [], []
    for k in (u'nombre', u'codigo', u'cui', u'entidad', u'propietario', u'departamento', u'provincia', u'distrito',
              u'localidad', u'proyectista', u'organizacion'):
        t = getattr(f, k)
        if es_texto_de_ejemplo(t):
            errores.append(u'«%s» tiene un texto de ejemplo («%s»): escriba el dato real o déjelo vacío' % (k, t))
    if not _u(f.nombre).strip():
        avisos.append(u'falta el nombre del proyecto: se usará el nombre del archivo')
    for k in (u'departamento', u'provincia', u'distrito'):
        if not _u(getattr(f, k)).strip():
            avisos.append(u'falta el %s de la ubicación' % k)
    if _u(f.proyectista).strip() and not _u(f.cip).strip():
        avisos.append(u'el proyectista no tiene CIP')
    return errores, avisos


# ============================================================================ salidas
_RX_INVALIDOS = re.compile(u'[<>:"/\\\\|?*\x00-\x1f]')
_RX_ESPACIOS = re.compile(u'\\s{2,}', re.UNICODE)
_RESERVADOS = set([u'CON', u'PRN', u'AUX', u'NUL'] + [u'COM%d' % i for i in range(1, 10)] +
                  [u'LPT%d' % i for i in range(1, 10)])

# rutas de Windows (C:\…, C:/…), UNC (\\servidor\…) y de Unix con carpeta de usuario (igual que alf_core.salidas)
_RX_RUTA = re.compile(
    u'(?:(?<![A-Za-z])[A-Za-z]:[\\\\/](?:[^\\\\/:*?"<>|\r\n\t]+[\\\\/])*[^\\\\/:*?"<>|\r\n\t]*)'
    u'|(?:\\\\\\\\[A-Za-z0-9_.$-]+\\\\(?:[^\\\\/:*?"<>|\r\n\t]+\\\\)*[^\\\\/:*?"<>|\r\n\t]*)'
    u'|(?:/(?:home|Users|mnt|tmp)/(?:[^/\\s"\'<>|]+/)*[^/\\s"\'<>|]*)', re.UNICODE)


def limpiar_nombre(nombre):
    """Quita solo lo que Windows no admite. Conserva «.», «×», tildes y espacios."""
    n = _RX_INVALIDOS.sub(u' ', _u(nombre))
    n = _RX_ESPACIOS.sub(u' ', n).strip().rstrip(u'. ')
    if n.upper().split(u'.')[0] in _RESERVADOS:
        n = u'_' + n
    return n


def base_proyecto(ficha, archivo=None):
    """Base de los nombres de archivo: código de la ficha («V16»), si no su nombre, si no el del archivo del
    proyecto; nunca «Proyecto1»; si no hay nada, «ALF_BIM»."""
    candidatos = []
    if ficha is not None:
        candidatos += [ficha.codigo, ficha.nombre]
    candidatos.append(nombre_desde_archivo(archivo))
    for c in candidatos:
        c = _u(c).strip()
        if c and not es_texto_de_ejemplo(c) and not re.match(u'(?i)proyecto\\s*\\d*$', c):
            return limpiar_nombre(c)
    return u'ALF_BIM'


def nombre_archivo(base, sufijo=u'', extension=u''):
    """«V16» + «Memoria» + «.docx» → «V16_Memoria.docx». No repite la base si el sufijo ya la trae."""
    base = limpiar_nombre(base) or u'ALF_BIM'
    sufijo = limpiar_nombre(sufijo)
    ext = extension if not extension or extension.startswith(u'.') else u'.' + extension
    if sufijo and sufijo.lower().startswith(base.lower()):
        nombre = sufijo
    else:
        nombre = u'%s_%s' % (base, sufijo) if sufijo else base
    if ext and nombre.lower().endswith(ext.lower()):
        nombre = nombre[:-len(ext)]
    return nombre + ext


def nombre_propuesto(ficha, sufijo, extension, archivo=None):
    """«V16_Índice de planos.xlsx»."""
    return nombre_archivo(base_proyecto(ficha, archivo), sufijo, extension)


def normalizar_guardado(ruta_elegida, extension, propuesto=None):
    """Arregla lo que devuelve un «Guardar como»: una sola extensión, y si el usuario escribió su nombre pegado al
    propuesto («V16_Índice de planosMi índice»), deja solo lo que escribió."""
    ruta = _u(ruta_elegida)
    carpeta, stem = os.path.split(ruta)
    if u'\\' in stem and u'/' not in ruta:   # ruta de Windows leída fuera de Windows
        carpeta, stem = ruta.rsplit(u'\\', 1)
    ext = extension if extension.startswith(u'.') else u'.' + extension
    while stem.lower().endswith(ext.lower()):
        stem = stem[:-len(ext)]
    if propuesto:
        prop = _nombre_final(propuesto)
        while prop.lower().endswith(ext.lower()):
            prop = prop[:-len(ext)]
        resto = stem[len(prop):] if prop and stem.startswith(prop) else u''
        if resto and resto[0] not in u' _-.(':
            stem = resto
    stem = limpiar_nombre(stem) or u'ALF_BIM'
    return os.path.join(carpeta, stem + ext) if carpeta else stem + ext


def _es_descargas_o_temporal(c):
    import tempfile
    partes = [x.lower() for x in re.split(u'[\\\\/]+', _u(c)) if x]
    if any(x in (u'downloads', u'descargas') or x.startswith(u'_mei') or x == u'content.outlook' for x in partes):
        return True
    if u'appdata' in partes and u'temp' in partes:
        return True
    try:
        r = os.path.normcase(os.path.abspath(c))
        if r == os.path.normcase(os.path.abspath(tempfile.gettempdir())):
            return True
        if r == os.path.normcase(os.path.abspath(os.path.join(os.path.expanduser(u'~'), u'Downloads'))):
            return True
    except Exception:
        pass
    return False


def carpeta_propuesta(ficha=None, archivo_proyecto=None, ultima=None):
    """La carpeta del archivo del proyecto, si no la de la ficha, si no la última usada (si no es Descargas ni
    temporal), si no Documentos."""
    candidatas = []
    if archivo_proyecto:
        a = _u(archivo_proyecto)
        candidatas.append(os.path.dirname(a) if os.path.splitext(a)[1] else a)
    if ficha is not None and getattr(ficha, u'ruta', None):
        candidatas.append(os.path.dirname(_u(ficha.ruta)))
    if ultima:
        candidatas.append(_u(ultima))
    for c in candidatas:
        try:
            if c and os.path.isdir(c) and not _es_descargas_o_temporal(c):
                return c
        except Exception:
            continue
    perfil = os.environ.get('USERPROFILE') or os.path.expanduser(u'~')
    docs = os.path.join(_u(perfil), u'Documents')
    return docs if os.path.isdir(docs) else _u(perfil)


def dentro_de(carpeta, raiz):
    """True si `carpeta` es `raiz` o está dentro de ella."""
    if not carpeta or not raiz:
        return False
    try:
        c = os.path.normcase(os.path.abspath(_u(carpeta))).rstrip(u'\\/')
        r = os.path.normcase(os.path.abspath(_u(raiz))).rstrip(u'\\/')
    except Exception:
        return False
    return c == r or c.startswith(r + os.sep)


def sin_rutas(texto):
    """Cada ruta de la PC → el nombre del archivo o de la carpeta final («C:\\…\\V16.rvt» → «V16.rvt»)."""
    if not texto:
        return texto
    texto = _u(texto)

    def corto(m):
        r = m.group(0).rstrip(u'\\/ .,;:)')
        resto = m.group(0)[len(r):]
        nombre = re.split(u'[\\\\/]', r.rstrip(u'\\/'))[-1]
        return (nombre or u'') + resto
    return _RX_RUTA.sub(corto, texto)


def tiene_rutas(texto):
    return [m.group(0) for m in _RX_RUTA.finditer(_u(texto)) if len(m.group(0)) > 3]


def nombre_corto(ruta):
    """Solo el nombre del archivo o de la carpeta (para mostrar en ventanas, mensajes y registros)."""
    r = _u(ruta).rstrip(u'\\/')
    return _nombre_final(r) or r


def autor(ficha):
    return ficha.autor() if ficha is not None else u'ALF_BIM'


# ============================================================================ diálogos (solo dentro de Revit)
def preguntar(titulo, instruccion, contenido=u''):
    """Pregunta con los botones «Sí» y «No» en español (TaskDialog de Revit). True si eligió «Sí»."""
    try:
        from Autodesk.Revit.UI import TaskDialog, TaskDialogCommandLinkId, TaskDialogResult
    except Exception:  # fuera de Revit (pruebas): no se abre nada
        return False
    td = TaskDialog(_u(titulo) or u'ALF_BIM')
    td.MainInstruction = sin_rutas(_u(instruccion))
    if contenido:
        td.MainContent = sin_rutas(_u(contenido))
    td.AllowCancellation = True
    td.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, u'Sí')
    td.AddCommandLink(TaskDialogCommandLinkId.CommandLink2, u'No')
    return td.Show() == TaskDialogResult.CommandLink1


def abrir(ruta):
    """Abre el archivo o la carpeta con el programa asociado (solo después de que el usuario dijo «Sí»)."""
    try:
        from System.Diagnostics import Process, ProcessStartInfo
        psi = ProcessStartInfo(_u(ruta))
        psi.UseShellExecute = True
        Process.Start(psi)
        return True
    except Exception:
        try:
            os.startfile(ruta)  # noqa
            return True
        except Exception:
            return False


def ofrecer_abrir(ruta, titulo=u'ALF_BIM', detalle=u''):
    """«Se guardó «V16_Índice de planos.xlsx». ¿Abrir el archivo?» Sí / No. Abre solo si dice «Sí»."""
    contenido = (sin_rutas(_u(detalle)) + u'\n\n' if detalle else u'') + u'¿Abrir el archivo?'
    if preguntar(titulo, u'Se guardó «%s».' % nombre_corto(ruta), contenido):
        return abrir(ruta)
    return False


def ofrecer_abrir_carpeta(carpeta, titulo=u'ALF_BIM', detalle=u''):
    """«¿Abrir la carpeta?» Sí / No. Nunca abre el Explorador sin preguntar."""
    contenido = (sin_rutas(_u(detalle)) + u'\n\n' if detalle else u'') + u'¿Abrir la carpeta?'
    if preguntar(titulo, u'Archivos guardados en «%s».' % nombre_corto(carpeta), contenido):
        return abrir(carpeta)
    return False
