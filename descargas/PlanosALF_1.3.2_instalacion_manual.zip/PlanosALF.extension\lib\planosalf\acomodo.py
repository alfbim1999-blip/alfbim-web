# -*- coding: utf-8 -*-
"""Etapa 5C: acomodo automático de las vistas de una lámina nueva que no entran en el área libre del rótulo.

Sin Revit (se prueba con pytest). Revit mide cada vista en la lámina (región de recorte, anotaciones y título) a su
escala y a las escalas normalizadas siguientes; aquí se decide, en este orden:

  1. una lámina más grande de la misma serie de rótulos (ALF_BIM A3 → A2 → A1 → A0) con las mismas escalas;
  2. una escala normalizada menor (1/50 → 1/75 → 1/100 → 1/125…) sin pasar de la que pide la especialidad para que
     el plano se lea (ESCALA_MAXIMA), en la lámina más chica (desde la elegida) donde entren;
  3. repartir las vistas en otra(s) lámina(s) del mismo tamaño (A-04a, A-04b… o el siguiente número libre),
     cada una con sus vistas a la escala original.

Si nada alcanza, se deja como estaba y se avisa qué falta (las vistas nunca se ponen sobre el rótulo).
Las medidas van en cualquier unidad de papel, siempre la misma (pies de papel en Revit, mm en las pruebas).
"""
from __future__ import division

from planosalf import core, xlsx

_u = xlsx._u

# escalas normalizadas (denominador)
ESCALAS = (1, 2, 5, 10, 20, 25, 50, 75, 100, 125, 150, 200, 250, 500, 750, 1000, 1250, 2000, 2500, 5000)

# la escala más chica con la que todavía se lee cada especialidad (no se pasa de ella al achicar)
ESCALA_MAXIMA = {u'U': 500, u'T': 500, u'PP': 500, u'A': 100, u'D': 50, u'E': 75, u'IS': 75, u'ACI': 75,
                 u'IE': 75, u'IM': 75, u'IC': 75, u'GN': 75, u'SE': 100, u'EV': 100, u'EQ': 100, u'*': 100}

NOMBRES_ESPECIALIDAD = dict(core.ESPECIALIDADES_PERU)


def escala_maxima(codigo, tabla=None):
    """Denominador más grande permitido para la especialidad (tabla de la Configuración o ESCALA_MAXIMA)."""
    t = dict(ESCALA_MAXIMA)
    for k, v in (tabla or {}).items():
        try:
            t[_u(k).strip().upper()] = int(v)
        except (TypeError, ValueError):
            pass
    codigo = _u(codigo or u'').strip().upper()
    return t.get(codigo, t.get(u'*', 100))


def escalas_siguientes(actual, maxima):
    """Escalas normalizadas menores que la actual (denominador mayor) sin pasar de `maxima`."""
    try:
        actual = int(actual)
    except (TypeError, ValueError):
        return []
    return [e for e in ESCALAS if actual < e <= int(maxima)]


def texto_escala(e):
    return u'1/%d' % int(e) if e else u'—'


def corto(clave):
    """'ALF_BIM A0 : ALF_BIM A0' → 'ALF_BIM A0'."""
    t = _u(clave)
    return t.split(u' : ')[0] if u' : ' in t else t


class Vista(object):
    """Una vista colocada en la lámina.

    medidas: {escala: (ancho, alto)} medidos en la lámina (Revit) o (ancho, alto) a la escala actual.
    escalable: se le puede cambiar la escala (plantas, cortes, elevaciones, 3D; no tablas ni leyendas, ni vistas cuya
    plantilla controla la escala).
    fijo: alto que no cambia con la escala (título de la vista), para estimar una escala que Revit no midió.
    origen: de dónde salió la medida en Revit (contorno del viewport o bounding box, y por qué), para el aviso de una
    vista que no entra ni sola (etapa 6A)."""

    def __init__(self, nombre, medidas, escala=None, escalable=False, fijo=0.0, origen=u''):
        self.nombre = _u(nombre)
        self.origen = _u(origen or u'')
        self.escala = int(escala) if escala else None
        self.escalable = bool(escalable and self.escala)
        self.fijo = float(fijo or 0.0)
        if isinstance(medidas, dict):
            self.medidas = dict((int(k), (float(v[0]), float(v[1]))) for k, v in medidas.items())
        else:
            self.medidas = {self.escala or 0: (float(medidas[0]), float(medidas[1]))}

    def medida(self, escala=None):
        e = int(escala) if escala else (self.escala or 0)
        if e in self.medidas:
            return self.medidas[e]
        if not self.escala or not self.escalable or not e:
            return self.medidas.get(self.escala or 0) or list(self.medidas.values())[0]
        # estimación: el dibujo cambia con la escala; el título no
        base = self.escala if self.escala in self.medidas else sorted(self.medidas)[0]
        w, h = self.medidas[base]
        f = base / float(e)
        return w * f, max(0.0, h - self.fijo) * f + self.fijo


class Propuesta(object):
    """Resultado del acomodo de UNA lámina.

    tamano: rótulo de la lámina original · escalas: {índice de vista: nueva escala} (solo las que cambian) ·
    grupos: [[índices de vista]] (el primero queda en la lámina original; los demás van a láminas nuevas) ·
    tamanos: rótulo de cada grupo · cabe: todo entra · paso: 'nada' | 'tamano' | 'escala' | 'repartir' | 'no_entra'
    · texto: explicación para el aviso."""

    def __init__(self, tamano, n):
        self.tamano = tamano
        self.escalas = {}
        self.grupos = [list(range(n))]
        self.tamanos = [tamano]
        self.cabe = True
        self.paso = u'nada'
        self.texto = u''

    @property
    def cambia(self):
        return self.paso not in (u'nada', u'no_entra')

    def como_dict(self):
        return dict(tamano=self.tamano, escalas=dict((str(k), v) for k, v in self.escalas.items()),
                    grupos=self.grupos, tamanos=self.tamanos, cabe=self.cabe, paso=self.paso, texto=self.texto)


def detalle_medida(vista, escala=None, unidad_mm=None):
    """Etapa 6A: «1700 × 1100 mm a 1/75, medida en Revit con el bounding box del viewport (…)» para el aviso de una
    vista que no entra ni sola: qué medida se tomó y de dónde salió. unidad_mm: mm de papel por unidad de las medidas
    (304.8 en Revit, que mide en pies; None si ya están en mm)."""
    e = int(escala) if escala else (vista.escala or 0)
    w, h = vista.medida(e or None)
    f = float(unidad_mm or 1.0)
    texto = u'%d × %d mm' % (int(round(w * f)), int(round(h * f)))
    if e:
        texto += u' a 1/%d' % e
    if e in vista.medidas or not e:
        texto += u', medida en Revit'
    else:
        base = vista.escala if vista.escala in vista.medidas else sorted(vista.medidas)[0]
        texto += u', estimada desde la medida a %s' % texto_escala(base)
    if vista.origen:
        texto += u' con %s' % vista.origen
    return texto


def _caben(tam, vistas, indices, escalas, franja_pct, margen_pct):
    _, w, h = tam
    medidas = [vistas[i].medida(escalas.get(i)) for i in indices]
    return core.caben(w, h, medidas, franja_pct, margen_pct)


def _escalas_paso(vistas, k, maximas):
    """Paso k (1, 2…) de reducción: cada vista escalable baja k escalas normalizadas (sin pasar de su máxima)."""
    res = {}
    for i, v in enumerate(vistas):
        if not v.escalable:
            continue
        sig = escalas_siguientes(v.escala, maximas[i])
        if sig:
            res[i] = sig[min(k, len(sig)) - 1]
    return res


def _escalas_de(vistas, indices, escalas):
    return sorted(set(escalas.get(i, vistas[i].escala) for i in indices if vistas[i].escala))


def _texto_escalas(vistas, indices, escalas):
    es = _escalas_de(vistas, indices, escalas)
    return u', '.join(texto_escala(e) for e in es) if es else u'su escala'


def acomodar(vistas, tamanos, actual, franja_pct=20.0, margen_pct=3.0, maxima=100, cambiar_tamano=True,
             cambiar_escala=True, repartir=True, especialidad=u'', unidad_mm=None):
    """Decide cómo acomodar las vistas de una lámina (ver el orden arriba).

    vistas: [Vista] · tamanos: [(clave, ancho, alto)] de la serie de rótulos (debe incluir `actual`) ·
    maxima: denominador máximo (int) o lista por vista · cambiar_tamano: False si la lámina tiene el tamaño
    uniforme de su especialidad · unidad_mm: mm de papel por unidad de las medidas, para el aviso de una vista que no
    entra ni sola (None: ya están en mm). Devuelve Propuesta."""
    n = len(vistas)
    lista = sorted(tamanos, key=lambda t: t[1] * t[2])
    tam = dict((t[0], t) for t in lista)
    if actual not in tam:
        raise ValueError(u'el rótulo actual no está entre los tamaños')
    prop = Propuesta(actual, n)
    todas = list(range(n))
    if not n or _caben(tam[actual], vistas, todas, {}, franja_pct, margen_pct):
        return prop
    maximas = maxima if isinstance(maxima, (list, tuple)) else [maxima] * n
    area_actual = tam[actual][1] * tam[actual][2]
    mayores = [t for t in lista if t[1] * t[2] > area_actual + 1e-9] if cambiar_tamano else []
    nombre_esp = NOMBRES_ESPECIALIDAD.get(_u(especialidad).upper(), u'')
    tope = u'1/%d' % max(maximas) if maximas else u''
    origen = u'Las vistas no entraban en «%s» a %s' % (corto(actual), _texto_escalas(vistas, todas, {}))

    # 1. lámina más grande, mismas escalas
    for t in mayores:
        if _caben(t, vistas, todas, {}, franja_pct, margen_pct):
            prop.tamano = t[0]
            prop.tamanos = [t[0]]
            prop.paso = u'tamano'
            prop.texto = u'%s: se usó «%s» con la misma escala (1.º lámina más grande).' % (origen, corto(t[0]))
            return prop

    # 2. escala menor (sin pasar de la que pide la especialidad), en la lámina más chica donde entren
    if cambiar_escala:
        anterior = None
        k = 1
        while True:
            esc = _escalas_paso(vistas, k, maximas)
            if not esc or esc == anterior:
                break
            for t in [tam[actual]] + mayores:
                if _caben(t, vistas, todas, esc, franja_pct, margen_pct):
                    prop.tamano = t[0]
                    prop.tamanos = [t[0]]
                    prop.escalas = dict((i, e) for i, e in esc.items() if e != vistas[i].escala)
                    prop.paso = u'escala'
                    cambiadas = u', '.join(u'«%s» %s → %s' % (vistas[i].nombre, texto_escala(vistas[i].escala),
                                                             texto_escala(e)) for i, e in sorted(prop.escalas.items()))
                    lam = u'en «%s»' % corto(t[0]) if t[0] == actual else u'y lámina «%s»' % corto(t[0])
                    ni = u' ni en «%s»' % corto(mayores[-1][0]) if mayores else u''
                    prop.texto = (u'%s%s: escala menor %s: %s (2.º escala; no se pasa de %s%s).'
                                  % (origen, ni, lam, cambiadas, tope,
                                     u', la que pide %s' % nombre_esp if nombre_esp else u''))
                    return prop
            anterior = esc
            k += 1

    # vistas que solas no entran ni en la lámina más grande a la escala más chica permitida: nada las arregla
    grande = lista[-1] if cambiar_tamano else tam[actual]
    peor = _escalas_paso(vistas, 99, maximas) if cambiar_escala else {}
    solas = [i for i in todas if not _caben(grande, vistas, [i], peor, franja_pct, margen_pct)]

    # 3. repartir en otra(s) lámina(s) del mismo tamaño, a la escala original
    if repartir and n > 1 and not solas:
        grupos = []
        for i in todas:
            if grupos and _caben(tam[actual], vistas, grupos[-1] + [i], {}, franja_pct, margen_pct):
                grupos[-1].append(i)
            else:
                grupos.append([i])
        if len(grupos) > 1:
            prop.grupos = grupos
            prop.tamanos = []
            prop.paso = u'repartir'
            extra = []
            for g in grupos:
                if _caben(tam[actual], vistas, g, {}, franja_pct, margen_pct):
                    prop.tamanos.append(actual)
                    continue
                # una vista sola que no entra en su tamaño: su lámina sigue los pasos 1 y 2
                sub = acomodar([vistas[i] for i in g], tamanos, actual, franja_pct, margen_pct,
                               [maximas[i] for i in g], cambiar_tamano, cambiar_escala, False, especialidad,
                               unidad_mm)
                prop.tamanos.append(sub.tamano)
                for j, e in sub.escalas.items():
                    prop.escalas[g[j]] = e
                prop.cabe = prop.cabe and sub.cabe
                extra.append(u'En la lámina de «%s»: %s' % (u'», «'.join(vistas[i].nombre for i in g),
                                                            sub.texto.split(u': ', 1)[-1]))
            reparto = u' | '.join(u'«%s»' % u'», «'.join(vistas[i].nombre for i in g) for g in grupos)
            prop.texto = (u'%s y no entran juntas ni con lámina más grande ni con escala menor (hasta %s): se '
                          u'repartieron en %d láminas de «%s» a su escala (3.º otra lámina): %s.%s'
                          % (origen, tope or u'la permitida', len(grupos), corto(actual), reparto,
                             (u' ' + u' '.join(extra)) if extra else u''))
            return prop

    # 4. no alcanza: se deja como estaba y se dice qué falta (las vistas no se ponen sobre el rótulo)
    prop.cabe = False
    prop.paso = u'no_entra'
    if solas:
        prop.texto = (u'%s: «%s» no entra%s ni sola en «%s» a %s; revise su región de recorte (que encierre solo el '
                      u'dibujo) o colóquela en otra lámina.' % (
                          origen, u'», «'.join(vistas[i].nombre for i in solas), u'n' if len(solas) > 1 else u'',
                          corto(grande[0]), tope or u'su escala'))
        # etapa 6A: qué medida se tomó y de dónde salió (contorno del viewport o bounding box)
        prop.texto += u' Medida tomada: %s.' % u'; '.join(
            u'«%s» %s' % (vistas[i].nombre, detalle_medida(vistas[i], peor.get(i), unidad_mm)) for i in solas)
    else:
        prop.texto = (u'%s y tampoco entran en «%s» a %s (sin repartir): revise la región de recorte de las vistas '
                      u'o sepárelas en otra lámina en el Excel.' % (origen, corto(grande[0]), tope or u'su escala'))
    return prop


def extension_robusta(cajas, limitar_tamano=False):
    """Extensión (x0, y0, x1, y1) del dibujo a partir de las cajas (x0, y0, x1, y1) de sus elementos, sin los
    elementos sueltos lejos del conjunto (puntos base, restos de CAD, una línea perdida a 60 m).

    El «núcleo» es la caja de los centros entre los percentiles 10 y 90; se aceptan los elementos cuyo centro está a
    menos de un tamaño de núcleo de él. Con `limitar_tamano` (vistas 3D) también se descartan los elementos más de 4
    veces más grandes que el núcleo (niveles y rejillas con extensión 3D enorme, un terreno muy grande).
    Devuelve None si no hay cajas."""
    cajas = [c for c in cajas if c is not None]
    if not cajas:
        return None
    cx = sorted((c[0] + c[2]) / 2.0 for c in cajas)
    cy = sorted((c[1] + c[3]) / 2.0 for c in cajas)

    def pct(lista, p):
        return lista[int(round(p * (len(lista) - 1)))]

    nx0, nx1, ny0, ny1 = pct(cx, 0.1), pct(cx, 0.9), pct(cy, 0.1), pct(cy, 0.9)
    tam = max(nx1 - nx0, ny1 - ny0)
    if tam <= 1e-9:   # todos los centros casi en el mismo punto: el tamaño de los propios elementos
        tam = max(max(c[2] - c[0], c[3] - c[1]) for c in cajas) or 1.0
    ok = []
    for c in cajas:
        x, y = (c[0] + c[2]) / 2.0, (c[1] + c[3]) / 2.0
        if not (nx0 - tam <= x <= nx1 + tam and ny0 - tam <= y <= ny1 + tam):
            continue
        if limitar_tamano and max(c[2] - c[0], c[3] - c[1]) > 4.0 * tam:
            continue
        ok.append(c)
    if not ok:
        ok = cajas
    return (min(c[0] for c in ok), min(c[1] for c in ok), max(c[2] for c in ok), max(c[3] for c in ok))


def caja_union(cajas):
    """Caja (x0, y0, x1, y1) que encierra las cajas dadas (las vacías o None no cuentan); None si no hay."""
    ok = [c for c in cajas if c is not None and c[2] - c[0] > 1e-9 and c[3] - c[1] > 1e-9]
    if not ok:
        return None
    return min(c[0] for c in ok), min(c[1] for c in ok), max(c[2] for c in ok), max(c[3] for c in ok)


def recorte_de_planta(caja_modelo, margen=1.5 / 0.3048, margen_rel=0.05):
    """Región de recorte de una planta: el MODELO (sin rejillas ni niveles, cuyas extensiones 2D pueden ser
    enormes) más un margen para que las rejillas asomen y sus burbujas queden en el recorte de anotación.
    margen en unidades del modelo (por defecto 1.5 m en pies) + `margen_rel` del lado mayor."""
    if caja_modelo is None:
        return None
    x0, y0, x1, y1 = caja_modelo
    m = margen + margen_rel * max(x1 - x0, y1 - y0)
    return x0 - m, y0 - m, x1 + m, y1 + m


def offset_anotacion(pedido_papel, medido_modelo, escala):
    """Revit no documenta en qué unidades van los «AnnotationCropOffset»: se pone `pedido_papel` (pies de papel), se
    mide el desfase que quedó en el modelo y, si salió `escala` veces más chico (unidades de modelo), se devuelve el
    valor a poner (pedido × escala); si ya está bien, None."""
    if not escala or pedido_papel <= 0:
        return None
    esperado = pedido_papel * escala
    if abs(medido_modelo - esperado) <= 0.2 * esperado:
        return None
    if abs(medido_modelo - pedido_papel) <= 0.2 * pedido_papel:
        return pedido_papel * escala
    return None


def numeros_extra(numero, cantidad, existentes, modo=u'sufijo', separador=u'-', digitos=2):
    """Números de las láminas nuevas al repartir: 'A-04' → ['A-04a', 'A-04b'] (modo «sufijo»; si alguno ya existe
    se usa el siguiente número libre) o ['A-07'] (modo «siguiente»: siguiente número libre de la especialidad)."""
    usados = set(_u(x).upper() for x in existentes)
    usados.add(_u(numero).upper())
    res = []
    if modo == u'sufijo':
        letras = u'abcdefghijklmnopqrstuvwxyz'
        for k in range(cantidad):
            cand = u'%s%s' % (numero, letras[k % 26])
            if cand.upper() in usados:
                break
            res.append(cand)
        if len(res) == cantidad:
            return res
        res = []
    prefijo, _, _ = core.separar_numero(numero, separador)
    mayor = 0
    for x in usados:
        p, nn, _ = core.separar_numero(x, separador)
        if nn is not None and p.upper() == prefijo.upper():
            mayor = max(mayor, nn)
    while len(res) < cantidad:
        mayor += 1
        cand = core.formatear_numero(prefijo, mayor, digitos, separador)
        if cand.upper() not in usados:
            res.append(cand)
            usados.add(cand.upper())
    return res
