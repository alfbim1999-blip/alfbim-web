# -*- coding: utf-8 -*-
"""PlanosALF — Manual."""
import os
import sys

# En modo desarrollo (archivo _DEV junto a la extensión) se recarga siempre el código de lib\planosalf
# raíz de 14_PlanosALF: la carpeta que contiene PlanosALF.extension (etapa 7: los botones están en ALF_BIM.tab\PlanosALF.panel\…)
_raiz = os.path.dirname(os.path.abspath(__file__))
while _raiz and not _raiz.lower().endswith('.extension') and os.path.dirname(_raiz) != _raiz:
    _raiz = os.path.dirname(_raiz)
_raiz = os.path.dirname(_raiz)
if os.path.isfile(os.path.join(_raiz, '_DEV')):
    for _m in [k for k in list(sys.modules) if k == 'planosalf' or k.startswith('planosalf.')]:
        del sys.modules[_m]

from planosalf import comandos  # noqa: E402

comandos.ejecutar(comandos.ayuda)
