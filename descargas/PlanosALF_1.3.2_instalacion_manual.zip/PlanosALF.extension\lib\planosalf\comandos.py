# -*- coding: utf-8 -*-
"""Comandos de la pestaña PlanosALF (cada botón llama a una función de este módulo)."""
from __future__ import print_function, division

import datetime
import os
import traceback

from Autodesk.Revit import DB
from pyrevit import forms, revit, script

from planosalf import alf_salidas, config, core, excel_planos, revit_ops, ui, xlsx

_u = xlsx._u
TITULO = u'PlanosALF'


# ============================================================================ utilidades

def documento(obligatorio=True):
    try:
        doc = revit.doc
    except Exception:
        doc = None
    if doc is not None and doc.IsFamilyDocument:
        if obligatorio:
            forms.alert(u'Abra un modelo de proyecto (no una familia).', title=TITULO, exitscript=True)
        return None
    if doc is None and obligatorio:
        forms.alert(u'Abra un modelo de Revit primero.', title=TITULO, exitscript=True)
    return doc


def ejecutar(funcion):
    """Ejecuta un comando mostrando los errores de forma clara."""
    try:
        funcion()
    except SystemExit:
        raise
    except (xlsx.ExcelError, revit_ops.ErrorPlanos) as ex:
        forms.alert(alf_salidas.sin_rutas(_u(ex)), title=TITULO)
    except revit_ops.Cancelado:
        forms.alert(u'Cancelado. No se cambió nada en el modelo.', title=TITULO, warn_icon=False)
    except Exception as ex:
        registrar_error()
        out = salida(u'PlanosALF — error')
        out.print_md(u'## Ocurrió un error inesperado')
        out.print_md(u'Nada quedó a medias: los cambios en el modelo se deshacen cuando hay un error. '
                     u'Envíe esta ventana a **%s** para corregirlo.' % config.CORREO)
        detalle = alf_salidas.sin_rutas(_u(traceback.format_exc()))   # sin las carpetas de la PC
        out.print_code(detalle)
        try:
            forms.alert(u'Ocurrió un error inesperado:\n\n%s' % alf_salidas.sin_rutas(_u(ex)), title=TITULO,
                        sub_msg=u'Despliegue «Detalle» y envíelo a %s.' % config.CORREO, expanded=detalle[-3000:])
        except TypeError:
            forms.alert(u'Ocurrió un error inesperado:\n\n%s\n\n%s' % (alf_salidas.sin_rutas(_u(ex)), detalle[-1500:]),
                        title=TITULO)


def registrar_error():
    """Guarda el último error en %APPDATA%\\ALF_BIM\\PlanosALF (y junto a la extensión en modo desarrollo)."""
    import io
    texto = u'%s\nPlanosALF %s\n%s' % (datetime.datetime.now().isoformat(), config.VERSION,
                                       alf_salidas.sin_rutas(_u(traceback.format_exc())))
    rutas = [os.path.join(config.carpeta_usuario(), u'ultimo_error.txt')]
    raiz = os.path.dirname(config.CARPETA_EXT)
    if os.path.isfile(os.path.join(raiz, u'_DEV')):
        rutas.append(os.path.join(raiz, u'_ultimo_error.txt'))
    for r in rutas:
        try:
            with io.open(r, 'w', encoding='utf-8') as f:
                f.write(texto)
        except Exception:
            pass


def ficha_de(doc):
    """Ficha del proyecto (.alfproyecto junto al modelo o en sus carpetas superiores; si no, la Información del
    proyecto). Sin modelo, una ficha vacía."""
    if doc is None:
        return alf_salidas.Ficha()
    try:
        return revit_ops.ficha_de(doc)
    except Exception:
        return alf_salidas.Ficha()


def ruta_modelo(doc):
    return revit_ops.ruta_modelo(doc) if doc is not None else u''


def guardar_como(doc, ficha, sufijo, titulo=u'Guardar Excel', carpeta=None):
    """«Guardar como» con el nombre propuesto limpio («V16_Índice de planos.xlsx») en la carpeta del proyecto. El
    cuadro tiene como dueño la ventana de Revit (etapa 5A: así no deja el ratón capturado)."""
    propuesto = alf_salidas.nombre_propuesto(ficha, sufijo, u'.xlsx', ruta_modelo(doc))
    carpeta = carpeta or carpeta_modelo(doc, ficha)
    ruta = ui.guardar_archivo(titulo, carpeta, propuesto)
    if not ruta:
        return None
    return alf_salidas.normalizar_guardado(_u(ruta), u'.xlsx', propuesto)


def elegir_excel(carpeta=u''):
    return ui.elegir_archivo(u'Elija el Excel de láminas', carpeta)


def carpeta_modelo(doc, ficha=None):
    """Carpeta del proyecto: la del modelo, si no la de la ficha, si no Documentos (nunca Descargas)."""
    return alf_salidas.carpeta_propuesta(ficha, ruta_modelo(doc) or None)


def raiz_proyecto(doc, ficha=None):
    """Carpeta del PROYECTO: la de su ficha «.alfproyecto» (que puede estar arriba de 01_ARQ, 02_EST…); si no hay
    ficha, la del modelo."""
    if ficha is not None and getattr(ficha, u'ruta', None):
        return os.path.dirname(_u(ficha.ruta))
    return carpeta_modelo(doc, ficha)


def especialidades_de(cfg, raiz):
    """Especialidades en el orden de la hoja ESPECIALIDADES del último Excel leído en este proyecto (si no, las de
    la Configuración): es el orden del índice de planos."""
    pares = core.datos_proyecto(cfg, raiz).get(u'especialidades')
    if pares:
        try:
            return core.Especialidades([tuple(x) for x in pares])
        except Exception:
            pass
    return cfg.especialidades()


def carpeta_de_exportacion(cfg, raiz):
    """La carpeta del proyecto o la última usada en ESTE proyecto; nunca la de otra obra."""
    return core.carpeta_exportacion_defecto(raiz, core.datos_proyecto(cfg, raiz).get(u'carpeta_exportacion'),
                                            _u(cfg.get(u'carpeta_exportacion') or u''))


def preguntar_abrir(ruta, mensaje):
    """«Se guardó «V16_….xlsx». ¿Abrir el archivo?» con Sí / No (nunca se abre solo)."""
    ui.ofrecer_abrir(ruta, TITULO, mensaje)


def seleccion_laminas(doc):
    """UniqueId de las láminas seleccionadas en el Navegador de proyectos."""
    res = set()
    try:
        for eid in revit.uidoc.Selection.GetElementIds():
            el = doc.GetElement(eid)
            if isinstance(el, DB.ViewSheet):
                res.add(_u(el.UniqueId))
    except Exception:
        pass
    return res


def salida(titulo):
    """Ventana de resultados de pyRevit con la letra de la marca (Times New Roman)."""
    out = script.get_output()
    out.set_title(titulo)
    try:
        out.add_style(u'body, p, li, td, th, h1, h2, h3 { font-family: "Times New Roman", serif !important; }')
    except Exception:
        pass
    return out


def enlace(out, lamina, texto=None):
    try:
        return out.linkify(lamina.Id, title=texto or _u(lamina.SheetNumber))
    except Exception:
        return texto or _u(lamina.SheetNumber)


# ============================================================================ plantilla y láminas a Excel

def _vistas_sin_colocar(doc):
    en_laminas = revit_ops.vistas_en_laminas(doc)
    vistas = []
    for v, tipo in revit_ops.vistas_colocables(doc):
        if revit_ops.vista_multiple(v) or revit_ops.eid_int(v.Id) not in en_laminas:
            vistas.append((_u(v.Name), tipo))
    return vistas


def plantilla_excel():
    doc = documento(obligatorio=False)
    cfg = config.cargar()
    esp = cfg.especialidades()
    rotulos, vistas, info, datos, extra = [], [], None, None, None
    if doc is not None:
        rotulos = [t for t, _ in revit_ops.rotulos(doc)]
        vistas = _vistas_sin_colocar(doc)
        # etapa 5A: la hoja LÁMINAS trae las láminas que ya tiene el modelo (con su Id Revit): al volver a leer el
        # Excel salen «Sin cambios» y las filas nuevas se agregan debajo
        datos, extra = revit_ops.datos_laminas(doc, esp)
    ficha = ficha_de(doc)
    if doc is not None:
        info = core.completar_info_con_ficha(revit_ops.info_proyecto(doc), core.valores_ficha(ficha, ruta_modelo(doc)))
    ruta = guardar_como(doc, ficha, u'Plantilla de láminas', u'Guardar la plantilla de láminas')
    if not ruta:
        return
    nombre = revit_ops.info_para_indice(doc, ficha)[u'proyecto'] if doc else u''
    sub = None
    if datos:
        sub = (u'Plantilla con las %d lámina(s) que ya tiene el modelo «%s» (no cambie la última columna, Id Revit). '
               u'Agregue debajo una fila por cada lámina nueva; si deja vacío el número, PlanosALF lo asigna.'
               % (len(datos), nombre or u'del proyecto'))
    excel_planos.libro_laminas(ruta, esp, rotulos=rotulos, vistas=vistas, info_proyecto=info,
                               laminas=datos or None, parametros_extra=extra, subtitulo=sub,
                               rotulo_defecto=cfg.get(u'rotulo_defecto', u''), nombre_proyecto=nombre,
                               autor=alf_salidas.autor(ficha))
    cfg[u'ultimo_excel'] = ruta
    cfg.guardar()
    extra_msg = u'' if doc else u'\n(Sin modelo abierto: las listas de rótulos y vistas van vacías.)'
    if datos:
        extra_msg = u'\nLa hoja LÁMINAS trae las %d lámina(s) del modelo.' % len(datos)
    preguntar_abrir(ruta, u'Plantilla creada.' + extra_msg)


def laminas_a_excel():
    doc = documento()
    cfg = config.cargar()
    esp = cfg.especialidades()
    datos, extra = revit_ops.datos_laminas(doc, esp)
    if not datos:
        forms.alert(u'El modelo no tiene láminas. Use «Plantilla Excel» para empezar.', title=TITULO)
        return
    ficha = ficha_de(doc)
    ruta = guardar_como(doc, ficha, u'Láminas', u'Guardar las láminas en Excel')
    if not ruta:
        return
    rotulos = [t for t, _ in revit_ops.rotulos(doc)]
    excel_planos.libro_laminas(ruta, esp, rotulos=rotulos, vistas=_vistas_sin_colocar(doc), laminas=datos,
                               parametros_extra=extra,
                               info_proyecto=core.completar_info_con_ficha(
                                   revit_ops.info_proyecto(doc), core.valores_ficha(ficha, ruta_modelo(doc))),
                               nombre_proyecto=revit_ops.info_para_indice(doc, ficha)[u'proyecto'],
                               rotulo_defecto=cfg.get(u'rotulo_defecto', u''), autor=alf_salidas.autor(ficha))
    cfg[u'ultimo_excel'] = ruta
    cfg.guardar()
    preguntar_abrir(ruta, u'%d lámina(s) exportadas a Excel.' % len(datos))


# ============================================================================ crear desde Excel

class _Preparado(object):
    """Lo que se leyó del Excel y se comparó con el modelo, antes de aplicar."""


def _preparar_excel(doc, cfg, ruta, ignorar_rotulo=False):
    hojas = xlsx.leer_libro(ruta)
    hoja = core.buscar_hoja(hojas, [u'LÁMINAS', u'LAMINAS', u'Láminas', u'Hojas', u'Planos', u'Lista de láminas'])
    if hoja is None:
        for h in hojas:
            try:
                core.leer_hoja_laminas(h)
                hoja = h
                break
            except xlsx.ExcelError:
                continue
    if hoja is None:
        raise xlsx.ExcelError(u'No se encontró una hoja con las columnas «Número de lámina» y «Nombre de lámina».\n\n'
                              u'Use el botón «Plantilla Excel» para crear el formato.')
    fmt = cfg.get(u'formato_fecha') or u'%d/%m/%Y'
    p = _Preparado()
    p.ruta = ruta
    p.hoja = hoja
    p.filas, p.columnas_param, p.avisos_excel = core.leer_hoja_laminas(hoja, fmt)
    if ignorar_rotulo:   # solo pedidos de desarrollo: prueba del tamaño uniforme por especialidad
        for f in p.filas:
            f.rotulo = u''
    p.pares_esp = core.leer_hoja_especialidades(core.buscar_hoja(hojas, [u'ESPECIALIDADES']))
    p.esp = core.Especialidades(p.pares_esp) if p.pares_esp else cfg.especialidades()
    p.proyecto = core.leer_hoja_proyecto(core.buscar_hoja(hojas, [u'PROYECTO']), fmt)
    if not p.filas and not p.proyecto:
        return p
    existentes = [dict(uid=_u(s.UniqueId), numero=_u(s.SheetNumber), nombre=_u(s.Name))
                  for s in revit_ops.laminas(doc)]
    p.acciones = core.planificar(p.filas, existentes, p.esp, _u(cfg.get(u'separador', u'-')),
                                 int(cfg.get(u'digitos', 2)))
    p.rotulos = revit_ops.rotulos(doc)
    revit_ops.detallar(doc, p.acciones, p.rotulos, revit_ops.vistas_colocables(doc), revit_ops.vistas_en_laminas(doc))
    # datos del proyecto que realmente cambian
    p.proyecto_cambia = []
    for nombre, valor in p.proyecto:
        prm = revit_ops.param_de_proyecto(doc, nombre)
        if prm is None:
            p.avisos_excel.append(u'PROYECTO: no existe el parámetro «%s» en la Información del proyecto.' % nombre)
        elif not revit_ops.mismo_valor(prm, valor):
            p.proyecto_cambia.append((nombre, valor))
    return p


def _rotulo_por_defecto(rotulos, guardado):
    """El rótulo guardado en la Configuración o el primero «ALF_BIM A1…» (como la ventana)."""
    textos = [t for t, _ in rotulos]
    if guardado and guardado in textos:
        return guardado
    a1 = [t for t in textos if t.upper().startswith(u'ALF_BIM A1')]
    return a1[0] if a1 else (textos[0] if textos else u'')


def _aplicar_excel(doc, cfg, p, r, interactivo=True):
    """Aplica el plan con las opciones r (crear, actualizar, vistas, proyecto, rotulo, uniforme). Devuelve el
    resumen (dict) y escribe la ventana de salida si es interactivo."""
    simbolo = None
    if r[u'rotulo']:
        simbolo, _ = revit_ops.buscar_rotulo(p.rotulos, r[u'rotulo'])
    franja = float(cfg.get(u'franja_rotulo_pct', 20.0))
    margen = float(cfg.get(u'margen_pct', 3.0))
    avisos_rotulo = []
    if r.get(u'uniforme', True) and r[u'crear'] and simbolo is not None:
        # etapa 5A: un solo tamaño de lámina por especialidad
        avisos_rotulo = revit_ops.uniformar_rotulos(doc, p.acciones, simbolo, p.rotulos, p.esp, franja, margen)
    opciones = dict(crear=r[u'crear'], actualizar=r[u'actualizar'], vistas=r[u'vistas'], rotulo_defecto=simbolo,
                    franja_pct=franja, margen_pct=margen, proyecto=p.proyecto_cambia if r[u'proyecto'] else [],
                    # etapa 5C: si las vistas de una lámina nueva no entran (recorte, tamaño, escala o reparto)
                    acomodar=bool(r.get(u'acomodar', True)), rotulos=p.rotulos, especialidades=p.esp.pares,
                    ajustar_recorte=bool(cfg.get(u'ajustar_recorte', True)),
                    repartir=bool(cfg.get(u'repartir_vistas', True)), escala_maxima=cfg.get(u'escala_maxima') or {},
                    reparto_numeracion=_u(cfg.get(u'reparto_numeracion') or u'sufijo'),
                    separador=_u(cfg.get(u'separador', u'-')), digitos=int(cfg.get(u'digitos', 2)))
    total = len([a for a in p.acciones if a.aplicar and ((a.tipo == core.Accion.CREAR and r[u'crear']) or
                                                          (a.tipo == core.Accion.ACTUALIZAR and r[u'actualizar']))])
    cancelado = False
    if interactivo:
        with forms.ProgressBar(title=u'PlanosALF: láminas ({value} de {max_value})', cancellable=True) as pb:
            def progreso(i, n):
                pb.update_progress(i, max(1, n))
                return pb.cancelled
            resultados, avisos_proyecto = revit_ops.aplicar_plan(doc, p.acciones, opciones, progreso)
            cancelado = pb.cancelled
        ui.liberar_raton()
    else:
        resultados, avisos_proyecto = revit_ops.aplicar_plan(doc, p.acciones, opciones, None)

    cfg[u'ultimo_excel'] = p.ruta
    cfg[u'crear_nuevas'] = r[u'crear']
    cfg[u'actualizar'] = r[u'actualizar']
    cfg[u'colocar_vistas'] = r[u'vistas']
    cfg[u'info_proyecto'] = r[u'proyecto']
    cfg[u'rotulo_uniforme'] = bool(r.get(u'uniforme', True))
    cfg[u'acomodar_vistas'] = bool(r.get(u'acomodar', True))
    if r[u'rotulo']:
        cfg[u'rotulo_defecto'] = r[u'rotulo']
    if p.pares_esp:
        # el orden de la hoja ESPECIALIDADES es el del índice de planos de este proyecto
        core.recordar_proyecto(cfg, raiz_proyecto(doc, ficha_de(doc)), especialidades=[list(x) for x in p.pares_esp])
    cfg.guardar()

    creadas = [x for x in resultados if x[0].tipo == core.Accion.CREAR and not x[3]]
    actualizadas = [x for x in resultados if x[0].tipo == core.Accion.ACTUALIZAR and not x[3]]
    errores = [x for x in resultados if x[3]]
    no_aplicadas = [a for a in p.acciones if a.tipo == core.Accion.ERROR]
    resumen = dict(creadas=[_u(x[0].numero) for x in creadas], actualizadas=[_u(x[0].numero) for x in actualizadas],
                   errores=[alf_salidas.sin_rutas(u'%s: %s' % (x[0].numero, x[3])) for x in errores],
                   filas_con_error=[u'Fila %d: %s' % (a.fila.fila, u'; '.join(a.errores)) for a in no_aplicadas],
                   rotulos=avisos_rotulo, cancelado=cancelado,
                   avisos=[alf_salidas.sin_rutas(u'%s: %s' % (x[0].numero, u'; '.join(x[2]))) for x in resultados
                           if x[2]])
    if not interactivo:
        return resumen

    out = salida(u'PlanosALF — láminas desde Excel')
    out.print_md(u'## PlanosALF · láminas desde Excel')
    out.print_md(u'**Excel:** %s' % alf_salidas.nombre_corto(p.ruta))
    out.print_md(u'**%d creada(s) · %d actualizada(s) · %d con error**%s' % (
        len(creadas), len(actualizadas), len(errores), u' · *cancelado por el usuario*' if cancelado else u''))
    if r[u'proyecto'] and p.proyecto_cambia:
        out.print_md(u'Información del proyecto: %d dato(s) escritos.' % (len(p.proyecto_cambia) - len(avisos_proyecto)))
    if avisos_rotulo and creadas:
        out.print_md(u'**Tamaño de lámina:**')
        for t in avisos_rotulo:
            out.print_md(u'- ' + t)
    filas_tabla = []
    for a, lam, avisos, error in resultados:
        filas_tabla.append([_u(a.fila.fila), a.tipo if not error else u'Error',
                            enlace(out, lam) if lam is not None and not error else a.numero, a.nombre,
                            alf_salidas.sin_rutas(error or u'; '.join(avisos))])
    if filas_tabla:
        out.print_table(table_data=filas_tabla, columns=[u'Fila', u'Acción', u'Lámina', u'Nombre', u'Observaciones'])
    if avisos_proyecto:
        out.print_md(u'**Información del proyecto:**')
        for t in avisos_proyecto:
            out.print_md(u'- ' + t)
    if no_aplicadas:
        out.print_md(u'**Filas del Excel con error (no se aplicaron):**')
        for a in no_aplicadas:
            out.print_md(u'- Fila %d: %s' % (a.fila.fila, u'; '.join(a.errores)))
    if total and not resultados and not cancelado:
        out.print_md(u'No se aplicó ninguna lámina.')
    out.print_md(u'---\n*PlanosALF %s · gratuito · www.alfbim.com*' % config.VERSION)
    ui.liberar_raton()
    return resumen


def crear_desde_excel():
    doc = documento()
    cfg = config.cargar()
    ultimo = _u(cfg.get(u'ultimo_excel') or u'')
    ficha = ficha_de(doc)
    raiz = raiz_proyecto(doc, ficha)
    # el último Excel solo si es de este proyecto; si no, la carpeta del proyecto
    inicio = os.path.dirname(ultimo) if ultimo and alf_salidas.dentro_de(os.path.dirname(ultimo), raiz) else raiz
    ruta = elegir_excel(inicio)
    if not ruta:
        return
    p = _preparar_excel(doc, cfg, ruta)
    if not p.filas and not p.proyecto:
        forms.alert(u'El Excel no tiene láminas ni datos del proyecto para leer.\n\nHoja leída: %s' % p.hoja.nombre,
                    title=TITULO)
        return
    v = ui.VentanaImportar(ruta, p.acciones, [t for t, _ in p.rotulos], _u(cfg.get(u'rotulo_defecto') or u''),
                           len(p.proyecto_cambia), p.avisos_excel, cfg)
    v.mostrar()
    if not v.resultado:
        return
    _aplicar_excel(doc, cfg, p, v.resultado, interactivo=True)


# ============================================================================ renumerar

def renumerar():
    doc = documento()
    cfg = config.cargar()
    esp = cfg.especialidades()
    hojas = revit_ops.laminas(doc)
    if not hojas:
        forms.alert(u'El modelo no tiene láminas.', title=TITULO)
        return
    marcadas = seleccion_laminas(doc)
    items = [dict(uid=_u(s.UniqueId), numero=_u(s.SheetNumber),
                  nombre=_u(s.Name) + (u'  (marcador)' if s.IsPlaceholder else u''), sel=_u(s.UniqueId) in marcadas)
             for s in hojas]
    todos = [(i[u'uid'], i[u'numero']) for i in items]
    v = ui.VentanaRenumerar(items, todos, cfg)
    v.mostrar()
    if not v.resultado:
        return
    r = v.resultado
    hechos, errores, avisos = revit_ops.renumerar(doc, r[u'cambios'], r[u'param_total'], esp)
    a = r[u'ajustes']
    cfg[u'renum_inicio'] = a[u'inicio']
    cfg[u'renum_incremento'] = a[u'incremento']
    cfg[u'renum_param_total'] = r[u'param_total']
    cfg.guardar()
    if errores or avisos:
        out = salida(u'PlanosALF — renumerar')
        if errores:
            out.print_md(u'## Renumerar: no se cambió ninguna lámina')
            out.print_md(u'Para no dejar números a medias, PlanosALF no aplica nada si una lámina falla:')
        else:
            out.print_md(u'## Renumerar: %d lámina(s) renumeradas' % hechos)
        for e in errores + avisos:
            out.print_md(u'- ' + e)
        ui.liberar_raton()
    else:
        forms.alert(u'%d lámina(s) renumeradas.' % hechos, title=TITULO, warn_icon=False)


# ============================================================================ exportar

def items_exportables(d, esp, info, marcadas=None):
    """(láminas exportables, items para la ventana y el plan de exportación) de un documento."""
    hojas = [s for s in revit_ops.laminas(d, incluir_marcadores=False)]
    items = []
    for s in hojas:
        datos = revit_ops.datos_patron(d, s, esp, info)
        items.append(dict(uid=_u(s.UniqueId), numero=_u(s.SheetNumber), nombre=_u(s.Name), codigo=datos[u'Codigo'],
                          revision=datos[u'Revision'], datos_patron=datos,
                          sel=(_u(s.UniqueId) in marcadas) if marcadas else True))
    items.sort(key=lambda i: (esp.orden(i[u'codigo']), core.clave_natural(i[u'numero'])))
    return hojas, items


def _con_archivos_existentes(filas, esperados, carpeta, archivos=None):
    """A cada fila le pone sus archivos: los de esta exportación y, si no, los ya exportados que siguen en la
    carpeta (no se pierde lo exportado antes)."""
    archivos = archivos or {}
    for d in filas:
        arch = dict(archivos.get(d[u'uid'], {}))
        for tipo, rel in esperados.get(d[u'uid'], {}).items():
            if tipo not in arch and os.path.isfile(os.path.join(carpeta, rel)):
                arch[tipo] = rel
        d[u'archivos'] = arch
    return filas


def escribir_indice(doc, cfg, esp, ficha, info, ruta_indice, columnas_pedidas, archivos=None, esperados=None):
    """Índice de planos ACUMULATIVO (etapa 5A): las láminas de este modelo, las de sus vínculos del mismo proyecto y
    las del índice que ya estaba en la carpeta (de los otros modelos: ARQ, EST, IISS, IIEE), en el orden de la hoja
    ESPECIALIDADES. Devuelve (cantidad de láminas, {código: cantidad}, avisos)."""
    carpeta = os.path.dirname(ruta_indice)
    raiz = raiz_proyecto(doc, ficha)
    avisos = []
    origen = revit_ops.nombre_modelo(doc)
    actuales = _con_archivos_existentes(revit_ops.datos_indice(doc, revit_ops.laminas_del_indice(doc), origen),
                                        esperados or {}, carpeta, archivos)
    origenes = [origen]
    if cfg.get(u'indice_vinculos', True):
        for ld, nombre in revit_ops.documentos_vinculados(doc, raiz):
            try:
                _, items_v = items_exportables(ld, esp, info)
                _, esperados_v = core.plan_exportacion(items_v, [], cfg, esp, alf_salidas.base_proyecto(ficha, ruta_modelo(doc)))
                filas_v = revit_ops.datos_indice(ld, revit_ops.laminas_del_indice(ld), nombre)
                if not filas_v:
                    # un vínculo sin láminas guardadas (p. ej. la ARQ vinculada en la EST) no borra del índice las
                    # láminas que ese modelo ya exportó: solo cuenta como «origen» si trae láminas
                    continue
                actuales += _con_archivos_existentes(filas_v, esperados_v, carpeta)
                origenes.append(nombre)
            except Exception as ex:
                avisos.append(u'Vínculo «%s»: %s' % (nombre, alf_salidas.sin_rutas(_u(ex))))
    previos = []
    if os.path.isfile(ruta_indice):
        try:
            previos = core.leer_indice(xlsx.leer_libro(ruta_indice))
        except Exception as ex:
            avisos.append(u'No se pudo leer el índice anterior (%s): se crea de nuevo' % alf_salidas.sin_rutas(_u(ex)))
        for f in previos:   # archivos que ya no están en la carpeta: se quitan del índice
            f[u'archivos'] = dict((t, rel) for t, rel in (f.get(u'archivos') or {}).items()
                                  if os.path.isfile(os.path.join(carpeta, rel)))
    filas = core.fusionar_indice(actuales, previos, origenes)
    columnas = core.columnas_de_archivo(filas, columnas_pedidas)
    info = dict(info)
    info[u'fecha'] = datetime.date.today().strftime(u'%d/%m/%Y')
    grupos = core.agrupar_por_especialidad(filas, esp)
    excel_planos.libro_indice(ruta_indice, info, grupos, columnas, esp, autor=alf_salidas.autor(ficha))
    por_esp = dict((cod or u'-', len(l)) for cod, _, l in grupos)
    return len(filas), por_esp, avisos


def exportar(pedido=None):
    """Exportar PDF / DWG. Con `pedido` (dict del panel Desarrollo) no abre ventanas y devuelve el resumen."""
    doc = documento()
    cfg = config.cargar()
    ficha = ficha_de(doc)
    raiz = raiz_proyecto(doc, ficha)
    esp = especialidades_de(cfg, raiz)
    info = revit_ops.info_para_indice(doc, ficha)
    base = alf_salidas.base_proyecto(ficha, ruta_modelo(doc))
    hojas, items = items_exportables(doc, esp, info, seleccion_laminas(doc) if pedido is None else None)
    if not hojas:
        if pedido is not None:
            return dict(ok=False, error=u'el modelo no tiene láminas')
        forms.alert(u'El modelo no tiene láminas para exportar.', title=TITULO)
        return
    carpeta_def = carpeta_de_exportacion(cfg, raiz)
    if pedido is None:
        v = ui.VentanaExportar(items, revit_ops.configuraciones_dwg(doc), cfg, carpeta_def)
        v.mostrar()
        if not v.resultado:
            return
        uids = v.resultado[u'uids']
    else:
        for k in (u'pdf', u'dwg', u'subcarpetas', u'modo_pdf', u'calidad_pdf', u'ocultar_cad', u'sobrescribir',
                  u'dwg_revisar_imagenes', u'indice_excel', u'dwg_unido', u'patron_archivo'):
            if k in pedido:
                cfg[k] = pedido[k]
        c = _u(pedido.get(u'carpeta') or u'')
        cfg[u'carpeta_exportacion'] = (c if os.path.isabs(c) else os.path.join(raiz, c)) if c else carpeta_def
        if not os.path.isdir(cfg[u'carpeta_exportacion']):
            os.makedirs(cfg[u'carpeta_exportacion'])
        codigos = [x.upper() for x in pedido.get(u'especialidades') or []]
        uids = [i[u'uid'] for i in items if not codigos or i[u'codigo'] in codigos]
    carpeta = _u(cfg[u'carpeta_exportacion'])
    # se recuerda la carpeta de ESTE proyecto (la próxima vez se propone la misma, nunca la de otra obra)
    guardar_en = cfg if pedido is None else config.cargar()   # un pedido no cambia la configuración del usuario
    if pedido is None or not pedido.get(u'no_recordar'):     # (pedidos de prueba en otra carpeta: no se recuerda)
        core.recordar_proyecto(guardar_en, raiz, carpeta_exportacion=carpeta)
        guardar_en.guardar()
    por_uid = dict((_u(s.UniqueId), s) for s in hojas)
    elegidos = [i for i in items if i[u'uid'] in set(uids)]
    tareas, esperados = core.plan_exportacion(items, [i[u'uid'] for i in elegidos], cfg, esp, base)

    archivos = {}   # uid -> {PDF: ruta relativa, DWG: ...}
    errores = []
    hechos = []
    cancelado = False
    opc_pdf = revit_ops.opciones_pdf(cfg) if cfg.get(u'pdf') else None
    opc_dwg = revit_ops.opciones_dwg(doc, cfg) if cfg.get(u'dwg') else None
    ocultar_cad = bool(cfg.get(u'ocultar_cad', True))
    revisar_img = bool(cfg.get(u'dwg_revisar_imagenes', True))
    revisiones = []
    # solo pedidos de desarrollo: logo de prueba en el rótulo de los DWG (se deshace al terminar)
    logo = config.recurso(u'PlanosALF_logo.png') if pedido is not None and pedido.get(u'logo_prueba') else None
    if logo and not os.path.isfile(logo):
        logo = None
    estad = {}
    carpetas_dwg = set()
    inicio = datetime.datetime.now()

    def una_tarea(tipo, lista, sub, nombre):
        destino = os.path.join(carpeta, sub) if sub else carpeta
        laminas_tarea = [por_uid[i[u'uid']] for i in lista]
        try:
            if tipo == u'PDF':
                def hacer():
                    return revit_ops.exportar_pdf(doc, [s.Id for s in laminas_tarea], destino, nombre,
                                                  opc_pdf, cfg.get(u'sobrescribir', True))
            else:
                carpetas_dwg.add(destino)

                def hacer():
                    return revit_ops.exportar_dwg(doc, laminas_tarea[0].Id, destino, nombre, opc_dwg,
                                                  cfg.get(u'sobrescribir', True), revisar_img, revisiones)
            logo_tarea = logo if tipo == u'DWG' else None
            if ocultar_cad or logo_tarea:
                ruta = revit_ops.exportar_sin_cad(doc, laminas_tarea, hacer, estad, logo=logo_tarea,
                                                  ocultar=ocultar_cad)
            else:
                ruta = hacer()
            rel = os.path.relpath(ruta, carpeta)
            hechos.append((tipo, rel, lista))
            for i in lista:
                archivos.setdefault(i[u'uid'], {})[tipo] = rel
        except Exception as ex:
            errores.append((tipo, nombre, alf_salidas.sin_rutas(_u(ex))))

    if tareas:
        if pedido is None:
            with forms.ProgressBar(title=u'PlanosALF: exportando ({value} de {max_value})', cancellable=True) as pb:
                for k, tarea in enumerate(tareas):
                    if pb.cancelled:
                        cancelado = True
                        break
                    pb.update_progress(k, len(tareas))
                    una_tarea(*tarea)
                pb.update_progress(len(tareas), len(tareas))
            ui.liberar_raton()
        else:
            for tarea in tareas:
                una_tarea(*tarea)

    ruta_indice = u''
    n_indice, por_esp, avisos_indice = 0, {}, []
    if cfg.get(u'indice_excel'):
        nombre_indice = alf_salidas.nombre_propuesto(ficha, u'Índice de planos', u'.xlsx', ruta_modelo(doc))
        ruta_indice = os.path.join(carpeta, nombre_indice)
        try:
            n_indice, por_esp, avisos_indice = escribir_indice(
                doc, cfg, esp, ficha, info, ruta_indice, [t for t in (u'PDF', u'DWG') if cfg.get(t.lower())],
                archivos, esperados)
        except Exception as ex:
            errores.append((u'Índice', nombre_indice, alf_salidas.sin_rutas(_u(ex))))
            ruta_indice = u''

    n_pdf = len([h for h in hechos if h[0] == u'PDF'])
    n_dwg = len([h for h in hechos if h[0] == u'DWG'])
    img = _resumen_imagenes(revisiones)
    segundos = (datetime.datetime.now() - inicio).total_seconds()
    resumen = dict(ok=not errores, version=config.VERSION, modelo=revit_ops.nombre_modelo(doc),
                   carpeta=alf_salidas.nombre_corto(carpeta), pdf=n_pdf, dwg=n_dwg, laminas=len(elegidos),
                   archivos=[r for _, r, _ in hechos], errores=[u'%s %s: %s' % e for e in errores],
                   indice=alf_salidas.nombre_corto(ruta_indice) if ruta_indice else u'', laminas_indice=n_indice,
                   indice_por_especialidad=por_esp, avisos_indice=avisos_indice, cad_ocultos=estad.get(u'cad', 0),
                   vistas_sin_cad=estad.get(u'vistas', 0), imagenes_dwg=img, segundos=int(segundos))
    if logo:
        resumen[u'logos_de_prueba'] = estad.get(u'logos', 0)
    if pedido is not None:
        return resumen

    out = salida(u'PlanosALF — exportar')
    out.print_md(u'## PlanosALF · exportación de láminas')
    out.print_md(u'**Carpeta:** %s' % alf_salidas.nombre_corto(carpeta))
    out.print_md(u'**%d PDF · %d DWG · %d error(es)** · %d lámina(s) · %.0f s%s' % (
        n_pdf, n_dwg, len(errores), len(elegidos), segundos, u' · *cancelado*' if cancelado else u''))
    if ocultar_cad and (estad.get(u'cad') or estad.get(u'vistas')):
        out.print_md(u'CAD de referencia oculto al exportar: %d vista(s) (el modelo quedó como estaba).'
                     % estad.get(u'vistas', 0))
    if img[u'dwg_con_imagenes']:
        out.print_md(u'Imágenes de los DWG (logos, fotos): %d en %d DWG, junto a cada DWG donde AutoCAD las busca%s.'
                     % (img[u'imagenes'], img[u'dwg_con_imagenes'],
                        u' (%d copiadas)' % len(img[u'copiadas']) if img[u'copiadas'] else u''))
    if img[u'faltan']:
        out.print_md(u'**Imágenes que los DWG piden y no están:** %s' % u', '.join(img[u'faltan']))
    if ruta_indice:
        out.print_md(u'Índice de planos: %s · **%d lámina(s)** (%s)' % (
            alf_salidas.nombre_corto(ruta_indice), n_indice,
            u', '.join(u'%s %d' % (c, n) for c, n in sorted(por_esp.items(), key=lambda x: (esp.orden(x[0]), x[0])))))
        for a in avisos_indice:
            out.print_md(u'- ' + a)
    if errores:
        out.print_table(table_data=[[t, n, e] for t, n, e in errores], columns=[u'Formato', u'Archivo', u'Error'],
                        title=u'Errores')
    if hechos:
        out.print_table(table_data=[[t, r, u', '.join(i[u'numero'] for i in l)] for t, r, l in hechos],
                        columns=[u'Formato', u'Archivo', u'Láminas'])
    out.print_md(u'---\n*PlanosALF %s · gratuito · www.alfbim.com*' % config.VERSION)
    ui.liberar_raton()
    if cfg.get(u'abrir_carpeta') and (hechos or ruta_indice):
        # nunca se abre el Explorador solo: se pregunta «¿Abrir la carpeta?» Sí / No
        ui.ofrecer_abrir_carpeta(carpeta, TITULO, u'%d PDF · %d DWG%s' % (
            n_pdf, n_dwg, u' · índice de planos (%d láminas)' % n_indice if ruta_indice else u''))
    return resumen


def _resumen_imagenes(revisiones):
    """Resumen de las imágenes de los DWG exportados (dwg_imagenes.revisar de cada uno)."""
    con = [r for r in revisiones if r.get(u'imagenes')]
    res = dict(dwg_revisados=len(revisiones), dwg_con_imagenes=len(con),
               imagenes=sum(len(r[u'imagenes']) for r in con),
               copiadas=sorted(set(x for r in con for x in r[u'copiadas'])),
               faltan=sorted(set(x for r in con for x in r[u'faltan'])),
               no_leidos=[u'%s: %s' % (r[u'dwg'], r[u'error']) for r in revisiones if r.get(u'error')],
               escritas_por_revit=sum(len(r.get(u'escritas_por_revit') or []) for r in revisiones))
    res[u'detalle'] = [dict(dwg=r[u'dwg'], version=r[u'version'],
                            imagenes=[alf_salidas.sin_rutas(x) for x in r[u'imagenes']]) for r in con]
    return res


def hojas_del_indice(doc):
    """Láminas que van en el índice (las que tienen «Aparece en la lista de planos»)."""
    return revit_ops.laminas_del_indice(doc)


# ============================================================================ índice de planos

def indice_planos():
    doc = documento()
    cfg = config.cargar()
    if not hojas_del_indice(doc):
        forms.alert(u'El modelo no tiene láminas.', title=TITULO)
        return
    ficha = ficha_de(doc)
    raiz = raiz_proyecto(doc, ficha)
    esp = especialidades_de(cfg, raiz)
    carpeta = carpeta_de_exportacion(cfg, raiz)
    if not os.path.isdir(carpeta):
        carpeta = raiz
    ruta = guardar_como(doc, ficha, u'Índice de planos', u'Guardar el índice de planos', carpeta=carpeta)
    if not ruta:
        return
    info = revit_ops.info_para_indice(doc, ficha)
    # si el índice ya existe se fusiona (las láminas de los otros modelos del proyecto no se pierden)
    _, items = items_exportables(doc, esp, info)
    _, esperados = core.plan_exportacion(items, [], cfg, esp, alf_salidas.base_proyecto(ficha, ruta_modelo(doc)))
    n, por_esp, avisos = escribir_indice(doc, cfg, esp, ficha, info, ruta, [], None, esperados)
    detalle = u'Índice de planos con %d lámina(s): %s.' % (
        n, u', '.join(u'%s %d' % (c, k) for c, k in sorted(por_esp.items(), key=lambda x: (esp.orden(x[0]), x[0]))))
    if avisos:
        detalle += u'\n' + u'\n'.join(avisos)
    preguntar_abrir(ruta, detalle)


# ============================================================================ ficha del proyecto

def _resumen_ficha(f):
    filas = [(u'Proyecto', f.nombre), (u'Código', f.codigo), (u'CUI', f.cui), (u'Entidad', f.entidad),
             (u'Ubicación', f.ubicacion_texto()), (u'Proyectista', f.proyectista_texto()),
             (u'Organización', f.organizacion), (u'Fecha', f.fecha)]
    return u'\n'.join(u'%s: %s' % (k, _u(v)) for k, v in filas if _u(v).strip())


def ficha_proyecto():
    """Lee la ficha «.alfproyecto» de la carpeta del modelo (o superiores) y la escribe en la Información del
    proyecto (la leen los rótulos), o crea la ficha con la Información del proyecto. Igual que el botón
    «Ficha del proyecto» de los complementos ALF_BIM en C#."""
    doc = documento()
    ruta = ruta_modelo(doc)
    ruta_ficha = alf_salidas.buscar(ruta) if ruta else None
    ficha, error = None, None
    if ruta_ficha:
        try:
            ficha = alf_salidas.leer(ruta_ficha)
        except ValueError as ex:
            error = _u(ex)
    # ventana propia (etapa 5A): el TaskDialog de Revit se titulaba «PyRevitLoader - Ficha del proyecto»
    ESCRIBIR, ACTUALIZAR = u'escribir', u'actualizar'
    if ficha is not None:
        errores, avisos = alf_salidas.validar(ficha)
        instruccion = u'Ficha «%s»' % alf_salidas.nombre_corto(ruta_ficha)
        contenido = _resumen_ficha(ficha) + ((u'\n\n' + u'\n'.join(errores + avisos)) if errores or avisos else u'')
        opciones = [(ESCRIBIR, u'Escribir la ficha en «Información del proyecto»'),
                    (ACTUALIZAR, u'Actualizar la ficha con «Información del proyecto»')]
    else:
        instruccion = (u'No se pudo leer la ficha: %s' % alf_salidas.sin_rutas(error)) if error else \
            u'No hay ficha del proyecto en la carpeta del modelo.'
        contenido = (u'Guarde el modelo primero: la ficha se guarda junto a él.' if not ruta else
                     u'Complete «Información del proyecto» (nombre, número, cliente, autor) y cree la ficha: '
                     u'los demás programas ALF_BIM la usarán.')
        opciones = [(ACTUALIZAR, u'Crear la ficha con «Información del proyecto»')] if ruta else []
    elegido = ui.preguntar(u'PlanosALF — Ficha del proyecto', instruccion, contenido,
                           [t for _, t in opciones] + [u'Cancelar'])
    r = opciones[elegido][0] if elegido is not None and elegido < len(opciones) else None
    if r == ESCRIBIR and ficha is not None:
        avisos = revit_ops.escribir_ficha(doc, ficha)
        forms.alert(u'Se escribió la ficha en «Información del proyecto».' +
                    ((u'\n\n' + u'\n'.join(avisos)) if avisos else u''), title=TITULO, warn_icon=False)
    elif r == ACTUALIZAR and ruta:
        desde = revit_ops.ficha_desde_informacion(doc)
        f = ficha or revit_ops.ficha_guardada(doc) or alf_salidas.Ficha()
        for campo in (u'nombre', u'codigo', u'entidad', u'organizacion', u'fecha'):
            if _u(getattr(desde, campo)).strip():
                setattr(f, campo, getattr(desde, campo))
        if desde.proyectista and not _u(f.proyectista).strip():
            f.proyectista = desde.proyectista
        if not f.fecha:
            f.fecha = datetime.date.today().strftime(u'%Y-%m-%d')
        destino = ruta_ficha or os.path.join(os.path.dirname(ruta), (alf_salidas.nombre_desde_archivo(ruta) or
                                                                    u'proyecto') + alf_salidas.EXTENSION)
        alf_salidas.guardar(f, destino)
        revit_ops.escribir_ficha(doc, f)
        forms.alert(u'Se guardó la ficha «%s» junto al modelo.' % alf_salidas.nombre_corto(destino) +
                    (u'\n\nFaltan la ubicación y otros datos: complételos en la ficha (o desde cualquier programa '
                     u'ALF_BIM de escritorio).' if not f.departamento else u''), title=TITULO, warn_icon=False)


# ============================================================================ configuración y ayuda

def configuracion():
    doc = documento(obligatorio=False)
    cfg = config.cargar()
    rotulos = [t for t, _ in revit_ops.rotulos(doc)] if doc is not None else []
    v = ui.VentanaConfig(cfg, rotulos)
    v.mostrar()


def ayuda():
    if not ui.abrir_manual():
        forms.alert(u'No se pudo abrir el manual. Visite %s' % config.WEB, title=TITULO)


def acerca():
    ui.VentanaAcerca().mostrar()


# ============================================================================ pedidos (solo desarrollo)

def carpeta_dev():
    return os.path.join(os.path.dirname(config.CARPETA_EXT), u'_dev_pedidos')  # «_dev» chocaría con el archivo «_DEV» (Windows no distingue mayúsculas)


def _ruta_de_pedido(raiz, texto):
    texto = _u(texto or u'').strip()
    if not texto:
        return u''
    return os.path.normpath(texto if os.path.isabs(texto) else os.path.join(raiz, texto))


def _cumplir_pedido(doc, ped):
    """Un pedido: plantilla | crear | exportar | indice. Devuelve el resumen (sin rutas de la PC)."""
    accion = _u(ped.get(u'accion')).lower()
    cfg = config.cargar()
    ficha = ficha_de(doc)
    raiz = raiz_proyecto(doc, ficha)
    if accion == u'exportar':
        return exportar(pedido=ped)
    if accion == u'plantilla':
        esp = cfg.especialidades()
        datos, extra = revit_ops.datos_laminas(doc, esp)
        ruta = _ruta_de_pedido(raiz, ped.get(u'excel')) or os.path.join(
            carpeta_modelo(doc, ficha), alf_salidas.nombre_propuesto(ficha, u'Plantilla de láminas', u'.xlsx',
                                                                     ruta_modelo(doc)))
        if not os.path.isdir(os.path.dirname(ruta)):
            os.makedirs(os.path.dirname(ruta))
        info = core.completar_info_con_ficha(revit_ops.info_proyecto(doc), core.valores_ficha(ficha, ruta_modelo(doc)))
        excel_planos.libro_laminas(ruta, esp, rotulos=[t for t, _ in revit_ops.rotulos(doc)],
                                   vistas=_vistas_sin_colocar(doc), info_proyecto=info, laminas=datos or None,
                                   parametros_extra=extra, nombre_proyecto=revit_ops.info_para_indice(doc, ficha)[u'proyecto'],
                                   rotulo_defecto=cfg.get(u'rotulo_defecto', u''), autor=alf_salidas.autor(ficha))
        return dict(ok=True, excel=alf_salidas.nombre_corto(ruta), laminas_en_la_hoja=len(datos or []))
    if accion == u'crear':
        ruta = _ruta_de_pedido(raiz, ped.get(u'excel'))
        if not ruta or not os.path.isfile(ruta):
            return dict(ok=False, error=u'no existe el Excel «%s»' % alf_salidas.nombre_corto(ruta))
        p = _preparar_excel(doc, cfg, ruta, ignorar_rotulo=bool(ped.get(u'ignorar_rotulo_del_excel')))
        if not p.filas and not p.proyecto:
            return dict(ok=False, error=u'el Excel no tiene láminas')
        rotulo = _u(ped.get(u'rotulo') or u'') or _rotulo_por_defecto(p.rotulos, _u(cfg.get(u'rotulo_defecto') or u''))
        r = dict(crear=True, actualizar=bool(ped.get(u'actualizar', True)), vistas=bool(ped.get(u'vistas', True)),
                 proyecto=bool(ped.get(u'proyecto', True)), rotulo=rotulo, uniforme=bool(ped.get(u'uniforme', True)),
                 acomodar=bool(ped.get(u'acomodar', True)))
        res = _aplicar_excel(doc, config.cargar(), p, r, interactivo=False)
        res[u'ok'] = not res[u'errores']
        res[u'plan'] = dict((t, len([a for a in p.acciones if a.tipo == t])) for t in
                            (core.Accion.CREAR, core.Accion.ACTUALIZAR, core.Accion.SIN_CAMBIOS, core.Accion.ERROR))
        return res
    if accion == u'indice':
        esp = especialidades_de(cfg, raiz)
        info = revit_ops.info_para_indice(doc, ficha)
        ruta = _ruta_de_pedido(raiz, ped.get(u'archivo')) or os.path.join(
            carpeta_de_exportacion(cfg, raiz),
            alf_salidas.nombre_propuesto(ficha, u'Índice de planos', u'.xlsx', ruta_modelo(doc)))
        _, items = items_exportables(doc, esp, info)
        _, esperados = core.plan_exportacion(items, [], cfg, esp, alf_salidas.base_proyecto(ficha, ruta_modelo(doc)))
        n, por_esp, avisos = escribir_indice(doc, cfg, esp, ficha, info, ruta, [], None, esperados)
        return dict(ok=True, indice=alf_salidas.nombre_corto(ruta), laminas_indice=n, indice_por_especialidad=por_esp,
                    avisos=avisos)
    return dict(ok=False, error=u'acción desconocida «%s»' % accion)


def pedido_sin_dialogo(datos):
    """«sin_dialogo»: true en el pedido (o en una de sus acciones): al terminar no se muestra «Pedido cumplido» (lo usa la
    prueba integral automática de la etapa 6A, que pulsa el botón sin nadie delante). La respuesta se escribe igual."""
    if isinstance(datos, dict):
        if datos.get(u'sin_dialogo'):
            return True
        pedidos = datos.get(u'pedidos') or []
    elif isinstance(datos, list):
        pedidos = datos
    else:
        return False
    return any(isinstance(p, dict) and p.get(u'sin_dialogo') for p in pedidos)


def pedido_desarrollo():
    """Panel Desarrollo (solo en la PC de desarrollo): cumple `_dev_pedidos\\pedidos\\pedido_planosalf.json` sobre el
    modelo abierto, sin ventanas, y deja `_dev_pedidos\\respuestas\\<modelo>_planosalf.json`. Las rutas del pedido son relativas a la
    carpeta del proyecto (la de la ficha .alfproyecto)."""
    import io
    import json
    doc = documento()
    ruta = os.path.join(carpeta_dev(), u'pedidos', u'pedido_planosalf.json')
    if not os.path.isfile(ruta):
        forms.alert(u'No hay pedido: falta _dev_pedidos\\pedidos\\pedido_planosalf.json.', title=TITULO)
        return
    with io.open(ruta, 'r', encoding='utf-8-sig') as f:
        datos = json.loads(f.read())
    pedidos = datos.get(u'pedidos') if isinstance(datos, dict) and u'pedidos' in datos else \
        (datos if isinstance(datos, list) else [datos])
    modelo = revit_ops.nombre_modelo(doc)
    resultados = []
    for ped in pedidos:
        modelos = [m.lower() for m in ped.get(u'modelos') or []]
        if modelos and not [m for m in modelos if m in modelo.lower()]:
            continue    # el pedido es para otro modelo (ARQ, EST, IISS, IIEE)
        # «{modelo}» en un texto del pedido = nombre del modelo abierto (V16_ARQ…)
        ped = dict((k, v.replace(u'{modelo}', modelo) if isinstance(v, type(u'')) else v) for k, v in ped.items())
        try:
            res = _cumplir_pedido(doc, ped)
        except Exception as ex:
            registrar_error()
            res = dict(ok=False, error=alf_salidas.sin_rutas(_u(ex)))
        res[u'accion'] = ped.get(u'accion')
        resultados.append(res)
    salida_json = dict(programa=u'PlanosALF', version=config.VERSION, modelo=modelo,
                       fecha=datetime.datetime.now().strftime(u'%Y-%m-%d %H:%M:%S'),
                       ok=all(r.get(u'ok') for r in resultados), resultados=resultados)
    carpeta = os.path.join(carpeta_dev(), u'respuestas')
    if not os.path.isdir(carpeta):
        os.makedirs(carpeta)
    destino = os.path.join(carpeta, u'%s_planosalf.json' % (alf_salidas.limpiar_nombre(modelo) or u'modelo'))
    texto = json.dumps(salida_json, ensure_ascii=False, indent=2, sort_keys=True)
    with io.open(destino, 'w', encoding='utf-8') as f:
        f.write(alf_salidas.sin_rutas(_u(texto)))
    if pedido_sin_dialogo(datos):
        return
    forms.alert(u'Pedido cumplido: %d acción(es), %s.\n\nRespuesta: _dev_pedidos\\respuestas\\%s' % (
        len(resultados), u'todo bien' if salida_json[u'ok'] else u'con errores', os.path.basename(destino)),
        title=TITULO, warn_icon=not salida_json[u'ok'])

