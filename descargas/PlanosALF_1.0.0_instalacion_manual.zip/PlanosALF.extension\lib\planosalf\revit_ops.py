# -*- coding: utf-8 -*-
"""Operaciones de PlanosALF sobre el modelo de Revit (API de Revit 2023-2027)."""
from __future__ import print_function, division

import os

import clr  # noqa: F401
from Autodesk.Revit import DB
from System.Collections.Generic import List

from planosalf import core, xlsx

try:  # cuadros de carga (tablas de tableros eléctricos)
    from Autodesk.Revit.DB.Electrical import PanelScheduleView, PanelScheduleSheetInstance
except Exception:  # pragma: no cover
    PanelScheduleView = PanelScheduleSheetInstance = None

_u = xlsx._u


# ============================================================================ utilidades

def eid_int(eid):
    """Valor numérico de un ElementId (Value en 2024+, IntegerValue antes)."""
    try:
        return int(eid.Value)
    except AttributeError:
        return int(eid.IntegerValue)


def nombre_de(el):
    try:
        return _u(el.Name)
    except Exception:
        pass
    try:
        return _u(DB.Element.Name.GetValue(el))
    except Exception:
        pass
    p = el.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
    return _u(p.AsString()) if p else u''


def bip(nombre):
    """BuiltInParameter por nombre (None si no existe en esta versión de Revit)."""
    return getattr(DB.BuiltInParameter, nombre, None)


def texto_param(p):
    if p is None or not p.HasValue:
        return u''
    try:
        if p.StorageType == DB.StorageType.String:
            return _u(p.AsString() or u'')
        return _u(p.AsValueString() or u'')
    except Exception:
        return u''


def es_si_no(p):
    try:
        return p.Definition.GetDataType() == DB.SpecTypeId.Boolean.YesNo
    except Exception:
        try:
            return p.Definition.ParameterType == DB.ParameterType.YesNo
        except Exception:
            return False


_SI = set([u'si', u'yes', u'1', u'x', u'true', u'verdadero', u's'])
_NO = set([u'no', u'0', u'false', u'falso', u'n', u''])


def escribir_param(p, texto):
    """Escribe un texto en el parámetro. Devuelve None si se escribió o el motivo del fallo."""
    if p is None:
        return u'no existe'
    if p.IsReadOnly:
        return u'es de solo lectura'
    borrar = core.normalizar(texto) == core.normalizar(core.CLAVE_BORRAR)
    st = p.StorageType
    try:
        if st == DB.StorageType.String:
            p.Set(u'' if borrar else _u(texto))
            return None
        if borrar:
            return u'no se puede vaciar (no es de texto)'
        if st == DB.StorageType.Integer:
            if es_si_no(p):
                n = core.normalizar(texto)
                if n in _SI:
                    p.Set(1)
                elif n in _NO:
                    p.Set(0)
                else:
                    return u'debe ser Sí o No'
                return None
            p.Set(int(round(float(_u(texto).replace(u',', u'.')))))
            return None
        if st == DB.StorageType.Double:
            if p.SetValueString(_u(texto)):
                return None
            p.Set(float(_u(texto).replace(u',', u'.')))
            return None
        return u'tipo de parámetro no admitido (elemento)'
    except Exception as ex:
        return u'valor no válido (%s)' % _u(ex)


def mismo_valor(p, texto):
    if core.normalizar(texto) == core.normalizar(core.CLAVE_BORRAR):
        return texto_param(p) == u''
    actual = texto_param(p)
    if actual == _u(texto):
        return True
    if p is not None and p.StorageType == DB.StorageType.Integer and es_si_no(p):
        n = core.normalizar(texto)
        return (p.AsInteger() == 1 and n in _SI) or (p.AsInteger() == 0 and n in _NO and n)
    if p is not None and p.StorageType != DB.StorageType.String:
        try:
            return abs(float(actual.replace(u',', u'.')) - float(_u(texto).replace(u',', u'.'))) < 1e-9
        except ValueError:
            return False
    return False


def buscar_param(el, nombre):
    """Parámetro por nombre exacto y luego sin tildes ni mayúsculas."""
    if el is None:
        return None
    p = el.LookupParameter(nombre)
    if p is not None:
        return p
    n = core.normalizar(nombre)
    for q in el.Parameters:
        try:
            if core.normalizar(q.Definition.Name) == n:
                return q
        except Exception:
            continue
    return None


ALIAS_LAMINA = core.ALIAS_LAMINA
ALIAS_PROYECTO = core.ALIAS_PROYECTO


def _por_alias(el, nombre, tabla):
    n = core.normalizar(nombre)
    for bname, alias in tabla:
        if n in alias:
            b = bip(bname)
            if b is not None:
                p = el.get_Parameter(b)
                if p is not None:
                    return p
    return None


def param_de_lamina(doc, lamina, rotulo, nombre):
    """Dónde se escribe una columna: lámina, rótulo de la lámina o Información del proyecto.

    Devuelve (parámetro, lugar) o (None, None)."""
    for el, lugar, exacto in ((lamina, u'lámina', True), (rotulo, u'rótulo', True)):
        if el is not None:
            p = el.LookupParameter(nombre)
            if p is not None:
                return p, lugar
    for el, lugar in ((lamina, u'lámina'), (rotulo, u'rótulo')):
        p = buscar_param(el, nombre)
        if p is not None:
            return p, lugar
    p = _por_alias(lamina, nombre, ALIAS_LAMINA)
    if p is not None:
        return p, u'lámina'
    info = doc.ProjectInformation
    p = buscar_param(info, nombre) or _por_alias(info, nombre, ALIAS_PROYECTO)
    if p is not None:
        return p, u'proyecto'
    return None, None


def param_de_proyecto(doc, nombre):
    info = doc.ProjectInformation
    return buscar_param(info, nombre) or _por_alias(info, nombre, ALIAS_PROYECTO)


class SilenciarAvisos(DB.IFailuresPreprocessor):
    """Quita los avisos (no los errores) para que no aparezcan cientos de ventanas al crear láminas."""

    def PreprocessFailures(self, accesor):
        try:
            for f in accesor.GetFailureMessages():
                if f.GetSeverity() == DB.FailureSeverity.Warning:
                    accesor.DeleteWarning(f)
        except Exception:
            pass
        return DB.FailureProcessingResult.Continue


def transaccion(doc, nombre):
    t = DB.Transaction(doc, nombre)
    opciones = t.GetFailureHandlingOptions()
    opciones.SetFailuresPreprocessor(SilenciarAvisos())
    t.SetFailureHandlingOptions(opciones)
    return t


# ============================================================================ consultas del modelo

def laminas(doc, incluir_marcadores=True):
    res = []
    for s in DB.FilteredElementCollector(doc).OfClass(DB.ViewSheet):
        if s.IsTemplate:
            continue
        if s.IsPlaceholder and not incluir_marcadores:
            continue
        res.append(s)
    res.sort(key=lambda s: core.clave_natural(s.SheetNumber))
    return res


def rotulo_de(doc, lamina):
    for tb in DB.FilteredElementCollector(doc, lamina.Id).OfCategory(DB.BuiltInCategory.OST_TitleBlocks) \
            .WhereElementIsNotElementType():
        return tb
    return None


def texto_rotulo(simbolo):
    try:
        familia = _u(simbolo.FamilyName)
    except Exception:
        familia = _u(simbolo.Family.Name) if simbolo.Family else u''
    return u'%s : %s' % (familia, nombre_de(simbolo))


def rotulos(doc):
    """[(texto 'Familia : Tipo', FamilySymbol)] ordenados."""
    res = []
    for s in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_TitleBlocks) \
            .WhereElementIsElementType():
        res.append((texto_rotulo(s), s))
    res.sort(key=lambda x: core.clave_natural(x[0]))
    return res


def buscar_rotulo(lista, texto):
    """Busca 'Familia : Tipo', solo 'Tipo' o solo 'Familia' (si es única). Devuelve (símbolo, error)."""
    texto = _u(texto).strip()
    if not texto:
        return None, u''
    n = core.normalizar(texto)
    for t, s in lista:
        if core.normalizar(t) == n:
            return s, u''
    candidatos = []
    for t, s in lista:
        fam, _, tipo = t.partition(u' : ')
        if core.normalizar(tipo) == n or core.normalizar(fam) == n:
            candidatos.append((t, s))
    if len(candidatos) == 1:
        return candidatos[0][1], u''
    if len(candidatos) > 1:
        return None, u'Rótulo «%s» ambiguo: escriba «Familia : Tipo» (%s)' % (texto, u'; '.join(t for t, _ in candidatos[:4]))
    return None, u'No existe el rótulo «%s» en el modelo (cárguelo o revise la hoja MODELO)' % texto


_TIPOS_COLOCABLES = None


def _tipos_colocables():
    global _TIPOS_COLOCABLES
    if _TIPOS_COLOCABLES is None:
        nombres = [u'FloorPlan', u'CeilingPlan', u'Elevation', u'ThreeD', u'Schedule', u'DraftingView', u'Section',
                   u'Detail', u'Legend', u'EngineeringPlan', u'AreaPlan', u'Rendering', u'Walkthrough',
                   u'ColumnSchedule', u'PanelSchedule', u'CostReport', u'LoadsReport', u'PresureLossReport']
        _TIPOS_COLOCABLES = set(getattr(DB.ViewType, n) for n in nombres if hasattr(DB.ViewType, n))
    return _TIPOS_COLOCABLES


def nombre_tipo_vista(doc, vista):
    try:
        t = doc.GetElement(vista.GetTypeId())
        if t is not None:
            return nombre_de(t)
    except Exception:
        pass
    return _u(str(vista.ViewType))


def es_tabla(vista):
    return isinstance(vista, DB.ViewSchedule)


def es_cuadro(vista):
    return PanelScheduleView is not None and isinstance(vista, PanelScheduleView)


def vista_multiple(vista):
    """Tablas, cuadros de carga y leyendas pueden estar en varias láminas."""
    return es_tabla(vista) or es_cuadro(vista) or vista.ViewType == DB.ViewType.Legend


def tabla_colocable(vista):
    if not es_tabla(vista):
        return False
    for attr in (u'IsTitleblockRevisionSchedule', u'IsInternalKeynoteSchedule'):
        try:
            if getattr(vista, attr):
                return False
        except Exception:
            pass
    return True


def vistas_colocables(doc):
    """Vistas, tablas y leyendas que se pueden poner en una lámina: [(vista, nombre_tipo)]."""
    tipos = _tipos_colocables()
    res = []
    for v in DB.FilteredElementCollector(doc).OfClass(DB.View):
        try:
            if v.IsTemplate or isinstance(v, DB.ViewSheet):
                continue
            if v.ViewType not in tipos:
                continue
            if es_tabla(v) and not tabla_colocable(v):
                continue
            if v.ViewType == DB.ViewType.ThreeD and getattr(v, 'IsAssemblyView', False):
                continue
        except Exception:
            continue
        res.append((v, nombre_tipo_vista(doc, v)))
    res.sort(key=lambda x: core.clave_natural(x[0].Name))
    return res


def vistas_en_laminas(doc):
    """ViewId (int) -> número de la lámina donde ya está (solo vistas de una sola ubicación)."""
    res = {}
    for vp in DB.FilteredElementCollector(doc).OfClass(DB.Viewport):
        s = doc.GetElement(vp.SheetId)
        if s is not None:
            res[eid_int(vp.ViewId)] = _u(s.SheetNumber)
    return res


def buscar_vista(colocables, texto):
    """'Nivel 1' o 'Nivel 1 [Plano de techo]'. Devuelve (vista, error)."""
    texto = _u(texto).strip()
    tipo = u''
    if texto.endswith(u']') and u'[' in texto:
        texto, _, tipo = texto[:-1].rpartition(u'[')
        texto = texto.strip()
    n = core.normalizar(texto)
    exactos = [(v, t) for v, t in colocables if _u(v.Name) == texto]
    candidatos = exactos or [(v, t) for v, t in colocables if core.normalizar(v.Name) == n]
    if tipo:
        candidatos = [(v, t) for v, t in candidatos if core.normalizar(t) == core.normalizar(tipo)]
    if len(candidatos) == 1:
        return candidatos[0][0], u''
    if not candidatos:
        return None, u'No existe la vista «%s»' % (texto + (u' [%s]' % tipo if tipo else u''))
    return None, (u'Hay %d vistas «%s»: escriba también el tipo, p. ej. «%s [%s]»'
                  % (len(candidatos), texto, texto, candidatos[0][1]))


def puede_colocar(doc, lamina_id, vista):
    if es_tabla(vista):
        return tabla_colocable(vista)
    if es_cuadro(vista) or vista.ViewType == DB.ViewType.Legend:
        return True
    try:
        return DB.Viewport.CanAddViewToSheet(doc, lamina_id, vista.Id)
    except Exception:
        return False


# ============================================================================ datos para Excel e índice

def info_proyecto(doc, solo_con_valor=False):
    """[(nombre, valor)] de la Información del proyecto (parámetros de texto editables)."""
    info = doc.ProjectInformation
    res = []
    vistos = set()
    preferidos = [b for b, _ in ALIAS_PROYECTO]
    for bname in preferidos:
        b = bip(bname)
        p = info.get_Parameter(b) if b is not None else None
        if p is not None and not p.IsReadOnly:
            nombre = _u(p.Definition.Name)
            vistos.add(core.normalizar(nombre))
            valor = texto_param(p)
            if valor or not solo_con_valor:
                res.append((nombre, valor, bname))
    otros = []
    for p in info.Parameters:
        try:
            if p.IsReadOnly or p.StorageType != DB.StorageType.String:
                continue
            nombre = _u(p.Definition.Name)
        except Exception:
            continue
        if core.normalizar(nombre) in vistos:
            continue
        if eid_int(p.Id) < 0:
            continue  # otros incorporados (p. ej. «Nombre del edificio» ya está arriba)
        vistos.add(core.normalizar(nombre))
        otros.append((nombre, texto_param(p), u''))
    otros.sort(key=lambda x: core.clave_natural(x[0]))
    return res + [o for o in otros if o[1] or not solo_con_valor]


COLUMNAS_INCORPORADAS = [
    (u'Dibujado por', u'SHEET_DRAWN_BY'),
    (u'Revisado por', u'SHEET_CHECKED_BY'),
    (u'Diseñado por', u'SHEET_DESIGNED_BY'),
    (u'Aprobado por', u'SHEET_APPROVED_BY'),
    (u'Fecha de emisión', u'SHEET_ISSUE_DATE'),
]


def _params_propios(el):
    """Parámetros editables de texto/número que NO son incorporados (compartidos o de proyecto/familia)."""
    res = []
    if el is None:
        return res
    for p in el.Parameters:
        try:
            if p.IsReadOnly or eid_int(p.Id) < 0:
                continue
            if p.StorageType == DB.StorageType.ElementId:
                continue
            res.append(p)
        except Exception:
            continue
    return res


def datos_laminas(doc, especialidades):
    """Láminas del modelo como dicts para el Excel (incluye parámetros propios de la lámina y del rótulo)."""
    hojas = [s for s in laminas(doc) if not s.IsPlaceholder]
    extra = []
    vistos = set(core.normalizar(c) for c, _ in COLUMNAS_INCORPORADAS)
    info_n = set(core.normalizar(x[0]) for x in info_proyecto(doc))
    datos = []
    en_lamina = {}
    for vp in DB.FilteredElementCollector(doc).OfClass(DB.Viewport):
        en_lamina.setdefault(eid_int(vp.SheetId), []).append(vp)
    # nombres de vista repetidos (p. ej. «Nivel 1» en planta y en techo): se escriben con su tipo
    conteo = {}
    for v, t in vistas_colocables(doc):
        n = core.normalizar(v.Name)
        conteo[n] = conteo.get(n, 0) + 1
    for s in hojas:
        tb = rotulo_de(doc, s)
        params = {}
        for col, bname in COLUMNAS_INCORPORADAS:
            b = bip(bname)
            p = s.get_Parameter(b) if b is not None else None
            params[col] = texto_param(p)
        for el in (s, tb):
            for p in _params_propios(el):
                nombre = _u(p.Definition.Name)
                n = core.normalizar(nombre)
                if n in info_n:
                    continue  # parámetros del proyecto: van en la hoja PROYECTO
                if n not in vistos:
                    vistos.add(n)
                    extra.append(nombre)
                if nombre not in params or not params[nombre]:
                    params[nombre] = texto_param(p)
        vistas = []
        for vp in sorted(en_lamina.get(eid_int(s.Id), []), key=lambda v: eid_int(v.Id)):
            v = doc.GetElement(vp.ViewId)
            if v is not None:
                if conteo.get(core.normalizar(v.Name), 0) > 1:
                    vistas.append(u'%s [%s]' % (_u(v.Name), nombre_tipo_vista(doc, v)))
                else:
                    vistas.append(_u(v.Name))
        datos.append(dict(especialidad=especialidades.de_numero(s.SheetNumber), numero=_u(s.SheetNumber),
                          nombre=_u(s.Name), rotulo=texto_rotulo(doc.GetElement(tb.GetTypeId())) if tb else u'',
                          vistas=u'; '.join(vistas), uid=_u(s.UniqueId), parametros=params))
    return datos, extra


def datos_indice(doc, hojas):
    res = []
    for s in hojas:
        b1 = bip(u'SHEET_CURRENT_REVISION')
        b2 = bip(u'SHEET_CURRENT_REVISION_DATE')
        res.append(dict(numero=_u(s.SheetNumber), nombre=_u(s.Name), uid=_u(s.UniqueId),
                        revision=texto_param(s.get_Parameter(b1)) if b1 is not None else u'',
                        fecha_revision=texto_param(s.get_Parameter(b2)) if b2 is not None else u''))
    return res


def info_para_indice(doc):
    info = doc.ProjectInformation

    def val(bname):
        b = bip(bname)
        p = info.get_Parameter(b) if b is not None else None
        if p is None:
            return u''
        texto = texto_param(p)
        # Revit llena la Información del proyecto con el nombre del parámetro («Número de proyecto»): no sirve
        try:
            if core.normalizar(texto) == core.normalizar(p.Definition.Name):
                return u''
        except Exception:
            pass
        return texto

    return dict(proyecto=val(u'PROJECT_NAME'), numero=val(u'PROJECT_NUMBER'), cliente=val(u'CLIENT_NAME'),
                direccion=val(u'PROJECT_ADDRESS'))


def datos_patron(doc, lamina, especialidades):
    """Valores para el patrón de nombre de archivo."""
    import datetime
    i = info_para_indice(doc)
    cod = especialidades.de_numero(lamina.SheetNumber)
    b1 = bip(u'SHEET_CURRENT_REVISION')
    b2 = bip(u'SHEET_CURRENT_REVISION_DATE')
    return {u'Numero': _u(lamina.SheetNumber), u'Nombre': _u(lamina.Name), u'Codigo': cod,
            u'Especialidad': especialidades.nombre(cod),
            u'Revision': texto_param(lamina.get_Parameter(b1)) if b1 is not None else u'',
            u'FechaRevision': texto_param(lamina.get_Parameter(b2)) if b2 is not None else u'',
            u'Proyecto': i[u'proyecto'], u'NumeroProyecto': i[u'numero'], u'Cliente': i[u'cliente'],
            u'Fecha': datetime.date.today().strftime(u'%Y-%m-%d')}


# ============================================================================ importar desde Excel

class Detalle(object):
    """Datos de Revit que se agregan a cada Accion del plan."""

    def __init__(self):
        self.lamina = None
        self.rotulo = None          # FamilySymbol para láminas nuevas
        self.rotulo_texto = u''
        self.params = []            # [(nombre, valor)] a escribir
        self.vistas = []            # [View]
        self.n_cambios_param = 0


def detallar(doc, acciones, rotulos_lista, colocables, en_laminas, colocar_vistas=True):
    """Valida rótulos, parámetros y vistas de cada acción; agrega cambios, avisos y errores."""
    por_uid = {}
    for s in laminas(doc):
        por_uid[_u(s.UniqueId)] = s
    # vistas, leyendas y tablas que ya están en cada lámina (para no volver a colocarlas)
    en_cada = {}
    for vp in DB.FilteredElementCollector(doc).OfClass(DB.Viewport):
        en_cada.setdefault(eid_int(vp.SheetId), set()).add(eid_int(vp.ViewId))
    clases = [DB.ScheduleSheetInstance] + ([PanelScheduleSheetInstance] if PanelScheduleSheetInstance else [])
    for clase in clases:
        for si in DB.FilteredElementCollector(doc).OfClass(clase):
            try:
                vid = si.ScheduleId if hasattr(si, 'ScheduleId') else si.GetPanelScheduleView().Id
                en_cada.setdefault(eid_int(si.OwnerViewId), set()).add(eid_int(vid))
            except Exception:
                pass
    vistas_pedidas = {}
    for a in acciones:
        d = Detalle()
        a.detalle = d
        if a.tipo == core.Accion.ERROR:
            continue
        f = a.fila
        if a.uid:
            d.lamina = por_uid.get(a.uid)
        # rótulo
        if f.rotulo:
            sim, err = buscar_rotulo(rotulos_lista, f.rotulo)
            if a.tipo == core.Accion.CREAR:
                if err:
                    a.errores.append(err)
                    a.tipo = core.Accion.ERROR
                    continue
                d.rotulo, d.rotulo_texto = sim, texto_rotulo(sim)
            elif sim is not None and d.lamina is not None:
                tb = rotulo_de(doc, d.lamina)
                if tb is None or eid_int(tb.GetTypeId()) != eid_int(sim.Id):
                    a.avisos.append(u'El rótulo de una lámina existente no se cambia (cámbielo en Revit)')
        # parámetros
        tb = rotulo_de(doc, d.lamina) if d.lamina is not None else None
        for nombre, valor in f.parametros:
            d.params.append((nombre, valor))
            if d.lamina is None:
                continue
            p, lugar = param_de_lamina(doc, d.lamina, tb, nombre)
            if p is None:
                a.avisos.append(u'No existe el parámetro «%s» (en la lámina, su rótulo ni el proyecto)' % nombre)
            elif p.IsReadOnly:
                a.avisos.append(u'«%s» es de solo lectura' % nombre)
            elif not mismo_valor(p, valor):
                d.n_cambios_param += 1
                if lugar == u'proyecto':
                    a.avisos.append(u'«%s» es de la Información del proyecto (afecta a todas las láminas)' % nombre)
                a.cambios.append(u'%s: «%s» → «%s»' % (nombre, texto_param(p), u'' if core.normalizar(valor) ==
                                                        core.normalizar(core.CLAVE_BORRAR) else valor))
        # vistas
        if colocar_vistas:
            for texto in f.vistas:
                v, err = buscar_vista(colocables, texto)
                if v is None:
                    a.avisos.append(err)
                    continue
                vid = eid_int(v.Id)
                if d.lamina is not None and vid in en_cada.get(eid_int(d.lamina.Id), set()):
                    continue  # ya está en esta lámina
                multiple = vista_multiple(v)
                if vid in en_laminas and not multiple:
                    if en_laminas[vid] != a.numero_actual or a.tipo == core.Accion.CREAR:
                        a.avisos.append(u'La vista «%s» ya está en la lámina %s' % (v.Name, en_laminas[vid]))
                    continue
                if not multiple and vid in vistas_pedidas:
                    a.avisos.append(u'La vista «%s» ya se pidió en la fila %d' % (v.Name, vistas_pedidas[vid]))
                    continue
                vistas_pedidas[vid] = f.fila
                d.vistas.append(v)
                a.cambios.append(u'Colocar «%s»' % v.Name)
        if a.tipo == core.Accion.SIN_CAMBIOS and (d.n_cambios_param or d.vistas):
            a.tipo = core.Accion.ACTUALIZAR
    return acciones


def colocar(doc, lamina, vistas, franja_pct=20.0, margen_pct=3.0):
    """Coloca vistas/tablas/leyendas ordenadas en filas dentro del área libre del rótulo. Devuelve avisos."""
    avisos = []
    colocados = []
    origen = DB.XYZ(0, 0, 0)
    for v in vistas:
        try:
            if not puede_colocar(doc, lamina.Id, v):
                avisos.append(u'Revit no permite colocar «%s» en esta lámina' % v.Name)
                continue
            if es_tabla(v):
                el = DB.ScheduleSheetInstance.Create(doc, lamina.Id, v.Id, origen)
            elif es_cuadro(v):
                el = PanelScheduleSheetInstance.Create(doc, v.Id, lamina)
            else:
                el = DB.Viewport.Create(doc, lamina.Id, v.Id, origen)
            colocados.append(el)
        except Exception as ex:
            avisos.append(u'No se pudo colocar «%s»: %s' % (v.Name, _u(ex)))
    if not colocados:
        return avisos
    doc.Regenerate()
    tb = rotulo_de(doc, lamina)
    bb = tb.get_BoundingBox(lamina) if tb is not None else None
    if bb is not None:
        x0, y0, x1, y1 = bb.Min.X, bb.Min.Y, bb.Max.X, bb.Max.Y
    else:  # sin rótulo: A1 horizontal (841 × 594 mm)
        x0, y0, x1, y1 = 0.0, 0.0, 841 / 304.8, 594 / 304.8
    ancho, alto = x1 - x0, y1 - y0
    margen = max(0.0, float(margen_pct)) / 100.0 * min(ancho, alto)
    franja = max(0.0, float(franja_pct)) / 100.0 * ancho
    ax0, ay0, ax1, ay1 = x0 + margen, y0 + margen, x1 - margen - franja, y1 - margen
    hueco = margen * 0.6
    medidas = []
    for el in colocados:
        b = el.get_BoundingBox(lamina)
        if b is None:
            medidas.append((el, 0.3, 0.3, DB.XYZ(0, 0, 0)))
            continue
        c = DB.XYZ((b.Min.X + b.Max.X) / 2, (b.Min.Y + b.Max.Y) / 2, 0)
        medidas.append((el, b.Max.X - b.Min.X, b.Max.Y - b.Min.Y, c))
    # filas de izquierda a derecha y de arriba abajo
    posiciones = []
    cx, cy, alto_fila = ax0, ay1, 0.0
    for el, w, h, c in medidas:
        if cx + w > ax1 + 1e-6 and cx > ax0 + 1e-6:
            cy -= alto_fila + hueco
            cx, alto_fila = ax0, 0.0
        posiciones.append((el, c, DB.XYZ(cx + w / 2, cy - h / 2, 0)))
        cx += w + hueco
        alto_fila = max(alto_fila, h)
    # centrar el bloque en el área libre
    minx = min(p.X - m[1] / 2 for (e, c, p), m in zip(posiciones, medidas))
    maxx = max(p.X + m[1] / 2 for (e, c, p), m in zip(posiciones, medidas))
    miny = min(p.Y - m[2] / 2 for (e, c, p), m in zip(posiciones, medidas))
    maxy = max(p.Y + m[2] / 2 for (e, c, p), m in zip(posiciones, medidas))
    dx = ((ax0 + ax1) / 2) - ((minx + maxx) / 2)
    dy = ((ay0 + ay1) / 2) - ((miny + maxy) / 2)
    if (maxx - minx) > (ax1 - ax0) + 1e-6 or (maxy - miny) > (ay1 - ay0) + 1e-6:
        sin_recorte = []
        for v in vistas:
            try:
                if not vista_multiple(v) and not v.CropBoxActive:
                    sin_recorte.append(_u(v.Name))
            except Exception:
                pass
        if sin_recorte:
            avisos.append(u'Las vistas no entran en el área libre del rótulo: «%s» no tiene la región de recorte '
                          u'activa (actívela para que solo ocupe el dibujo)' % u'», «'.join(sin_recorte))
        else:
            avisos.append(u'Las vistas no entran en el área libre del rótulo: revise sus escalas o recortes')
        dx = (ax0 - minx) if (maxx - minx) > (ax1 - ax0) else dx
        dy = (ay1 - maxy) if (maxy - miny) > (ay1 - ay0) else dy
    for el, c, p in posiciones:
        mov = DB.XYZ(p.X + dx - c.X, p.Y + dy - c.Y, 0)
        if mov.GetLength() > 1e-9:
            DB.ElementTransformUtils.MoveElement(doc, el.Id, mov)
    return avisos


class Cancelado(Exception):
    """El usuario canceló: se deshace todo lo hecho."""


class ErrorPlanos(Exception):
    """Error con mensaje para el usuario (en español)."""


def _confirmar(t, que):
    estado = t.Commit()
    if estado != DB.TransactionStatus.Committed:
        raise ErrorPlanos(u'Revit no aceptó los cambios (%s). No se modificó el modelo.' % que)


def _deshacer(t, tg=None):
    try:
        if t is not None and t.HasStarted() and not t.HasEnded():
            t.RollBack()
    except Exception:
        pass
    try:
        if tg is not None and tg.HasStarted() and not tg.HasEnded():
            tg.RollBack()
    except Exception:
        pass


def aplicar_plan(doc, acciones, opciones, progreso=None):
    """Aplica el plan. opciones: dict(crear, actualizar, vistas, rotulo_defecto (FamilySymbol o None),
    franja_pct, margen_pct, proyecto [(nombre, valor)]). Devuelve (resultados, avisos_proyecto).

    resultados: [(accion, lamina o None, [avisos], error)]. Si el usuario cancela se lanza Cancelado y no queda
    ningún cambio en el modelo (todo es un solo grupo de transacciones)."""
    resultados = []
    avisos_proyecto = []
    tg = DB.TransactionGroup(doc, u'PlanosALF: láminas desde Excel')
    tg.Start()
    t = None
    try:
        # 1) Información del proyecto
        if opciones.get(u'proyecto'):
            t = transaccion(doc, u'PlanosALF: información del proyecto')
            t.Start()
            for nombre, valor in opciones[u'proyecto']:
                p = param_de_proyecto(doc, nombre)
                if p is None:
                    avisos_proyecto.append(u'No existe el parámetro del proyecto «%s»' % nombre)
                    continue
                if mismo_valor(p, valor):
                    continue
                err = escribir_param(p, valor)
                if err:
                    avisos_proyecto.append(u'«%s»: %s' % (nombre, err))
            _confirmar(t, u'información del proyecto')

        elegidas = [a for a in acciones if a.aplicar and (
            (a.tipo == core.Accion.CREAR and opciones.get(u'crear', True)) or
            (a.tipo == core.Accion.ACTUALIZAR and opciones.get(u'actualizar', True)))]
        total = len(elegidas)

        # 2) números: primero temporales (permite intercambiar E-01 y E-02), luego los definitivos
        t = transaccion(doc, u'PlanosALF: crear y actualizar láminas')
        t.Start()
        renumerar_ = [a for a in elegidas if a.tipo == core.Accion.ACTUALIZAR and a.detalle.lamina is not None
                      and a.numero != a.numero_actual]
        for i, a in enumerate(renumerar_):
            a.detalle.lamina.SheetNumber = u'PLANOSALF-TMP-%d-%s' % (i, a.numero_actual)
        hechos = 0
        for a in elegidas:
            if progreso and progreso(hechos, total):
                raise Cancelado()
            hechos += 1
            d = a.detalle
            avisos = []
            nueva = None
            try:
                if a.tipo == core.Accion.CREAR:
                    sim = d.rotulo or opciones.get(u'rotulo_defecto')
                    if sim is not None and not sim.IsActive:
                        sim.Activate()
                    nueva = DB.ViewSheet.Create(doc, sim.Id if sim is not None else DB.ElementId.InvalidElementId)
                    nueva.SheetNumber = a.numero
                    nueva.Name = a.nombre
                    lam = d.lamina = nueva
                    doc.Regenerate()
                else:
                    lam = d.lamina
                    if a.numero != _u(lam.SheetNumber):
                        lam.SheetNumber = a.numero
                    if a.nombre and a.nombre != _u(lam.Name):
                        lam.Name = a.nombre
                tb = rotulo_de(doc, lam)
                for nombre, valor in d.params:
                    p, lugar = param_de_lamina(doc, lam, tb, nombre)
                    if p is None:
                        avisos.append(u'No existe «%s»' % nombre)
                        continue
                    if mismo_valor(p, valor):
                        continue
                    err = escribir_param(p, valor)
                    if err:
                        avisos.append(u'«%s» %s' % (nombre, err))
                if opciones.get(u'vistas', True) and d.vistas:
                    avisos.extend(colocar(doc, lam, d.vistas, opciones.get(u'franja_pct', 20.0),
                                          opciones.get(u'margen_pct', 3.0)))
                resultados.append((a, lam, avisos, u''))
            except Exception as ex:
                if nueva is not None:   # no dejar una lámina «Sin nombre» a medio crear
                    try:
                        doc.Delete(nueva.Id)
                    except Exception:
                        pass
                    d.lamina = None
                resultados.append((a, None if nueva is not None else d.lamina, avisos, _u(ex)))
        # 3) ningún número temporal puede quedar: se devuelve el número original o se deshace todo
        quedan = []
        for a in renumerar_:
            lam = a.detalle.lamina
            if _u(lam.SheetNumber).startswith(u'PLANOSALF-TMP-'):
                try:
                    lam.SheetNumber = a.numero_actual
                except Exception:
                    quedan.append(a.numero_actual)
        if quedan:
            raise ErrorPlanos(u'No se pudo devolver su número a: %s (otra lámina ya lo usa). No se modificó el '
                              u'modelo; revise los números del Excel.' % u', '.join(quedan))
        _confirmar(t, u'láminas')
        t = None
        tg.Assimilate()
    except Exception:
        _deshacer(t, tg)
        raise
    return resultados, avisos_proyecto


# ============================================================================ renumerar

def renumerar(doc, cambios, param_total=u'', especialidades=None):
    """cambios: [(uid, actual, nuevo)]. Todo o nada: si una lámina no se puede renumerar, no cambia ninguna.
    Devuelve (hechos, errores, avisos)."""
    por_uid = dict((_u(s.UniqueId), s) for s in laminas(doc))
    errores = []
    avisos = []
    hechos = 0
    t = transaccion(doc, u'PlanosALF: renumerar láminas')
    t.Start()
    try:
        pendientes = [(por_uid.get(uid), actual, nuevo) for uid, actual, nuevo in cambios if actual != nuevo]
        for s, actual, nuevo in pendientes:
            if s is None:
                errores.append(u'%s: la lámina ya no existe' % actual)
        if not errores:
            for i, (s, actual, nuevo) in enumerate(pendientes):
                s.SheetNumber = u'PLANOSALF-TMP-%d-%s' % (i, actual)
            for s, actual, nuevo in pendientes:
                try:
                    s.SheetNumber = nuevo
                    hechos += 1
                except Exception as ex:
                    errores.append(u'%s → %s: %s' % (actual, nuevo, _u(ex)))
        if errores:
            _deshacer(t)
            return 0, errores, avisos
        if param_total and especialidades is not None:
            conteo = {}
            hojas = [s for s in laminas(doc) if not s.IsPlaceholder]
            for s in hojas:
                cod = especialidades.de_numero(s.SheetNumber)
                conteo[cod] = conteo.get(cod, 0) + 1
            afectadas = set(especialidades.de_numero(n) for _, _, n in cambios)
            sin_param = 0
            for s in hojas:
                cod = especialidades.de_numero(s.SheetNumber)
                if cod not in afectadas:
                    continue
                p, lugar = param_de_lamina(doc, s, rotulo_de(doc, s), param_total)
                if p is None or lugar == u'proyecto':
                    sin_param += 1
                    continue
                total = _u(str(conteo.get(cod, 0)))
                if not mismo_valor(p, total):
                    err = escribir_param(p, total)
                    if err:
                        avisos.append(u'%s: «%s» %s' % (s.SheetNumber, param_total, err))
            if sin_param:
                avisos.append(u'%d lámina(s) no tienen el parámetro «%s» (ni en su rótulo)' % (sin_param, param_total))
        _confirmar(t, u'renumerar')
    except Exception:
        _deshacer(t)
        raise
    return hechos, errores, avisos


# ============================================================================ exportar

def opciones_pdf(cfg):
    o = DB.PDFExportOptions()

    def poner(attr, valor):
        try:
            setattr(o, attr, valor)
        except Exception:
            pass

    color = {u'color': u'Color', u'grises': u'GrayScale', u'negro': u'BlackLine'}.get(cfg.get(u'color_pdf'), u'Color')
    poner(u'ColorDepth', getattr(DB.ColorDepthType, color))
    calidad = {u'baja': u'Low', u'media': u'Medium', u'alta': u'High',
               u'presentacion': u'Presentation'}.get(cfg.get(u'calidad_pdf'), u'High')
    poner(u'RasterQuality', getattr(DB.RasterQualityType, calidad))
    try:
        ppp = {u'Low': u'DPI144', u'Medium': u'DPI300', u'High': u'DPI600', u'Presentation': u'DPI1200'}[calidad]
        poner(u'ExportQuality', getattr(DB.PDFExportQualityType, ppp))
    except Exception:
        pass
    poner(u'PaperFormat', DB.ExportPaperFormat.Default)
    poner(u'ZoomType', DB.ZoomType.Zoom)
    poner(u'ZoomPercentage', 100)
    poner(u'HideCropBoundaries', bool(cfg.get(u'ocultar_recortes', True)))
    poner(u'HideReferencePlane', bool(cfg.get(u'ocultar_ref', True)))
    poner(u'HideScopeBoxes', bool(cfg.get(u'ocultar_cajas', True)))
    poner(u'HideUnreferencedViewTags', bool(cfg.get(u'ocultar_etiquetas', True)))
    poner(u'StopOnError', False)
    return o


def opciones_dwg(doc, cfg):
    o = None
    nombre = cfg.get(u'config_dwg') or u''
    if nombre:
        try:
            o = DB.DWGExportOptions.GetPredefinedOptions(doc, nombre)
        except Exception:
            o = None
    if o is None:
        o = DB.DWGExportOptions()
    try:
        o.MergedViews = bool(cfg.get(u'dwg_unido', True))
    except Exception:
        pass
    version = u'R' + _u(cfg.get(u'version_dwg') or u'2018')
    if hasattr(DB.ACADVersion, version):
        try:
            o.FileVersion = getattr(DB.ACADVersion, version)
        except Exception:
            pass
    return o


def configuraciones_dwg(doc):
    try:
        return sorted(_u(n) for n in DB.BaseExportOptions.GetPredefinedSetupNames(doc))
    except Exception:
        return []


def _preparar_destino(ruta, sobrescribir):
    """Devuelve la ruta final (con (2) si no se sobrescribe) o lanza IOError si está abierta/bloqueada."""
    if not os.path.exists(ruta):
        return ruta
    if sobrescribir:
        try:
            os.remove(ruta)
            return ruta
        except OSError:
            raise IOError(u'El archivo está abierto en otro programa: %s' % os.path.basename(ruta))
    base, ext = os.path.splitext(ruta)
    i = 2
    while os.path.exists(u'%s (%d)%s' % (base, i, ext)):
        i += 1
    return u'%s (%d)%s' % (base, i, ext)


def exportar_pdf(doc, ids, carpeta, nombre, opciones, sobrescribir=True):
    """Exporta una o varias láminas a UN PDF combinado con el nombre dado. Devuelve la ruta."""
    if not os.path.isdir(carpeta):
        os.makedirs(carpeta)
    ruta = _preparar_destino(os.path.join(carpeta, nombre + u'.pdf'), sobrescribir)
    opciones.Combine = True
    opciones.FileName = os.path.splitext(os.path.basename(ruta))[0]
    lista = List[DB.ElementId]()
    for i in ids:
        lista.Add(i)
    ok = doc.Export(carpeta, lista, opciones)
    if not ok or not os.path.exists(ruta):
        raise IOError(u'Revit no generó el PDF')
    return ruta


def exportar_dwg(doc, lamina_id, carpeta, nombre, opciones, sobrescribir=True):
    if not os.path.isdir(carpeta):
        os.makedirs(carpeta)
    ruta = _preparar_destino(os.path.join(carpeta, nombre + u'.dwg'), sobrescribir)
    lista = List[DB.ElementId]()
    lista.Add(lamina_id)
    base = os.path.splitext(os.path.basename(ruta))[0]
    ok = doc.Export(carpeta, base, lista, opciones)
    if not ok or not os.path.exists(ruta):
        raise IOError(u'Revit no generó el DWG')
    # Revit deja un .pcp (registro de capas) junto a cada DWG: no forma parte del entregable
    pcp = os.path.join(carpeta, base + u'.pcp')
    if os.path.exists(pcp):
        try:
            os.remove(pcp)
        except OSError:
            pass
    return ruta
