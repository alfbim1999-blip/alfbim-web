# -*- coding: utf-8 -*-
"""Configuración de PlanosALF (por usuario): %APPDATA%\\ALF_BIM\\PlanosALF\\config.json."""
from __future__ import print_function

import io
import json
import os

from planosalf import core, xlsx

_u = xlsx._u

VERSION = u'1.0.0'
PRODUCTO = u'PlanosALF'
WEB = u'https://www.alfbim.com'
CORREO = u'andersonirigoin@gmail.com'
AUTOR = u'Ing. Anderson Irigoín C. — ALF_BIM'

CARPETA_LIB = os.path.dirname(os.path.abspath(__file__))
CARPETA_EXT = os.path.dirname(os.path.dirname(CARPETA_LIB))   # ...\PlanosALF.extension
CARPETA_RECURSOS = os.path.join(CARPETA_EXT, u'recursos')


def carpeta_usuario():
    base = os.environ.get('APPDATA') or os.path.expanduser(u'~')
    carpeta = os.path.join(_u(base), u'ALF_BIM', u'PlanosALF')
    if not os.path.isdir(carpeta):
        try:
            os.makedirs(carpeta)
        except OSError:
            pass
    return carpeta


def ruta_config():
    return os.path.join(carpeta_usuario(), u'config.json')


def carpeta_documentos():
    perfil = os.environ.get('USERPROFILE') or os.path.expanduser(u'~')
    doc = os.path.join(_u(perfil), u'Documents')
    return doc if os.path.isdir(doc) else _u(perfil)


DEFECTO = {
    u'especialidades': [[c, n] for c, n in core.ESPECIALIDADES_PERU],
    u'separador': u'-',
    u'digitos': 2,
    u'rotulo_defecto': u'',
    # colocación automática de vistas: franja del rótulo a la derecha (% del ancho) y margen (% del lado menor)
    u'franja_rotulo_pct': 20.0,
    u'margen_pct': 3.0,
    u'formato_fecha': u'%d/%m/%Y',
    # exportación
    u'carpeta_exportacion': u'',
    u'patron_archivo': u'{Numero}',
    u'pdf': True,
    u'dwg': False,
    u'subcarpetas': True,
    u'modo_pdf': u'separado',          # separado | especialidad | uno
    u'color_pdf': u'color',           # color | grises | negro
    u'calidad_pdf': u'media',         # media (300 ppp) | alta (600) | presentacion (1200)
    u'ocultar_recortes': True,
    u'ocultar_ref': True,
    u'ocultar_cajas': True,
    u'ocultar_etiquetas': True,
    u'config_dwg': u'',
    u'version_dwg': u'2018',
    u'dwg_unido': True,
    u'indice_excel': True,
    u'sobrescribir': True,
    u'abrir_carpeta': True,
    # renumeración
    u'renum_inicio': 1,
    u'renum_incremento': 1,
    u'renum_param_total': u'',
    # crear desde Excel
    u'ultimo_excel': u'',
    u'crear_nuevas': True,
    u'actualizar': True,
    u'colocar_vistas': True,
    u'info_proyecto': True,
}


class Config(dict):
    def especialidades(self):
        return core.Especialidades([tuple(p) for p in self.get(u'especialidades') or []] or None)

    def guardar(self):
        ruta = ruta_config()
        try:
            texto = json.dumps(dict(self), ensure_ascii=False, indent=2, sort_keys=True)
            with io.open(ruta, 'w', encoding='utf-8') as f:
                f.write(_u(texto))
        except Exception:
            pass  # la configuración es una comodidad: nunca debe detener un comando


def cargar():
    cfg = Config(DEFECTO)
    ruta = ruta_config()
    if os.path.isfile(ruta):
        try:
            with io.open(ruta, 'r', encoding='utf-8') as f:
                datos = json.loads(f.read())
            if isinstance(datos, dict):
                for k, v in datos.items():
                    if k in DEFECTO and v is not None:
                        cfg[k] = v
        except Exception:
            pass
    try:
        cfg[u'digitos'] = max(1, min(5, int(cfg[u'digitos'])))
    except Exception:
        cfg[u'digitos'] = 2
    if cfg.get(u'separador') is None:
        cfg[u'separador'] = u'-'
    return cfg


def recurso(nombre):
    return os.path.join(CARPETA_RECURSOS, nombre)
