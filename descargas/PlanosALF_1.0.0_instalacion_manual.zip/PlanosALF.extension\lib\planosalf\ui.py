# -*- coding: utf-8 -*-
"""Ventanas de PlanosALF (WPF) con la marca ALF_BIM. Las ventanas solo recogen datos; las operaciones con el
modelo se hacen en revit_ops desde cada botón."""
from __future__ import print_function, division

import os

import clr
clr.AddReference('System.Data')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')
clr.AddReference('WindowsBase')
try:
    clr.AddReference('System.Diagnostics.Process')  # .NET 8/10 (Revit 2025+)
except Exception:
    pass
import System  # noqa: E402
from System.Data import DataTable  # noqa: E402
from System.Diagnostics import Process, ProcessStartInfo  # noqa: E402
from System.Windows.Media.Imaging import BitmapImage  # noqa: E402

from pyrevit import forms  # noqa: E402

from planosalf import config, core, xlsx  # noqa: E402

_u = xlsx._u

T_BOOL = clr.GetClrType(System.Boolean)
T_STR = clr.GetClrType(System.String)
T_INT = clr.GetClrType(System.Int32)


# ============================================================================ utilidades

def abrir(ruta_o_url):
    """Abre una carpeta, archivo o página web con el programa predeterminado."""
    try:
        psi = ProcessStartInfo(_u(ruta_o_url))
        psi.UseShellExecute = True
        Process.Start(psi)
        return True
    except Exception:
        return False


def numero(texto, defecto, minimo=None, maximo=None, real=False):
    try:
        v = float(_u(texto).replace(u',', u'.')) if real else int(float(_u(texto).replace(u',', u'.')))
    except Exception:
        v = defecto
    if minimo is not None:
        v = max(minimo, v)
    if maximo is not None:
        v = min(maximo, v)
    return v


def tabla(columnas):
    """DataTable con columnas [(nombre, tipo)] donde tipo es 'b', 's' o 'i'."""
    t = DataTable()
    for nombre, tipo in columnas:
        t.Columns.Add(nombre, {u'b': T_BOOL, u's': T_STR, u'i': T_INT}[tipo])
    return t


def fila_tabla(t, valores):
    r = t.NewRow()
    for k, v in valores.items():
        r[k] = v
    t.Rows.Add(r)
    return r


ESTILOS = u'''
<Window.Resources>
  <SolidColorBrush x:Key="Negro" Color="#0B0B0B"/>
  <SolidColorBrush x:Key="Azul" Color="#2F7CF6"/>
  <SolidColorBrush x:Key="Turquesa" Color="#0F766E"/>
  <SolidColorBrush x:Key="Gris" Color="#5F5F5F"/>
  <Style TargetType="Button">
    <Setter Property="Padding" Value="14,5"/>
    <Setter Property="Margin" Value="4"/>
    <Setter Property="MinWidth" Value="84"/>
    <Setter Property="Background" Value="White"/>
    <Setter Property="BorderBrush" Value="#B9B9B9"/>
    <Setter Property="Cursor" Value="Hand"/>
  </Style>
  <Style x:Key="Primario" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}">
    <Setter Property="Background" Value="#2F7CF6"/>
    <Setter Property="Foreground" Value="White"/>
    <Setter Property="BorderBrush" Value="#1F5FC9"/>
    <Setter Property="FontWeight" Value="Bold"/>
    <Setter Property="MinWidth" Value="120"/>
  </Style>
  <Style x:Key="Chico" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}">
    <Setter Property="Padding" Value="8,2"/>
    <Setter Property="MinWidth" Value="0"/>
    <Setter Property="Margin" Value="0,0,6,0"/>
  </Style>
  <Style TargetType="TextBox">
    <Setter Property="Height" Value="28"/>
    <Setter Property="Padding" Value="4,3"/>
    <Setter Property="Margin" Value="4,3"/>
    <Setter Property="VerticalContentAlignment" Value="Center"/>
  </Style>
  <Style TargetType="ComboBox">
    <Setter Property="Margin" Value="4,3"/>
    <Setter Property="Padding" Value="6,3"/>
    <Setter Property="Height" Value="28"/>
    <Setter Property="VerticalContentAlignment" Value="Center"/>
  </Style>
  <Style TargetType="CheckBox">
    <Setter Property="Margin" Value="4,4"/>
    <Setter Property="VerticalContentAlignment" Value="Center"/>
  </Style>
  <Style TargetType="RadioButton">
    <Setter Property="Margin" Value="4,4"/>
    <Setter Property="VerticalContentAlignment" Value="Center"/>
  </Style>
  <Style TargetType="GroupBox">
    <Setter Property="Margin" Value="0,0,0,8"/>
    <Setter Property="Padding" Value="6,4"/>
    <Setter Property="BorderBrush" Value="#CFCFCF"/>
    <Setter Property="FontWeight" Value="Normal"/>
  </Style>
  <Style TargetType="DataGridColumnHeader">
    <Setter Property="Background" Value="#0B0B0B"/>
    <Setter Property="Foreground" Value="White"/>
    <Setter Property="Padding" Value="6,5"/>
    <Setter Property="FontWeight" Value="Bold"/>
    <Setter Property="BorderBrush" Value="#3A3A3A"/>
    <Setter Property="BorderThickness" Value="0,0,1,0"/>
  </Style>
  <Style TargetType="DataGrid">
    <Setter Property="AutoGenerateColumns" Value="False"/>
    <Setter Property="CanUserAddRows" Value="False"/>
    <Setter Property="CanUserDeleteRows" Value="False"/>
    <Setter Property="CanUserResizeRows" Value="False"/>
    <Setter Property="RowHeaderWidth" Value="0"/>
    <Setter Property="GridLinesVisibility" Value="Horizontal"/>
    <Setter Property="HorizontalGridLinesBrush" Value="#E4E4E4"/>
    <Setter Property="AlternatingRowBackground" Value="#F4F8FF"/>
    <Setter Property="Background" Value="White"/>
    <Setter Property="BorderBrush" Value="#CFCFCF"/>
    <Setter Property="SelectionMode" Value="Extended"/>
    <Setter Property="SelectionUnit" Value="FullRow"/>
    <Setter Property="HeadersVisibility" Value="Column"/>
  </Style>
  <Style TargetType="DataGridCell">
    <Setter Property="Padding" Value="4,2"/>
    <Setter Property="VerticalContentAlignment" Value="Center"/>
    <Style.Triggers>
      <Trigger Property="IsSelected" Value="True">
        <Setter Property="Background" Value="#D6E6FF"/>
        <Setter Property="Foreground" Value="Black"/>
        <Setter Property="BorderBrush" Value="#D6E6FF"/>
      </Trigger>
    </Style.Triggers>
  </Style>
  <Style x:Key="Nota" TargetType="TextBlock">
    <Setter Property="Foreground" Value="#5F5F5F"/>
    <Setter Property="FontSize" Value="12"/>
    <Setter Property="TextWrapping" Value="Wrap"/>
  </Style>
  <Style x:Key="Celda" TargetType="TextBlock">
    <Setter Property="TextWrapping" Value="Wrap"/>
    <Setter Property="VerticalAlignment" Value="Center"/>
  </Style>
</Window.Resources>
'''


def cabecera(subtitulo):
    return u'''
  <Border DockPanel.Dock="Top" Background="#0B0B0B" Padding="16,10">
    <Grid>
      <StackPanel Orientation="Horizontal">
        <Image x:Name="img_logo" Width="44" Height="44" Margin="0,0,12,0" RenderOptions.BitmapScalingMode="HighQuality"/>
        <StackPanel VerticalAlignment="Center">
          <TextBlock Text="PlanosALF" Foreground="White" FontSize="21" FontWeight="Bold"/>
          <TextBlock Text="%s" Foreground="#8EE3D6" FontSize="13"/>
        </StackPanel>
      </StackPanel>
      <StackPanel HorizontalAlignment="Right" VerticalAlignment="Center">
        <TextBlock Text="ALF_BIM" Foreground="White" FontWeight="Bold" FontSize="15" HorizontalAlignment="Right"/>
        <TextBlock Text="www.alfbim.com" Foreground="#9FC2FF" FontSize="12" HorizontalAlignment="Right"/>
      </StackPanel>
    </Grid>
  </Border>''' % subtitulo


def ventana_xaml(titulo, subtitulo, cuerpo, ancho=980, alto=640, pie=u''):
    return u'''<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="%s" Width="%d" Height="%d" MinWidth="640" MinHeight="420"
        WindowStartupLocation="CenterScreen" ResizeMode="CanResizeWithGrip" ShowInTaskbar="False"
        FontFamily="Times New Roman" FontSize="14" Background="#F7F7F5">
%s
<DockPanel LastChildFill="True">
%s
  <Border DockPanel.Dock="Bottom" Background="White" BorderBrush="#DADADA" BorderThickness="0,1,0,0" Padding="12,6">
    <DockPanel>
      %s
    </DockPanel>
  </Border>
  <Grid Margin="14,10,14,8">
%s
  </Grid>
</DockPanel>
</Window>''' % (titulo, ancho, alto, ESTILOS, cabecera(subtitulo), pie, cuerpo)


def _esc(texto):
    return xlsx._xml_escape(texto)


class VentanaALF(forms.WPFWindow):
    def __init__(self, xaml):
        forms.WPFWindow.__init__(self, xaml, literal_string=True)
        self.resultado = None
        logo = config.recurso(u'PlanosALF_logo_blanco.png')
        if not os.path.isfile(logo):
            logo = config.recurso(u'PlanosALF_logo.png')
        if os.path.isfile(logo):
            try:
                img = BitmapImage()
                img.BeginInit()
                img.UriSource = System.Uri(logo)
                img.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad
                img.EndInit()
                self.img_logo.Source = img
                self.Icon = img
            except Exception:
                pass

    def cerrar(self, sender=None, args=None):
        self.Close()


# ============================================================================ importar desde Excel

class VentanaImportar(VentanaALF):
    """Vista previa del plan. resultado = dict(opciones) o None."""

    def __init__(self, ruta_excel, acciones, rotulos_textos, rotulo_defecto, n_proyecto, avisos_excel, cfg):
        cuerpo = u'''
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
    </Grid.RowDefinitions>
    <TextBlock Grid.Row="0" x:Name="txt_excel" TextTrimming="CharacterEllipsis" Margin="0,0,0,6"/>
    <WrapPanel Grid.Row="1" Margin="0,0,0,4">
      <Border Background="#E6F4EA" CornerRadius="3" Padding="8,3" Margin="0,0,6,0"><TextBlock x:Name="txt_crear"/></Border>
      <Border Background="#E3EDFF" CornerRadius="3" Padding="8,3" Margin="0,0,6,0"><TextBlock x:Name="txt_actualizar"/></Border>
      <Border Background="#EFEFEF" CornerRadius="3" Padding="8,3" Margin="0,0,6,0"><TextBlock x:Name="txt_igual"/></Border>
      <Border Background="#FDE7E7" CornerRadius="3" Padding="8,3" Margin="0,0,6,0"><TextBlock x:Name="txt_error"/></Border>
    </WrapPanel>
    <Grid Grid.Row="2" Margin="0,4,0,6">
      <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
      <WrapPanel Grid.Column="0">
        <CheckBox x:Name="chk_crear" Content="Crear láminas nuevas" IsChecked="True"/>
        <CheckBox x:Name="chk_actualizar" Content="Actualizar las existentes" IsChecked="True"/>
        <CheckBox x:Name="chk_vistas" Content="Colocar vistas" IsChecked="True"/>
        <CheckBox x:Name="chk_proyecto" Content="Información del proyecto" IsChecked="True"/>
      </WrapPanel>
      <StackPanel Grid.Column="1" Orientation="Horizontal">
        <TextBlock Text="Rótulo por defecto:" VerticalAlignment="Center" Margin="8,0,2,0"/>
        <ComboBox x:Name="cmb_rotulo" Width="250"/>
        <TextBlock Text="Mostrar:" VerticalAlignment="Center" Margin="10,0,2,0"/>
        <ComboBox x:Name="cmb_filtro" Width="150"/>
      </StackPanel>
    </Grid>
    <DataGrid Grid.Row="3" x:Name="grid" CanUserSortColumns="True">
      <DataGrid.Columns>
        <DataGridTemplateColumn Header="✓" Width="34">
          <DataGridTemplateColumn.CellTemplate><DataTemplate>
            <CheckBox IsChecked="{Binding Sel, UpdateSourceTrigger=PropertyChanged}" IsEnabled="{Binding Habil}"
                      HorizontalAlignment="Center" Margin="0"/>
          </DataTemplate></DataGridTemplateColumn.CellTemplate>
        </DataGridTemplateColumn>
        <DataGridTextColumn Header="Fila" Binding="{Binding Fila}" Width="48" IsReadOnly="True" ElementStyle="{StaticResource Celda}"/>
        <DataGridTextColumn Header="Acción" Binding="{Binding Accion}" Width="96" IsReadOnly="True">
          <DataGridTextColumn.ElementStyle>
            <Style TargetType="TextBlock">
              <Setter Property="FontWeight" Value="Bold"/>
              <Setter Property="VerticalAlignment" Value="Center"/>
              <Style.Triggers>
                <DataTrigger Binding="{Binding Accion}" Value="Crear"><Setter Property="Foreground" Value="#1E7B34"/></DataTrigger>
                <DataTrigger Binding="{Binding Accion}" Value="Actualizar"><Setter Property="Foreground" Value="#1F5FC9"/></DataTrigger>
                <DataTrigger Binding="{Binding Accion}" Value="Sin cambios"><Setter Property="Foreground" Value="#7F7F7F"/></DataTrigger>
                <DataTrigger Binding="{Binding Accion}" Value="Error"><Setter Property="Foreground" Value="#C00000"/></DataTrigger>
              </Style.Triggers>
            </Style>
          </DataGridTextColumn.ElementStyle>
        </DataGridTextColumn>
        <DataGridTextColumn Header="Número" Binding="{Binding Numero}" Width="90" IsReadOnly="True" ElementStyle="{StaticResource Celda}"/>
        <DataGridTextColumn Header="Nombre de lámina" Binding="{Binding Nombre}" Width="250" IsReadOnly="True"
                            ElementStyle="{StaticResource Celda}"/>
        <DataGridTextColumn Header="Detalle (cambios, errores y avisos)" Binding="{Binding Detalle}" Width="*"
                            IsReadOnly="True" ElementStyle="{StaticResource Celda}"/>
      </DataGrid.Columns>
    </DataGrid>'''
        pie = u'''<StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
        <Button x:Name="btn_cancelar" Content="Cancelar" IsCancel="True"/>
        <Button x:Name="btn_aplicar" Content="Aplicar cambios" Style="{StaticResource Primario}"/>
      </StackPanel>
      <TextBlock x:Name="txt_pie" VerticalAlignment="Center" Style="{StaticResource Nota}"/>'''
        VentanaALF.__init__(self, ventana_xaml(u'PlanosALF — Crear láminas desde Excel', u'Crear y actualizar láminas desde Excel',
                                               cuerpo, 1120, 700, pie))
        self.acciones = acciones
        self.n_proyecto = n_proyecto
        self.txt_excel.Text = u'Excel: %s' % ruta_excel
        conteo = {}
        for a in acciones:
            conteo[a.tipo] = conteo.get(a.tipo, 0) + 1
        self.txt_crear.Text = u'Crear: %d' % conteo.get(core.Accion.CREAR, 0)
        self.txt_actualizar.Text = u'Actualizar: %d' % conteo.get(core.Accion.ACTUALIZAR, 0)
        self.txt_igual.Text = u'Sin cambios: %d' % conteo.get(core.Accion.SIN_CAMBIOS, 0)
        self.txt_error.Text = u'Con error: %d' % conteo.get(core.Accion.ERROR, 0)
        self.chk_proyecto.Content = u'Información del proyecto (%d dato%s)' % (n_proyecto, u'' if n_proyecto == 1 else u's')
        self.chk_proyecto.IsEnabled = n_proyecto > 0
        self.chk_proyecto.IsChecked = n_proyecto > 0 and bool(cfg.get(u'info_proyecto', True))
        self.chk_crear.IsChecked = bool(cfg.get(u'crear_nuevas', True))
        self.chk_actualizar.IsChecked = bool(cfg.get(u'actualizar', True))
        self.chk_vistas.IsChecked = bool(cfg.get(u'colocar_vistas', True))

        self.opciones_rotulo = [u'(sin rótulo)'] + list(rotulos_textos)
        for r in self.opciones_rotulo:
            self.cmb_rotulo.Items.Add(r)
        sel = rotulo_defecto if rotulo_defecto in self.opciones_rotulo else (
            rotulos_textos[0] if rotulos_textos else u'(sin rótulo)')
        self.cmb_rotulo.SelectedItem = sel
        necesitan = len([a for a in acciones if a.tipo == core.Accion.CREAR and not getattr(a.detalle, 'rotulo', None)])
        self.cmb_rotulo.IsEnabled = necesitan > 0
        self.cmb_rotulo.ToolTip = u'Para las %d lámina(s) nuevas que no indican rótulo en el Excel' % necesitan

        for f in (u'Todas', u'Solo cambios', u'Errores y avisos'):
            self.cmb_filtro.Items.Add(f)
        self.cmb_filtro.SelectedIndex = 0

        self.t = tabla([(u'Sel', u'b'), (u'Habil', u'b'), (u'Fila', u'i'), (u'Accion', u's'), (u'Numero', u's'),
                        (u'Nombre', u's'), (u'Detalle', u's'), (u'Idx', u'i'), (u'Aviso', u'b')])
        for i, a in enumerate(acciones):
            puede = a.tipo in (core.Accion.CREAR, core.Accion.ACTUALIZAR)
            fila_tabla(self.t, {u'Sel': puede, u'Habil': puede, u'Fila': a.fila.fila, u'Accion': a.tipo,
                                u'Numero': a.numero or a.fila.numero, u'Nombre': a.nombre or a.fila.nombre,
                                u'Detalle': a.resumen(), u'Idx': i, u'Aviso': bool(a.avisos or a.errores)})
        self.grid.ItemsSource = self.t.DefaultView
        extra = u''
        if avisos_excel:
            extra = u' · Excel: ' + u' '.join(avisos_excel[:3])
        self.txt_pie.Text = (u'Se aplica en un solo paso de Deshacer (Ctrl+Z).' + extra)

        self.cmb_filtro.SelectionChanged += self.filtrar
        self.btn_cancelar.Click += self.cerrar
        self.btn_aplicar.Click += self.aplicar

    def filtrar(self, sender, args):
        i = self.cmb_filtro.SelectedIndex
        if i == 1:
            self.t.DefaultView.RowFilter = u"Accion = 'Crear' OR Accion = 'Actualizar'"
        elif i == 2:
            self.t.DefaultView.RowFilter = u"Accion = 'Error' OR Aviso = true"
        else:
            self.t.DefaultView.RowFilter = u''

    def aplicar(self, sender, args):
        self.grid.CommitEdit()
        for r in self.t.Rows:
            self.acciones[int(r[u'Idx'])].aplicar = bool(r[u'Sel'])
        crear = bool(self.chk_crear.IsChecked)
        actualizar = bool(self.chk_actualizar.IsChecked)
        n = len([a for a in self.acciones if a.aplicar and ((a.tipo == core.Accion.CREAR and crear) or
                                                             (a.tipo == core.Accion.ACTUALIZAR and actualizar))])
        proyecto = bool(self.chk_proyecto.IsChecked) and self.n_proyecto > 0
        if not n and not proyecto:
            forms.alert(u'No hay nada marcado para aplicar.', title=u'PlanosALF')
            return
        rotulo = _u(self.cmb_rotulo.SelectedItem or u'')
        self.resultado = dict(crear=crear, actualizar=actualizar, vistas=bool(self.chk_vistas.IsChecked),
                              proyecto=proyecto, rotulo=u'' if rotulo == u'(sin rótulo)' else rotulo)
        self.Close()


# ============================================================================ renumerar

class VentanaRenumerar(VentanaALF):
    """laminas: [dict(uid, numero, nombre, sel)]. resultado = dict(cambios, param_total, ajustes)."""

    def __init__(self, laminas, numeros_todos, cfg):
        esp = cfg.especialidades()
        self.esp = esp
        self.cfg = cfg
        self.todos = numeros_todos
        cuerpo = u'''
    <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="300"/></Grid.ColumnDefinitions>
    <DockPanel Grid.Column="0" Margin="0,0,12,0">
      <StackPanel DockPanel.Dock="Top" Orientation="Horizontal" Margin="0,0,0,6">
        <TextBlock Text="Especialidad:" VerticalAlignment="Center"/>
        <ComboBox x:Name="cmb_filtro" Width="230"/>
        <TextBlock Text="Buscar:" VerticalAlignment="Center" Margin="8,0,0,0"/>
        <TextBox x:Name="txt_buscar" Width="170"/>
      </StackPanel>
      <StackPanel DockPanel.Dock="Bottom" Orientation="Horizontal" Margin="0,6,0,0">
        <Button x:Name="btn_todo" Content="Marcar visibles" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_nada" Content="Desmarcar todo" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_subir" Content="▲ Subir" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_bajar" Content="▼ Bajar" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_ord_num" Content="Ordenar por número" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_ord_nom" Content="Ordenar por nombre" Style="{StaticResource Chico}"/>
      </StackPanel>
      <DataGrid x:Name="grid" CanUserSortColumns="False">
        <DataGrid.Columns>
          <DataGridTemplateColumn Header="✓" Width="34">
            <DataGridTemplateColumn.CellTemplate><DataTemplate>
              <CheckBox IsChecked="{Binding Sel, UpdateSourceTrigger=PropertyChanged}" HorizontalAlignment="Center"/>
            </DataTemplate></DataGridTemplateColumn.CellTemplate>
          </DataGridTemplateColumn>
          <DataGridTextColumn Header="Actual" Binding="{Binding Actual}" Width="90" IsReadOnly="True" ElementStyle="{StaticResource Celda}"/>
          <DataGridTextColumn Header="Nombre de lámina" Binding="{Binding Nombre}" Width="*" IsReadOnly="True"
                              ElementStyle="{StaticResource Celda}"/>
          <DataGridTextColumn Header="Nuevo" Binding="{Binding Nuevo}" Width="100" IsReadOnly="True">
            <DataGridTextColumn.ElementStyle>
              <Style TargetType="TextBlock"><Setter Property="FontWeight" Value="Bold"/>
                <Setter Property="Foreground" Value="#1F5FC9"/></Style>
            </DataGridTextColumn.ElementStyle>
          </DataGridTextColumn>
        </DataGrid.Columns>
      </DataGrid>
    </DockPanel>
    <ScrollViewer Grid.Column="1" VerticalScrollBarVisibility="Auto">
    <StackPanel>
      <GroupBox Header="Prefijo">
        <StackPanel>
          <RadioButton x:Name="rb_conservar" Content="Conservar la especialidad de cada lámina" IsChecked="True"/>
          <TextBlock Style="{StaticResource Nota}" Margin="24,0,0,4"
                     Text="E-, IE-, IS-… se numeran por separado, cada una desde el inicio."/>
          <StackPanel Orientation="Horizontal">
            <RadioButton x:Name="rb_prefijo" Content="Usar el prefijo:"/>
            <ComboBox x:Name="cmb_prefijo" Width="90" IsEditable="True"/>
          </StackPanel>
        </StackPanel>
      </GroupBox>
      <GroupBox Header="Numeración">
        <Grid>
          <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="80"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Text="Empezar en" VerticalAlignment="Center"/>
          <TextBox x:Name="txt_inicio" Grid.Column="1"/>
          <TextBlock Grid.Row="1" Text="Incremento" VerticalAlignment="Center"/>
          <TextBox x:Name="txt_incremento" Grid.Row="1" Grid.Column="1"/>
          <TextBlock Grid.Row="2" Text="Dígitos (01, 001…)" VerticalAlignment="Center"/>
          <TextBox x:Name="txt_digitos" Grid.Row="2" Grid.Column="1"/>
          <TextBlock Grid.Row="3" Text="Separador" VerticalAlignment="Center"/>
          <TextBox x:Name="txt_separador" Grid.Row="3" Grid.Column="1"/>
        </Grid>
      </GroupBox>
      <GroupBox Header="Total de láminas (opcional)">
        <StackPanel>
          <TextBlock Style="{StaticResource Nota}" Text="Parámetro del rótulo donde escribir cuántas láminas tiene la especialidad (p. ej. «Total de láminas»)."/>
          <TextBox x:Name="txt_total"/>
        </StackPanel>
      </GroupBox>
      <TextBlock x:Name="txt_resumen" TextWrapping="Wrap" FontWeight="Bold" Margin="2,4"/>
      <TextBlock x:Name="txt_errores" TextWrapping="Wrap" Foreground="#C00000" Margin="2,4"/>
      <TextBlock Style="{StaticResource Nota}" Margin="2,6"
                 Text="Se numera en el orden de la lista (use Subir/Bajar). Los números se intercambian sin choques y todo queda en un solo Deshacer."/>
    </StackPanel>
    </ScrollViewer>'''
        pie = u'''<StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
        <Button x:Name="btn_cancelar" Content="Cancelar" IsCancel="True"/>
        <Button x:Name="btn_aplicar" Content="Renumerar" Style="{StaticResource Primario}"/>
      </StackPanel>
      <TextBlock x:Name="txt_pie" VerticalAlignment="Center" Style="{StaticResource Nota}"/>'''
        VentanaALF.__init__(self, ventana_xaml(u'PlanosALF — Renumerar láminas', u'Renumerar láminas', cuerpo, 1060, 680, pie))
        self.items = list(laminas)   # orden actual
        self._ocupado = False
        self.cmb_filtro.Items.Add(u'Todas')
        codigos = []
        for l in self.items:
            c = esp.de_numero(l[u'numero'])
            if c not in codigos:
                codigos.append(c)
        codigos.sort(key=lambda c: (esp.orden(c), c))
        self.codigos_filtro = [u''] + codigos
        for c in codigos:
            self.cmb_filtro.Items.Add((u'%s — %s' % (c, esp.nombre(c) or u'otras')) if c else u'(sin prefijo)')
        self.cmb_filtro.SelectedIndex = 0
        for c in esp.codigos():
            self.cmb_prefijo.Items.Add(c)
        self.cmb_prefijo.Text = codigos[0] if codigos and codigos[0] else u'E'
        self.txt_inicio.Text = _u(str(cfg.get(u'renum_inicio', 1)))
        self.txt_incremento.Text = _u(str(cfg.get(u'renum_incremento', 1)))
        self.txt_digitos.Text = _u(str(cfg.get(u'digitos', 2)))
        self.txt_separador.Text = _u(cfg.get(u'separador', u'-'))
        self.txt_total.Text = _u(cfg.get(u'renum_param_total', u''))
        self.t = tabla([(u'Sel', u'b'), (u'Actual', u's'), (u'Nombre', u's'), (u'Nuevo', u's'), (u'Uid', u's')])
        self.reconstruir()
        self.t.ColumnChanged += self.cambio_tabla
        for ctl in (self.txt_inicio, self.txt_incremento, self.txt_digitos, self.txt_separador, self.txt_buscar):
            ctl.TextChanged += self.actualizar
        self.cmb_prefijo.SelectionChanged += self.actualizar
        self.cmb_prefijo.AddHandler(System.Windows.Controls.Primitives.TextBoxBase.TextChangedEvent,
                                    System.Windows.Controls.TextChangedEventHandler(self.actualizar))
        self.rb_conservar.Checked += self.actualizar
        self.rb_prefijo.Checked += self.actualizar
        self.cmb_filtro.SelectionChanged += self.actualizar
        self.btn_todo.Click += self.marcar_visibles
        self.btn_nada.Click += self.desmarcar
        self.btn_subir.Click += lambda s, a: self.mover(-1)
        self.btn_bajar.Click += lambda s, a: self.mover(1)
        self.btn_ord_num.Click += lambda s, a: self.ordenar(lambda l: core.clave_natural(l[u'numero']))
        self.btn_ord_nom.Click += lambda s, a: self.ordenar(lambda l: core.clave_natural(l[u'nombre']))
        self.btn_cancelar.Click += self.cerrar
        self.btn_aplicar.Click += self.aplicar
        self.actualizar()

    # ---------------------------------------------------------------- datos
    def visible(self, l):
        i = self.cmb_filtro.SelectedIndex
        if i > 0 and self.esp.de_numero(l[u'numero']) != self.codigos_filtro[i]:
            return False
        b = core.normalizar(self.txt_buscar.Text)
        if b and b not in core.normalizar(l[u'numero'] + l[u'nombre']):
            return False
        return True

    def reconstruir(self):
        self._ocupado = True
        try:
            self.t.Rows.Clear()
            for l in self.items:
                if self.visible(l):
                    fila_tabla(self.t, {u'Sel': bool(l.get(u'sel')), u'Actual': l[u'numero'], u'Nombre': l[u'nombre'],
                                        u'Nuevo': u'', u'Uid': l[u'uid']})
            self.grid.ItemsSource = self.t.DefaultView
        finally:
            self._ocupado = False

    def leer_marcas(self):
        por_uid = dict((l[u'uid'], l) for l in self.items)
        for r in self.t.Rows:
            l = por_uid.get(_u(r[u'Uid']))
            if l is not None:
                l[u'sel'] = bool(r[u'Sel'])

    def cambio_tabla(self, sender, args):
        if self._ocupado or args.Column.ColumnName != u'Sel':
            return
        self.leer_marcas()
        self.calcular()

    def ajustes(self):
        return dict(inicio=numero(self.txt_inicio.Text, 1, 0), incremento=numero(self.txt_incremento.Text, 1, 1),
                    digitos=numero(self.txt_digitos.Text, 2, 1, 5), separador=_u(self.txt_separador.Text),
                    prefijo=None if self.rb_conservar.IsChecked else _u(self.cmb_prefijo.Text).strip().upper())

    def calcular(self):
        a = self.ajustes()
        # solo las marcadas que están a la vista (el filtro oculta las demás)
        seleccion = [(l[u'uid'], l[u'numero']) for l in self.items if l.get(u'sel') and self.visible(l)]
        cambios, errores = core.planificar_renumeracion(
            seleccion, self.todos, a[u'inicio'], a[u'incremento'], a[u'digitos'], a[u'separador'], a[u'prefijo'],
            self.esp)
        if a[u'prefijo'] is not None and not a[u'prefijo']:
            errores = [u'Escriba el prefijo (p. ej. E, IE, IS).'] + errores
        nuevos = dict((uid, nuevo) for uid, _, nuevo in cambios)
        self._ocupado = True
        try:
            for r in self.t.Rows:
                r[u'Nuevo'] = nuevos.get(_u(r[u'Uid']), u'')
        finally:
            self._ocupado = False
        n_cambian = len([c for c in cambios if c[1] != c[2]])
        self.txt_resumen.Text = u'%d seleccionada(s) · %d cambian de número' % (len(cambios), n_cambian)
        self.txt_errores.Text = u'\n'.join(errores[:8]) + (u'\n…' if len(errores) > 8 else u'')
        self.txt_pie.Text = u'Ejemplo: %s' % core.formatear_numero(a[u'prefijo'] or u'IE', a[u'inicio'],
                                                                    a[u'digitos'], a[u'separador'])
        self.cambios, self.errores = cambios, errores

    def actualizar(self, sender=None, args=None):
        if self._ocupado:
            return
        self.leer_marcas()
        self.reconstruir()
        self.calcular()

    def marcar_visibles(self, sender, args):
        for l in self.items:
            if self.visible(l):
                l[u'sel'] = True
        self.reconstruir()
        self.calcular()

    def desmarcar(self, sender, args):
        for l in self.items:
            l[u'sel'] = False
        self.reconstruir()
        self.calcular()

    def mover(self, paso):
        self.leer_marcas()
        elegidos = []
        for item in self.grid.SelectedItems:
            elegidos.append(_u(item[u'Uid']))
        if not elegidos:
            forms.alert(u'Seleccione una o más filas (clic en el nombre) para moverlas.', title=u'PlanosALF')
            return
        idx = [i for i, l in enumerate(self.items) if l[u'uid'] in elegidos]
        orden = idx if paso < 0 else list(reversed(idx))
        for i in orden:
            j = i + paso
            # salta las láminas ocultas por el filtro
            while 0 <= j < len(self.items) and not self.visible(self.items[j]):
                j += paso
            if 0 <= j < len(self.items) and self.items[j][u'uid'] not in elegidos:
                self.items[i], self.items[j] = self.items[j], self.items[i]
        self.reconstruir()
        self.calcular()
        for item in list(self.grid.Items):
            if _u(item[u'Uid']) in elegidos:
                self.grid.SelectedItems.Add(item)

    def ordenar(self, clave):
        self.leer_marcas()
        visibles = [l for l in self.items if self.visible(l)]
        ordenados = sorted(visibles, key=clave)
        it = iter(ordenados)
        self.items = [next(it) if self.visible(l) else l for l in self.items]
        self.reconstruir()
        self.calcular()

    def aplicar(self, sender, args):
        self.leer_marcas()
        self.calcular()
        if not self.cambios:
            forms.alert(u'Marque las láminas que desea renumerar.', title=u'PlanosALF')
            return
        if self.errores:
            forms.alert(u'Corrija primero:\n\n' + u'\n'.join(self.errores[:10]), title=u'PlanosALF')
            return
        if not [c for c in self.cambios if c[1] != c[2]] and not _u(self.txt_total.Text).strip():
            forms.alert(u'Los números ya son esos: no hay nada que cambiar.', title=u'PlanosALF')
            return
        a = self.ajustes()
        self.resultado = dict(cambios=self.cambios, param_total=_u(self.txt_total.Text).strip(), ajustes=a)
        self.Close()


# ============================================================================ exportar

MODOS_PDF = [(u'separado', u'Un PDF por lámina'), (u'especialidad', u'Un PDF por especialidad'),
             (u'uno', u'Un solo PDF con todas')]
COLORES_PDF = [(u'color', u'Color'), (u'grises', u'Escala de grises'), (u'negro', u'Blanco y negro')]
CALIDADES_PDF = [(u'media', u'Normal (300 ppp, rápido)'), (u'alta', u'Alta (600 ppp)'),
                 (u'presentacion', u'Presentación (1200 ppp)')]
VERSIONES_DWG = [u'2018', u'2013', u'2010', u'2007']


class VentanaExportar(VentanaALF):
    """laminas: [dict(uid, numero, nombre, codigo, revision, datos_patron, sel)].
    resultado = dict(uids [en orden], cfg actualizada)."""

    def __init__(self, laminas, configs_dwg, cfg, carpeta_defecto):
        self.cfg = cfg
        self.esp = cfg.especialidades()
        cuerpo = u'''
    <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="410"/></Grid.ColumnDefinitions>
    <DockPanel Grid.Column="0" Margin="0,0,12,0">
      <StackPanel DockPanel.Dock="Top" Orientation="Horizontal" Margin="0,0,0,6">
        <TextBlock Text="Especialidad:" VerticalAlignment="Center"/>
        <ComboBox x:Name="cmb_filtro" Width="230"/>
        <TextBlock Text="Buscar:" VerticalAlignment="Center" Margin="8,0,0,0"/>
        <TextBox x:Name="txt_buscar" Width="160"/>
      </StackPanel>
      <StackPanel DockPanel.Dock="Bottom" Orientation="Horizontal" Margin="0,6,0,0">
        <Button x:Name="btn_todo" Content="Marcar visibles" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_nada" Content="Desmarcar todo" Style="{StaticResource Chico}"/>
        <TextBlock x:Name="txt_conteo" VerticalAlignment="Center" Margin="8,0,0,0" FontWeight="Bold"/>
      </StackPanel>
      <DataGrid x:Name="grid" CanUserSortColumns="False">
        <DataGrid.Columns>
          <DataGridTemplateColumn Header="✓" Width="34">
            <DataGridTemplateColumn.CellTemplate><DataTemplate>
              <CheckBox IsChecked="{Binding Sel, UpdateSourceTrigger=PropertyChanged}" HorizontalAlignment="Center"/>
            </DataTemplate></DataGridTemplateColumn.CellTemplate>
          </DataGridTemplateColumn>
          <DataGridTextColumn Header="Número" Binding="{Binding Numero}" Width="80" IsReadOnly="True" ElementStyle="{StaticResource Celda}"/>
          <DataGridTextColumn Header="Nombre de lámina" Binding="{Binding Nombre}" Width="*" IsReadOnly="True"
                              ElementStyle="{StaticResource Celda}"/>
          <DataGridTextColumn Header="Rev." Binding="{Binding Rev}" Width="44" IsReadOnly="True" ElementStyle="{StaticResource Celda}"/>
          <DataGridTextColumn Header="Archivo" Binding="{Binding Archivo}" Width="200" IsReadOnly="True"
                              ElementStyle="{StaticResource Celda}"/>
        </DataGrid.Columns>
      </DataGrid>
    </DockPanel>
    <ScrollViewer Grid.Column="1" VerticalScrollBarVisibility="Auto">
    <StackPanel>
      <GroupBox Header="Formatos">
        <StackPanel Orientation="Horizontal">
          <CheckBox x:Name="chk_pdf" Content="PDF" FontWeight="Bold"/>
          <CheckBox x:Name="chk_dwg" Content="DWG" FontWeight="Bold" Margin="24,4,4,4"/>
        </StackPanel>
      </GroupBox>
      <GroupBox Header="Destino y nombres">
        <StackPanel>
          <DockPanel>
            <Button x:Name="btn_carpeta" DockPanel.Dock="Right" Content="…" Style="{StaticResource Chico}" Margin="2,3,0,3"/>
            <TextBox x:Name="txt_carpeta"/>
          </DockPanel>
          <CheckBox x:Name="chk_subcarpetas" Content="Una subcarpeta por especialidad"/>
          <TextBlock Text="Nombre de archivo:" Margin="4,4,4,0"/>
          <ComboBox x:Name="cmb_patron" IsEditable="True"/>
          <TextBlock x:Name="txt_campos" Style="{StaticResource Nota}" Margin="4,0,4,4"/>
        </StackPanel>
      </GroupBox>
      <GroupBox x:Name="grp_pdf" Header="PDF">
        <Grid>
          <Grid.ColumnDefinitions><ColumnDefinition Width="80"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Text="Archivos" VerticalAlignment="Center"/>
          <ComboBox x:Name="cmb_modo" Grid.Column="1"/>
          <TextBlock Grid.Row="1" Text="Color" VerticalAlignment="Center"/>
          <ComboBox x:Name="cmb_color" Grid.Row="1" Grid.Column="1"/>
          <TextBlock Grid.Row="2" Text="Calidad" VerticalAlignment="Center"/>
          <ComboBox x:Name="cmb_calidad" Grid.Row="2" Grid.Column="1"/>
          <CheckBox x:Name="chk_ocultar" Grid.Row="3" Grid.ColumnSpan="2"><TextBlock TextWrapping="Wrap" Text="Ocultar recortes, planos y cajas de referencia y etiquetas sin referencia"/></CheckBox>
        </Grid>
      </GroupBox>
      <GroupBox x:Name="grp_dwg" Header="DWG">
        <Grid>
          <Grid.ColumnDefinitions><ColumnDefinition Width="100"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Text="Configuración" VerticalAlignment="Center"/>
          <ComboBox x:Name="cmb_config_dwg" Grid.Column="1"/>
          <TextBlock Grid.Row="1" Text="Versión" VerticalAlignment="Center"/>
          <ComboBox x:Name="cmb_version" Grid.Row="1" Grid.Column="1"/>
          <CheckBox x:Name="chk_unido" Grid.Row="2" Grid.ColumnSpan="2"><TextBlock TextWrapping="Wrap" Text="Un solo DWG por lámina (vistas unidas, sin referencias externas)"/></CheckBox>
        </Grid>
      </GroupBox>
      <CheckBox x:Name="chk_indice" Content="Crear el índice de planos (Excel)"/>
      <CheckBox x:Name="chk_sobrescribir" Content="Reemplazar archivos que ya existan"/>
      <CheckBox x:Name="chk_abrir" Content="Abrir la carpeta al terminar"/>
    </StackPanel>
    </ScrollViewer>'''
        pie = u'''<StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
        <Button x:Name="btn_cancelar" Content="Cancelar" IsCancel="True"/>
        <Button x:Name="btn_aplicar" Content="Exportar" Style="{StaticResource Primario}"/>
      </StackPanel>
      <TextBlock x:Name="txt_pie" VerticalAlignment="Center" Style="{StaticResource Nota}"/>'''
        VentanaALF.__init__(self, ventana_xaml(u'PlanosALF — Exportar PDF y DWG', u'Exportar láminas a PDF y DWG',
                                               cuerpo, 1180, 740, pie))
        self.items = list(laminas)
        self._ocupado = False
        self.cmb_filtro.Items.Add(u'Todas')
        codigos = []
        for l in self.items:
            if l[u'codigo'] not in codigos:
                codigos.append(l[u'codigo'])
        codigos.sort(key=lambda c: (self.esp.orden(c), c))
        self.codigos_filtro = [u''] + codigos
        for c in codigos:
            self.cmb_filtro.Items.Add((u'%s — %s' % (c, self.esp.nombre(c) or u'otras')) if c else u'(sin prefijo)')
        self.cmb_filtro.SelectedIndex = 0

        self.chk_pdf.IsChecked = bool(cfg.get(u'pdf', True))
        self.chk_dwg.IsChecked = bool(cfg.get(u'dwg', False))
        carpeta = _u(cfg.get(u'carpeta_exportacion') or u'')
        self.txt_carpeta.Text = carpeta if carpeta and os.path.isdir(carpeta) else carpeta_defecto
        self.chk_subcarpetas.IsChecked = bool(cfg.get(u'subcarpetas', True))
        for p in core.PATRONES_ARCHIVO:
            self.cmb_patron.Items.Add(p)
        self.cmb_patron.Text = _u(cfg.get(u'patron_archivo') or u'{Numero}')
        self.txt_campos.Text = u'Campos: ' + u'  '.join(u'{%s}' % c for c, _ in core.CAMPOS_PATRON)
        self.txt_campos.ToolTip = u'\n'.join(u'{%s}: %s' % (c, d) for c, d in core.CAMPOS_PATRON)
        self._llenar(self.cmb_modo, MODOS_PDF, cfg.get(u'modo_pdf'))
        self._llenar(self.cmb_color, COLORES_PDF, cfg.get(u'color_pdf'))
        self._llenar(self.cmb_calidad, CALIDADES_PDF, cfg.get(u'calidad_pdf'))
        self.chk_ocultar.IsChecked = bool(cfg.get(u'ocultar_recortes', True))
        self.configs_dwg = [u''] + list(configs_dwg)
        for c in self.configs_dwg:
            self.cmb_config_dwg.Items.Add(c or u'(predeterminada de Revit)')
        actual = _u(cfg.get(u'config_dwg') or u'')
        self.cmb_config_dwg.SelectedIndex = self.configs_dwg.index(actual) if actual in self.configs_dwg else 0
        for v in VERSIONES_DWG:
            self.cmb_version.Items.Add(u'AutoCAD ' + v)
        v = _u(cfg.get(u'version_dwg') or u'2018')
        self.cmb_version.SelectedIndex = VERSIONES_DWG.index(v) if v in VERSIONES_DWG else 0
        self.chk_unido.IsChecked = bool(cfg.get(u'dwg_unido', True))
        self.chk_indice.IsChecked = bool(cfg.get(u'indice_excel', True))
        self.chk_sobrescribir.IsChecked = bool(cfg.get(u'sobrescribir', True))
        self.chk_abrir.IsChecked = bool(cfg.get(u'abrir_carpeta', True))

        self.t = tabla([(u'Sel', u'b'), (u'Numero', u's'), (u'Nombre', u's'), (u'Rev', u's'), (u'Archivo', u's'),
                        (u'Uid', u's')])
        self.reconstruir()
        self.t.ColumnChanged += self.cambio_tabla
        self.txt_buscar.TextChanged += self.actualizar
        self.cmb_filtro.SelectionChanged += self.actualizar
        self.cmb_patron.SelectionChanged += self.actualizar_diferido
        self.cmb_patron.AddHandler(System.Windows.Controls.Primitives.TextBoxBase.TextChangedEvent,
                                   System.Windows.Controls.TextChangedEventHandler(self.actualizar))
        for ctl in (self.chk_pdf, self.chk_dwg, self.chk_subcarpetas):
            ctl.Checked += self.actualizar
            ctl.Unchecked += self.actualizar
        self.cmb_modo.SelectionChanged += self.actualizar
        self.btn_todo.Click += self.marcar_visibles
        self.btn_nada.Click += self.desmarcar
        self.btn_carpeta.Click += self.elegir_carpeta
        self.btn_cancelar.Click += self.cerrar
        self.btn_aplicar.Click += self.aplicar
        self.actualizar()

    @staticmethod
    def _llenar(combo, opciones, actual):
        for clave, texto in opciones:
            combo.Items.Add(texto)
        claves = [c for c, _ in opciones]
        combo.SelectedIndex = claves.index(actual) if actual in claves else 0

    def visible(self, l):
        i = self.cmb_filtro.SelectedIndex
        if i > 0 and l[u'codigo'] != self.codigos_filtro[i]:
            return False
        b = core.normalizar(self.txt_buscar.Text)
        if b and b not in core.normalizar(l[u'numero'] + l[u'nombre']):
            return False
        return True

    def patron(self):
        return _u(self.cmb_patron.Text).strip() or u'{Numero}'

    def nombre_archivo(self, l):
        return core.aplicar_patron(self.patron(), l[u'datos_patron'])

    def reconstruir(self):
        self._ocupado = True
        try:
            self.t.Rows.Clear()
            for l in self.items:
                if self.visible(l):
                    fila_tabla(self.t, {u'Sel': bool(l.get(u'sel')), u'Numero': l[u'numero'], u'Nombre': l[u'nombre'],
                                        u'Rev': l.get(u'revision', u''), u'Archivo': u'', u'Uid': l[u'uid']})
            self.grid.ItemsSource = self.t.DefaultView
        finally:
            self._ocupado = False

    def leer_marcas(self):
        por_uid = dict((l[u'uid'], l) for l in self.items)
        for r in self.t.Rows:
            l = por_uid.get(_u(r[u'Uid']))
            if l is not None:
                l[u'sel'] = bool(r[u'Sel'])

    def cambio_tabla(self, sender, args):
        if self._ocupado or args.Column.ColumnName != u'Sel':
            return
        self.leer_marcas()
        self.calcular()

    def calcular(self):
        modo = MODOS_PDF[max(0, self.cmb_modo.SelectedIndex)][0]
        por_uid = dict((l[u'uid'], l) for l in self.items)
        self._ocupado = True
        try:
            for r in self.t.Rows:
                l = por_uid.get(_u(r[u'Uid']))
                if l is None:
                    continue
                n = self.nombre_archivo(l)
                exts = []
                if self.chk_pdf.IsChecked and modo == u'separado':
                    exts.append(u'.pdf')
                if self.chk_dwg.IsChecked:
                    exts.append(u'.dwg')
                r[u'Archivo'] = (n + u' (' + u', '.join(exts) + u')') if exts else n
        finally:
            self._ocupado = False
        sel = [l for l in self.items if l.get(u'sel') and self.visible(l)]
        partes = [u'%d lámina(s) marcada(s)' % len(sel)]
        self.txt_conteo.Text = partes[0]
        if self.chk_pdf.IsChecked:
            if modo == u'separado':
                partes.append(u'%d PDF' % len(sel))
            elif modo == u'especialidad':
                partes.append(u'%d PDF' % len(set(l[u'codigo'] for l in sel)))
            else:
                partes.append(u'1 PDF' if sel else u'0 PDF')
        if self.chk_dwg.IsChecked:
            partes.append(u'%d DWG' % len(sel))
        self.txt_pie.Text = u' · '.join(partes)

    def actualizar(self, sender=None, args=None):
        if self._ocupado:
            return
        self.leer_marcas()
        self.reconstruir()
        self.calcular()

    def actualizar_diferido(self, sender, args):
        # el texto del combo editable cambia después de SelectionChanged
        self.Dispatcher.BeginInvoke(System.Action(self.actualizar))

    def marcar_visibles(self, sender, args):
        self.leer_marcas()
        for l in self.items:
            if self.visible(l):
                l[u'sel'] = True
        self.reconstruir()
        self.calcular()

    def desmarcar(self, sender, args):
        for l in self.items:
            l[u'sel'] = False
        self.reconstruir()
        self.calcular()

    def elegir_carpeta(self, sender, args):
        c = forms.pick_folder(title=u'Carpeta donde guardar los planos')
        if c:
            self.txt_carpeta.Text = c

    def aplicar(self, sender, args):
        self.leer_marcas()
        sel = [l[u'uid'] for l in self.items if l.get(u'sel') and self.visible(l)]
        if not sel:
            forms.alert(u'Marque las láminas que desea exportar (solo se exportan las que se ven con el filtro '
                        u'actual).', title=u'PlanosALF')
            return
        if not self.chk_pdf.IsChecked and not self.chk_dwg.IsChecked and not self.chk_indice.IsChecked:
            forms.alert(u'Elija PDF, DWG o el índice de planos.', title=u'PlanosALF')
            return
        carpeta = _u(self.txt_carpeta.Text).strip().strip(u'"')
        if not carpeta:
            forms.alert(u'Elija la carpeta de destino.', title=u'PlanosALF')
            return
        if not os.path.isdir(carpeta):
            try:
                os.makedirs(carpeta)
            except OSError:
                forms.alert(u'No se pudo crear la carpeta:\n%s' % carpeta, title=u'PlanosALF')
                return
        c = self.cfg
        c[u'pdf'] = bool(self.chk_pdf.IsChecked)
        c[u'dwg'] = bool(self.chk_dwg.IsChecked)
        c[u'carpeta_exportacion'] = carpeta
        c[u'subcarpetas'] = bool(self.chk_subcarpetas.IsChecked)
        c[u'patron_archivo'] = self.patron()
        c[u'modo_pdf'] = MODOS_PDF[max(0, self.cmb_modo.SelectedIndex)][0]
        c[u'color_pdf'] = COLORES_PDF[max(0, self.cmb_color.SelectedIndex)][0]
        c[u'calidad_pdf'] = CALIDADES_PDF[max(0, self.cmb_calidad.SelectedIndex)][0]
        oc = bool(self.chk_ocultar.IsChecked)
        c[u'ocultar_recortes'] = c[u'ocultar_ref'] = c[u'ocultar_cajas'] = c[u'ocultar_etiquetas'] = oc
        c[u'config_dwg'] = self.configs_dwg[max(0, self.cmb_config_dwg.SelectedIndex)]
        c[u'version_dwg'] = VERSIONES_DWG[max(0, self.cmb_version.SelectedIndex)]
        c[u'dwg_unido'] = bool(self.chk_unido.IsChecked)
        c[u'indice_excel'] = bool(self.chk_indice.IsChecked)
        c[u'sobrescribir'] = bool(self.chk_sobrescribir.IsChecked)
        c[u'abrir_carpeta'] = bool(self.chk_abrir.IsChecked)
        self.resultado = dict(uids=sel)
        self.Close()


# ============================================================================ configuración

class VentanaConfig(VentanaALF):
    def __init__(self, cfg, rotulos_textos):
        self.cfg = cfg
        cuerpo = u'''
    <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="340"/></Grid.ColumnDefinitions>
    <DockPanel Grid.Column="0" Margin="0,0,12,0">
      <TextBlock DockPanel.Dock="Top" Text="Especialidades (código = prefijo de la lámina). El orden es el del índice de planos."
                 Style="{StaticResource Nota}" Margin="0,0,0,6"/>
      <StackPanel DockPanel.Dock="Bottom" Orientation="Horizontal" Margin="0,6,0,0">
        <Button x:Name="btn_agregar" Content="+ Agregar" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_quitar" Content="Quitar" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_subir" Content="▲" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_bajar" Content="▼" Style="{StaticResource Chico}"/>
        <Button x:Name="btn_peru" Content="Restaurar lista de Perú" Style="{StaticResource Chico}"/>
      </StackPanel>
      <DataGrid x:Name="grid" CanUserSortColumns="False" SelectionMode="Single">
        <DataGrid.Columns>
          <DataGridTextColumn Header="Código" Binding="{Binding Codigo, UpdateSourceTrigger=PropertyChanged}" Width="80"/>
          <DataGridTextColumn Header="Especialidad" Binding="{Binding Nombre, UpdateSourceTrigger=PropertyChanged}" Width="*"/>
        </DataGrid.Columns>
      </DataGrid>
    </DockPanel>
    <StackPanel Grid.Column="1">
      <GroupBox Header="Numeración de láminas">
        <Grid>
          <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="80"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Text="Separador" VerticalAlignment="Center"/>
          <TextBox x:Name="txt_separador" Grid.Column="1"/>
          <TextBlock Grid.Row="1" Text="Dígitos" VerticalAlignment="Center"/>
          <TextBox x:Name="txt_digitos" Grid.Row="1" Grid.Column="1"/>
          <TextBlock x:Name="txt_ejemplo" Grid.Row="2" Grid.ColumnSpan="2" Style="{StaticResource Nota}"/>
        </Grid>
      </GroupBox>
      <GroupBox Header="Rótulo por defecto (láminas nuevas)">
        <ComboBox x:Name="cmb_rotulo" IsEditable="True"/>
      </GroupBox>
      <GroupBox Header="Colocación automática de vistas">
        <Grid>
          <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="80"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Text="Franja del rótulo a la derecha (%)" VerticalAlignment="Center" TextWrapping="Wrap"/>
          <TextBox x:Name="txt_franja" Grid.Column="1"/>
          <TextBlock Grid.Row="1" Text="Margen (%)" VerticalAlignment="Center"/>
          <TextBox x:Name="txt_margen" Grid.Row="1" Grid.Column="1"/>
          <TextBlock Grid.Row="2" Grid.ColumnSpan="2" Style="{StaticResource Nota}"
                     Text="Las vistas se ordenan en filas dentro del rótulo, dejando libre la franja derecha (cajetín). Use 0 si su rótulo va abajo."/>
        </Grid>
      </GroupBox>
      <GroupBox Header="Fechas leídas del Excel">
        <ComboBox x:Name="cmb_fecha"/>
      </GroupBox>
      <TextBlock x:Name="txt_ruta" Style="{StaticResource Nota}"/>
    </StackPanel>'''
        pie = u'''<StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
        <Button x:Name="btn_cancelar" Content="Cancelar" IsCancel="True"/>
        <Button x:Name="btn_aplicar" Content="Guardar" Style="{StaticResource Primario}"/>
      </StackPanel>
      <TextBlock VerticalAlignment="Center" Style="{StaticResource Nota}" Text="Se guarda para su usuario de Windows."/>'''
        VentanaALF.__init__(self, ventana_xaml(u'PlanosALF — Configuración', u'Configuración', cuerpo, 900, 620, pie))
        self.t = tabla([(u'Codigo', u's'), (u'Nombre', u's')])
        self.cargar_especialidades(cfg.get(u'especialidades') or [])
        self.txt_separador.Text = _u(cfg.get(u'separador', u'-'))
        self.txt_digitos.Text = _u(str(cfg.get(u'digitos', 2)))
        for r in rotulos_textos:
            self.cmb_rotulo.Items.Add(r)
        self.cmb_rotulo.Text = _u(cfg.get(u'rotulo_defecto') or u'')
        self.txt_franja.Text = _u(str(cfg.get(u'franja_rotulo_pct', 20.0)))
        self.txt_margen.Text = _u(str(cfg.get(u'margen_pct', 3.0)))
        self.formatos = [(u'%d/%m/%Y', u'22/10/2026 (día/mes/año)'), (u'%d.%m.%Y', u'22.10.2026'),
                         (u'%Y-%m-%d', u'2026-10-22 (ISO)'), (u'%d de %B de %Y', u'22 de octubre de 2026')]
        for _, t in self.formatos:
            self.cmb_fecha.Items.Add(t)
        claves = [f for f, _ in self.formatos]
        self.cmb_fecha.SelectedIndex = claves.index(cfg.get(u'formato_fecha')) if cfg.get(u'formato_fecha') in claves else 0
        self.txt_ruta.Text = u'Archivo: ' + config.ruta_config()
        self.txt_separador.TextChanged += self.ejemplo
        self.txt_digitos.TextChanged += self.ejemplo
        self.ejemplo()
        self.btn_agregar.Click += self.agregar
        self.btn_quitar.Click += self.quitar
        self.btn_subir.Click += lambda s, a: self.mover(-1)
        self.btn_bajar.Click += lambda s, a: self.mover(1)
        self.btn_peru.Click += self.restaurar
        self.btn_cancelar.Click += self.cerrar
        self.btn_aplicar.Click += self.guardar

    def cargar_especialidades(self, pares):
        self.t.Rows.Clear()
        for c, n in pares:
            fila_tabla(self.t, {u'Codigo': _u(c), u'Nombre': _u(n)})
        self.grid.ItemsSource = self.t.DefaultView

    @staticmethod
    def _texto(r, col):
        v = r[col]
        return u'' if v is None or isinstance(v, System.DBNull) else _u(v)

    def filas(self):
        """Todas las filas (también las vacías) como [código, nombre], en el orden de la tabla."""
        self.grid.CommitEdit()
        self.grid.CommitEdit()
        return [[self._texto(r, u'Codigo').strip().upper(), self._texto(r, u'Nombre').strip()] for r in self.t.Rows]

    def pares(self):
        return [f for f in self.filas() if f[0]]

    def ejemplo(self, sender=None, args=None):
        d = numero(self.txt_digitos.Text, 2, 1, 5)
        s = _u(self.txt_separador.Text)
        self.txt_ejemplo.Text = u'Ejemplo: %s, %s, %s' % (core.formatear_numero(u'E', 1, d, s),
                                                          core.formatear_numero(u'IE', 2, d, s),
                                                          core.formatear_numero(u'IS', 10, d, s))

    def agregar(self, sender, args):
        fila_tabla(self.t, {u'Codigo': u'', u'Nombre': u''})

    def quitar(self, sender, args):
        item = self.grid.SelectedItem
        if item is not None:
            item.Row.Delete()
            self.t.AcceptChanges()

    def mover(self, paso):
        item = self.grid.SelectedItem
        if item is None:
            return
        filas = self.filas()
        i = self.t.Rows.IndexOf(item.Row)
        j = i + paso
        if 0 <= i < len(filas) and 0 <= j < len(filas):
            filas[i], filas[j] = filas[j], filas[i]
            self.cargar_especialidades(filas)
            self.grid.SelectedIndex = j

    def restaurar(self, sender, args):
        self.cargar_especialidades(core.ESPECIALIDADES_PERU)

    def guardar(self, sender, args):
        pares = self.pares()
        codigos = [c for c, _ in pares]
        malos = [c for c in codigos if not core.re.match(u'^[A-ZÑ]{1,5}$', c)]
        if malos:
            forms.alert(u'Los códigos deben ser de 1 a 5 letras: %s' % u', '.join(malos), title=u'PlanosALF')
            return
        if len(set(codigos)) != len(codigos):
            forms.alert(u'Hay códigos repetidos.', title=u'PlanosALF')
            return
        self.cfg[u'especialidades'] = pares
        self.cfg[u'separador'] = _u(self.txt_separador.Text)
        self.cfg[u'digitos'] = numero(self.txt_digitos.Text, 2, 1, 5)
        self.cfg[u'rotulo_defecto'] = _u(self.cmb_rotulo.Text).strip()
        self.cfg[u'franja_rotulo_pct'] = numero(self.txt_franja.Text, 20.0, 0.0, 60.0, real=True)
        self.cfg[u'margen_pct'] = numero(self.txt_margen.Text, 3.0, 0.0, 20.0, real=True)
        self.cfg[u'formato_fecha'] = self.formatos[max(0, self.cmb_fecha.SelectedIndex)][0]
        self.cfg.guardar()
        self.resultado = True
        self.Close()


# ============================================================================ acerca de

PROGRAMAS = [
    (u'AceroALF', u'Acero de refuerzo en Revit: planilla y optimización de cortes'),
    (u'MetradosALF', u'Metrados de estructuras y arquitectura en Revit'),
    (u'ElectricasALF', u'Instalaciones eléctricas en Revit'),
    (u'SanitariasALF', u'Instalaciones sanitarias en Revit'),
    (u'CronogramaALF', u'Gantt, ruta crítica y calendario valorizado'),
    (u'ValorizacionesALF', u'Valorizaciones y reajustes de obra'),
]


class VentanaAcerca(VentanaALF):
    def __init__(self):
        lista = u''.join(u'<TextBlock Margin="0,2" TextWrapping="Wrap"><Run FontWeight="Bold" Text="%s"/>'
                         u'<Run Text=" — %s"/></TextBlock>' % (_esc(n), _esc(d)) for n, d in PROGRAMAS)
        cuerpo = u'''
    <StackPanel>
      <TextBlock Text="PlanosALF %s" FontSize="22" FontWeight="Bold"/>
      <TextBlock Text="Láminas en lote para Revit · gratuito" FontSize="15" Foreground="#0F766E" Margin="0,0,0,10"/>
      <TextBlock TextWrapping="Wrap" Margin="0,0,0,8"
        Text="Crea láminas desde Excel, llena los rótulos con el formato de su entidad, renumera por especialidad y exporta en lote a PDF y DWG con nombres estandarizados (E-01, IE-01, IS-01…) y el índice de planos."/>
      <TextBlock TextWrapping="Wrap" Text="%s · %s" Foreground="#5F5F5F"/>
      <TextBlock Text="Otros programas ALF_BIM" FontWeight="Bold" Margin="0,14,0,4"/>
      %s
      <TextBlock Style="{StaticResource Nota}" Margin="0,14,0,0"
        Text="Autodesk y Revit son marcas registradas de Autodesk, Inc. PlanosALF es un producto independiente. Funciona sobre pyRevit (gratuito, de pyRevitLabs)."/>
    </StackPanel>''' % (config.VERSION, _esc(config.AUTOR), config.CORREO, lista)
        pie = u'''<StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
        <Button x:Name="btn_web" Content="www.alfbim.com"/>
        <Button x:Name="btn_manual" Content="Manual"/>
        <Button x:Name="btn_correo" Content="Escribir al autor"/>
        <Button x:Name="btn_cerrar" Content="Cerrar" Style="{StaticResource Primario}" IsCancel="True"/>
      </StackPanel>'''
        VentanaALF.__init__(self, ventana_xaml(u'PlanosALF — Acerca de', u'Acerca de', cuerpo, 700, 560, pie))
        self.btn_web.Click += lambda s, a: abrir(config.WEB)
        self.btn_manual.Click += lambda s, a: abrir_manual()
        self.btn_correo.Click += lambda s, a: abrir(u'mailto:%s?subject=PlanosALF%%20%s' % (config.CORREO, config.VERSION))
        self.btn_cerrar.Click += self.cerrar


def abrir_manual():
    for nombre in (u'Manual_PlanosALF_1.0.pdf', u'Manual_PlanosALF.pdf'):
        ruta = config.recurso(nombre)
        if os.path.isfile(ruta):
            return abrir(ruta)
    return abrir(config.WEB)
