# -*- coding: utf-8 -*-
"""Lector y escritor de Excel (.xlsx) sin dependencias externas.

PlanosALF corre dentro de pyRevit (IronPython 2.7 por defecto, o CPython 3), donde no hay openpyxl.
Este módulo usa solo la biblioteca estándar (zipfile + expresiones regulares) para:

- leer libros .xlsx guardados por Excel, LibreOffice o Google Sheets (texto, números, fechas, booleanos);
- escribir libros con estilos (Times New Roman, bordes, rellenos), anchos de columna, paneles fijos,
  filtros, celdas combinadas, listas desplegables, hojas ocultas y ajustes de impresión.

ALF_BIM — Ing. Anderson Irigoín C.
"""
from __future__ import print_function, division

import datetime
import io
import os
import re
import sys
import zipfile

PY3 = sys.version_info[0] >= 3
if PY3:
    text_type = str
    string_types = (str,)
else:  # IronPython 2.7 / CPython 2.7
    text_type = unicode  # noqa: F821
    string_types = (str, unicode)  # noqa: F821

FUENTE = u'Times New Roman'  # regla de la línea ALF_BIM


class ExcelError(Exception):
    """Error al leer o escribir un libro de Excel (mensaje en español para el usuario)."""


# ============================================================================ utilidades

def _u(valor):
    """Convierte a texto unicode (bytes UTF-8 incluidos)."""
    if valor is None:
        return u''
    if isinstance(valor, text_type):
        return valor
    if isinstance(valor, bytes) and PY3:
        return valor.decode('utf-8')
    try:
        return text_type(valor)
    except Exception:  # pragma: no cover (py2 con bytes no ASCII)
        return str(valor).decode('utf-8')


def _xml_escape(texto):
    texto = _u(texto)
    # caracteres de control no permitidos en XML 1.0 (excepto tab, salto de línea y retorno)
    texto = re.sub(u'[\x00-\x08\x0b\x0c\x0e-\x1f]', u'', texto)
    return (texto.replace(u'&', u'&amp;').replace(u'<', u'&lt;')
            .replace(u'>', u'&gt;').replace(u'"', u'&quot;'))


_ENTIDADES = {u'amp': u'&', u'lt': u'<', u'gt': u'>', u'quot': u'"', u'apos': u"'"}


def _unichr(n):
    try:
        return unichr(n)  # noqa: F821
    except NameError:
        return chr(n)


def _xml_unescape(texto):
    def repl(m):
        ent = m.group(1)
        if ent.startswith(u'#x') or ent.startswith(u'#X'):
            return _unichr(int(ent[2:], 16))
        if ent.startswith(u'#'):
            return _unichr(int(ent[1:]))
        return _ENTIDADES.get(ent, m.group(0))
    return re.sub(u'&(#?[A-Za-z0-9]+);', repl, texto)


_ATTR_RE = re.compile(u'([A-Za-z_:][-A-Za-z0-9_:.]*)\\s*=\\s*("([^"]*)"|\'([^\']*)\')')


def _atributos(etiqueta):
    """Atributos de una etiqueta XML como dict (sin prefijo de espacio de nombres)."""
    res = {}
    for m in _ATTR_RE.finditer(etiqueta):
        nombre = m.group(1)
        if u':' in nombre:
            pref, local = nombre.split(u':', 1)
            if pref == u'xmlns':
                continue
            nombre = local if pref != u'xml' else nombre
        valor = m.group(3) if m.group(3) is not None else m.group(4)
        res[nombre] = _xml_unescape(valor)
    return res


def col_letra(indice):
    """0 -> A, 25 -> Z, 26 -> AA."""
    indice += 1
    letras = u''
    while indice:
        indice, resto = divmod(indice - 1, 26)
        letras = _unichr(65 + resto) + letras
    return letras


def col_indice(letras):
    """A -> 0, AA -> 26."""
    n = 0
    for ch in letras.upper():
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def ref(fila, col):
    """Referencia A1 a partir de fila y columna (base 0)."""
    return u'%s%d' % (col_letra(col), fila + 1)


def _sin_ns(xml):
    """Quita prefijos de espacio de nombres en etiquetas (<x:row> -> <row>)."""
    return re.sub(u'<(/?)[A-Za-z0-9_]+:', u'<\\1', xml)


# ============================================================================ LECTURA

_FECHA_BASE = datetime.datetime(1899, 12, 30)
_FORMATOS_FECHA_INCORPORADOS = set([14, 15, 16, 17, 22, 27, 30, 36, 50, 57])
_FORMATOS_HORA_INCORPORADOS = set([18, 19, 20, 21, 45, 46, 47])


def _es_formato_fecha(codigo):
    codigo = re.sub(u'"[^"]*"', u'', codigo)        # textos literales
    codigo = re.sub(u'\\[[^\\]]*\\]', u'', codigo)    # colores, condiciones, [$-es-PE]
    codigo = re.sub(u'\\\\.', u'', codigo)           # caracteres escapados (\d)
    return bool(re.search(u'[dyDY]', codigo)) or (bool(re.search(u'[mM]', codigo)) and not re.search(u'[hHsS]', codigo) and bool(re.search(u'[dDyY]', codigo)))


class Hoja(object):
    """Hoja leída: nombre y filas (listas de valores: texto, float, bool, datetime o None)."""

    def __init__(self, nombre, filas, oculta=False):
        self.nombre = nombre
        self.filas = filas
        self.oculta = oculta

    def celda(self, fila, col):
        if fila < len(self.filas) and col < len(self.filas[fila]):
            return self.filas[fila][col]
        return None

    def __repr__(self):
        return u'<Hoja %s: %d filas>' % (self.nombre, len(self.filas))


def leer_libro(ruta):
    """Lee un .xlsx y devuelve una lista de Hoja en el orden del libro."""
    if not os.path.isfile(ruta):
        raise ExcelError(u'No se encontró el archivo:\n%s' % ruta)
    ext = os.path.splitext(ruta)[1].lower()
    if ext in (u'.xls', '.xls'):
        raise ExcelError(u'El archivo es .xls (Excel 97-2003). Ábralo en Excel y guárdelo como '
                         u'«Libro de Excel (.xlsx)».')
    try:
        zf = zipfile.ZipFile(ruta, 'r')
    except Exception as ex:
        raise ExcelError(u'No se pudo abrir el Excel (¿está dañado o no es .xlsx?):\n%s\n\n%s' % (ruta, ex))
    try:
        nombres = set(zf.namelist())

        def leer(nombre):
            nombre = nombre.lstrip('/')
            if nombre not in nombres:
                return None
            return _sin_ns(zf.read(nombre).decode('utf-8'))

        libro_xml = leer('xl/workbook.xml')
        if libro_xml is None:
            raise ExcelError(u'El archivo no es un libro de Excel válido (.xlsx).')
        rels = {}
        rels_xml = leer('xl/_rels/workbook.xml.rels') or u''
        for m in re.finditer(u'<Relationship\\b([^>]*)/?>', rels_xml):
            a = _atributos(m.group(1))
            destino = a.get(u'Target', u'')
            if destino.startswith(u'/'):
                destino = destino[1:]
            elif not destino.startswith(u'xl/'):
                destino = u'xl/' + destino
            rels[a.get(u'Id')] = destino

        compartidas = _leer_compartidas(leer('xl/sharedStrings.xml'))
        estilos_fecha = _leer_estilos_fecha(leer('xl/styles.xml'))
        fecha1904 = bool(re.search(u'date1904\\s*=\\s*"(1|true)"', libro_xml))

        hojas = []
        for m in re.finditer(u'<sheet\\b([^>]*)/?>', libro_xml):
            a = _atributos(m.group(1))
            destino = rels.get(a.get(u'id'))
            if not destino:
                continue
            xml = leer(destino)
            if xml is None:
                continue
            filas = _leer_hoja(xml, compartidas, estilos_fecha, fecha1904)
            hojas.append(Hoja(a.get(u'name', u''), filas, a.get(u'state', u'visible') != u'visible'))
        return hojas
    finally:
        zf.close()


def _texto_de_si(fragmento):
    """Texto de un <si> o <is> (con o sin formato enriquecido <r>), ignorando la fonética <rPh>."""
    fragmento = re.sub(u'<rPh\\b.*?</rPh>', u'', fragmento, flags=re.S)
    partes = re.findall(u'<t\\b[^>]*?(?:/>|>(.*?)</t>)', fragmento, flags=re.S)
    return _decodificar_x(_xml_unescape(u''.join(partes)))


def _decodificar_x(texto):
    """Excel guarda algunos caracteres como _x000D_ (retorno de carro) o _x0009_ (tabulación)."""
    if u'_x' not in texto:
        return texto
    return re.sub(u'_x([0-9A-Fa-f]{4})_', lambda m: _unichr(int(m.group(1), 16)), texto)


def _leer_compartidas(xml):
    if not xml:
        return []
    res = []
    for m in re.finditer(u'<si\\b[^>]*?(?:/>|>(.*?)</si>)', xml, flags=re.S):
        res.append(_texto_de_si(m.group(1) or u''))
    return res


def _leer_estilos_fecha(xml):
    """Conjunto de índices de estilo (xf) que tienen formato de fecha u hora."""
    if not xml:
        return set()
    personalizados = {}
    for m in re.finditer(u'<numFmt\\b([^>]*)/?>', xml):
        a = _atributos(m.group(1))
        try:
            personalizados[int(a.get(u'numFmtId', u'-1'))] = a.get(u'formatCode', u'')
        except ValueError:
            pass
    res = set()
    m = re.search(u'<cellXfs\\b[^>]*>(.*?)</cellXfs>', xml, flags=re.S)
    if not m:
        return res
    for i, xf in enumerate(re.finditer(u'<xf\\b([^>]*?)(?:/>|>)', m.group(1))):
        a = _atributos(xf.group(1))
        try:
            fid = int(a.get(u'numFmtId', u'0'))
        except ValueError:
            continue
        if fid in _FORMATOS_FECHA_INCORPORADOS or fid in (22,):
            res.add(i)
        elif fid in _FORMATOS_HORA_INCORPORADOS:
            res.add(-1 - i)   # solo hora (se marca con índice negativo)
        elif fid in personalizados and _es_formato_fecha(personalizados[fid]):
            res.add(i)
    return res


_CELDA_RE = re.compile(u'<c\\b([^>]*?)(?:/>|>(.*?)</c>)', re.S)
_FILA_RE = re.compile(u'<row\\b([^>]*?)(?:/>|>(.*?)</row>)', re.S)


def _numero(texto):
    # ojo: en IronPython float(None) lanza SystemError, no TypeError
    if texto is None or texto == u'':
        return None
    try:
        return float(texto)
    except Exception:
        return None


def serial_a_fecha(serial, fecha1904=False):
    base = datetime.datetime(1904, 1, 1) if fecha1904 else _FECHA_BASE
    return base + datetime.timedelta(days=float(serial))


def _leer_hoja(xml, compartidas, estilos_fecha, fecha1904):
    filas = []
    m = re.search(u'<sheetData\\b[^>]*?(?:/>|>(.*?)</sheetData>)', xml, flags=re.S)
    if not m or not m.group(1):
        return filas
    fila_auto = 0
    for fm in _FILA_RE.finditer(m.group(1)):
        fa = _atributos(fm.group(1))
        try:
            nfila = int(fa.get(u'r')) - 1
        except Exception:
            nfila = fila_auto
        fila_auto = nfila + 1
        valores = {}
        col_auto = 0
        for cm in _CELDA_RE.finditer(fm.group(2) or u''):
            ca = _atributos(cm.group(1))
            r = ca.get(u'r')
            if r:
                letras = re.match(u'[A-Za-z]+', r)
                col = col_indice(letras.group(0)) if letras else col_auto
            else:
                col = col_auto
            col_auto = col + 1
            interior = cm.group(2) or u''
            tipo = ca.get(u't', u'n')
            vm = re.search(u'<v\\b[^>]*>(.*?)</v>', interior, flags=re.S)
            v = _xml_unescape(vm.group(1)) if vm else None
            valor = None
            if tipo == u's':
                try:
                    valor = compartidas[int(v)]
                except (TypeError, ValueError, IndexError):
                    valor = None
            elif tipo == u'inlineStr':
                im = re.search(u'<is\\b[^>]*>(.*?)</is>', interior, flags=re.S)
                valor = _texto_de_si(im.group(1)) if im else u''
            elif tipo in (u'str', u'e'):
                valor = _decodificar_x(v) if v else v
            elif tipo == u'b':
                valor = (v == u'1')
            elif tipo == u'd':
                valor = v  # fecha ISO (poco común)
            else:
                num = _numero(v)
                if num is not None:
                    try:
                        estilo = int(ca.get(u's', u'0'))
                    except ValueError:
                        estilo = 0
                    if estilo in estilos_fecha:
                        try:
                            valor = serial_a_fecha(num, fecha1904)
                        except Exception:
                            valor = num
                    elif (-1 - estilo) in estilos_fecha:
                        minutos = int(round((num % 1) * 1440))
                        valor = u'%02d:%02d' % (minutos // 60 % 24, minutos % 60)
                    else:
                        valor = num
            if valor is not None and valor != u'':
                valores[col] = valor
        if valores:
            while len(filas) < nfila:
                filas.append([])
            fila = [None] * (max(valores.keys()) + 1)
            for c, val in valores.items():
                fila[c] = val
            if len(filas) == nfila:
                filas.append(fila)
            else:
                filas[nfila] = fila
    return filas


MESES = [u'enero', u'febrero', u'marzo', u'abril', u'mayo', u'junio', u'julio', u'agosto', u'setiembre',
         u'octubre', u'noviembre', u'diciembre']


def fecha_texto(fecha, formato=u'%d/%m/%Y'):
    """strftime con el nombre del mes en español (%B) e independiente del idioma de Windows."""
    formato = _u(formato).replace(u'%B', MESES[fecha.month - 1])
    partes = []
    i = 0
    while i < len(formato):
        if formato[i] == u'%' and i + 1 < len(formato):
            codigo = formato[i + 1]
            valores = {u'd': u'%02d' % fecha.day, u'm': u'%02d' % fecha.month, u'Y': u'%04d' % fecha.year,
                       u'y': u'%02d' % (fecha.year % 100), u'H': u'%02d' % getattr(fecha, 'hour', 0),
                       u'M': u'%02d' % getattr(fecha, 'minute', 0), u'%': u'%'}
            partes.append(valores.get(codigo, u'%' + codigo))
            i += 2
        else:
            partes.append(formato[i])
            i += 1
    return u''.join(partes)


def valor_a_texto(valor, formato_fecha=u'%d/%m/%Y'):
    """Convierte un valor leído en el texto que se escribirá en Revit."""
    if valor is None:
        return u''
    if isinstance(valor, bool):
        return u'Sí' if valor else u'No'
    if isinstance(valor, datetime.datetime):
        if valor.hour or valor.minute or valor.second:
            return fecha_texto(valor, formato_fecha + u' %H:%M')
        return fecha_texto(valor, formato_fecha)
    if isinstance(valor, float):
        if valor == int(valor) and abs(valor) < 1e15:
            return _u(str(int(valor)))
        texto = repr(valor)
        if u'e' in texto or u'E' in texto:
            return _u(u'%g' % valor)
        return _u(texto)
    return _u(valor).strip()


# ============================================================================ ESCRITURA

class Estilo(object):
    """Estilo de celda. Todos los textos usan Times New Roman."""

    def __init__(self, negrita=False, cursiva=False, tamano=11, color=u'000000', relleno=None,
                 borde=True, horizontal=None, vertical=u'center', ajustar=False, formato=None,
                 subrayado=False, borde_grueso=False):
        self.negrita = negrita
        self.cursiva = cursiva
        self.tamano = tamano
        self.color = color
        self.relleno = relleno
        self.borde = borde
        self.horizontal = horizontal
        self.vertical = vertical
        self.ajustar = ajustar
        self.formato = formato
        self.subrayado = subrayado
        self.borde_grueso = borde_grueso

    def clave_fuente(self):
        return (self.negrita, self.cursiva, self.tamano, self.color, self.subrayado)

    def clave_borde(self):
        return (self.borde, self.borde_grueso)


class HojaNueva(object):
    def __init__(self, nombre):
        nombre = re.sub(u'[\\[\\]:*?/\\\\]', u'', _u(nombre))[:31] or u'Hoja'
        self.nombre = nombre
        self.celdas = {}            # (fila, col) -> (valor, Estilo)
        self.anchos = {}            # col -> ancho
        self.altos = {}             # fila -> alto
        self.fijar = None           # (fila, col) primera celda NO fija
        self.filtro = None          # 'A4:H50'
        self.combinadas = []        # 'A1:H1'
        self.validaciones = []      # (rango, formula, mensaje)
        self.oculta = False
        self.horizontal = True      # orientación de impresión
        self.titulos_impresion = None  # (fila_ini, fila_fin) base 0
        self.ajustar_ancho = True
        self.color_pestana = None
        self.zoom = None
        self.vinculos = []          # (ref, url)
        self.cuadricula = True

    def escribir(self, fila, col, valor, estilo=None):
        self.celdas[(fila, col)] = (valor, estilo)

    def fila(self, fila, valores, estilo=None, col_inicio=0):
        for i, v in enumerate(valores):
            est = estilo[i] if isinstance(estilo, (list, tuple)) else estilo
            self.escribir(fila, col_inicio + i, v, est)

    def combinar(self, fila1, col1, fila2, col2, valor=None, estilo=None):
        if (fila1, col1) != (fila2, col2):
            self.combinadas.append(u'%s:%s' % (ref(fila1, col1), ref(fila2, col2)))
        if valor is not None or estilo is not None:
            self.escribir(fila1, col1, valor, estilo)
        if estilo is not None:
            for f in range(fila1, fila2 + 1):
                for c in range(col1, col2 + 1):
                    if (f, c) != (fila1, col1) and (f, c) not in self.celdas:
                        self.escribir(f, c, None, estilo)

    def lista(self, rango, formula, mensaje=None):
        self.validaciones.append((rango, formula, mensaje))

    def vinculo(self, fila, col, url):
        self.vinculos.append((ref(fila, col), url))


class LibroNuevo(object):
    def __init__(self):
        self.hojas = []
        self.titulo = u''
        self.autor = u'PlanosALF — ALF_BIM'

    def hoja(self, nombre):
        h = HojaNueva(nombre)
        self.hojas.append(h)
        return h

    # ------------------------------------------------------------ guardado
    def guardar(self, ruta):
        fuentes = [(False, False, 11, u'000000', False)]
        rellenos = [None, u'gray125']
        bordes = [(False, False)]
        formatos = {}
        xfs = [(0, 0, 0, 0, None, u'center', False)]
        indice_xf = {}

        def idx(lista, clave):
            if clave not in lista:
                lista.append(clave)
            return lista.index(clave)

        def xf_de(estilo, valor):
            if estilo is None:
                if isinstance(valor, datetime.datetime):
                    estilo = Estilo(borde=False, formato=u'dd/mm/yyyy')
                else:
                    return 0
            f = idx(fuentes, estilo.clave_fuente())
            r = idx(rellenos, estilo.relleno) if estilo.relleno else 0
            b = idx(bordes, estilo.clave_borde()) if estilo.borde else 0
            fmt = estilo.formato
            if fmt is None and isinstance(valor, datetime.datetime):
                fmt = u'dd/mm/yyyy'
            nf = 0
            if fmt:
                if fmt == u'0':
                    nf = 1
                elif fmt == u'0.00':
                    nf = 2
                elif fmt == u'@':
                    nf = 49
                else:
                    if fmt not in formatos:
                        formatos[fmt] = 164 + len(formatos)
                    nf = formatos[fmt]
            clave = (f, r, b, nf, estilo.horizontal, estilo.vertical, estilo.ajustar)
            if clave not in indice_xf:
                indice_xf[clave] = len(xfs)
                xfs.append(clave)
            return indice_xf[clave]

        compartidas = []
        indice_comp = {}

        def comp(texto):
            if texto not in indice_comp:
                indice_comp[texto] = len(compartidas)
                compartidas.append(texto)
            return indice_comp[texto]

        hojas_xml = []
        for h in self.hojas:
            hojas_xml.append(self._hoja_xml(h, xf_de, comp))

        archivos = []
        archivos.append(('[Content_Types].xml', self._content_types()))
        archivos.append(('_rels/.rels', _RELS_RAIZ))
        archivos.append(('docProps/core.xml', self._core()))
        archivos.append(('docProps/app.xml', _APP))
        archivos.append(('xl/workbook.xml', self._workbook_xml()))
        archivos.append(('xl/_rels/workbook.xml.rels', self._workbook_rels()))
        archivos.append(('xl/styles.xml', self._estilos_xml(fuentes, rellenos, bordes, formatos, xfs)))
        archivos.append(('xl/sharedStrings.xml', self._compartidas_xml(compartidas)))
        for i, (xml, rels) in enumerate(hojas_xml):
            archivos.append(('xl/worksheets/sheet%d.xml' % (i + 1), xml))
            if rels:
                archivos.append(('xl/worksheets/_rels/sheet%d.xml.rels' % (i + 1), rels))

        carpeta = os.path.dirname(os.path.abspath(ruta))
        if carpeta and not os.path.isdir(carpeta):
            os.makedirs(carpeta)
        temporal = ruta + u'.tmp'
        try:
            try:
                zf = zipfile.ZipFile(temporal, 'w', zipfile.ZIP_DEFLATED)
            except (RuntimeError, ImportError):  # sin zlib
                zf = zipfile.ZipFile(temporal, 'w', zipfile.ZIP_STORED)
            try:
                for nombre, contenido in archivos:
                    zf.writestr(nombre, _u(contenido).encode('utf-8'))
            finally:
                zf.close()
            if os.path.exists(ruta):
                try:
                    os.remove(ruta)
                except OSError:
                    raise ExcelError(u'No se pudo reemplazar el archivo (¿está abierto en Excel?):\n%s\n\n'
                                     u'Ciérrelo y vuelva a intentarlo.' % ruta)
            os.rename(temporal, ruta)
        except ExcelError:
            raise
        except (IOError, OSError) as ex:
            raise ExcelError(u'No se pudo guardar el Excel:\n%s\n\n%s\n\n¿Está abierto en Excel o la carpeta '
                             u'es de solo lectura?' % (ruta, ex))
        finally:
            if os.path.exists(temporal):
                try:
                    os.remove(temporal)
                except OSError:
                    pass
        return ruta

    def _hoja_xml(self, h, xf_de, comp):
        p = []
        p.append(u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n')
        p.append(u'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                 u'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">')
        p.append(u'<sheetPr>')
        if h.color_pestana:
            p.append(u'<tabColor rgb="FF%s"/>' % h.color_pestana)
        p.append(u'<pageSetUpPr fitToPage="1"/></sheetPr>')
        if h.celdas:
            maxf = max(k[0] for k in h.celdas)
            maxc = max(k[1] for k in h.celdas)
            p.append(u'<dimension ref="A1:%s"/>' % ref(maxf, maxc))
        p.append(u'<sheetViews><sheetView workbookViewId="0"')
        if not h.cuadricula:
            p.append(u' showGridLines="0"')
        if h.zoom:
            p.append(u' zoomScale="%d"' % h.zoom)
        if self.hojas and h is self.hojas[0]:
            p.append(u' tabSelected="1"')
        p.append(u'>')
        if h.fijar:
            fila, col = h.fijar
            panel = u'bottomRight' if (fila and col) else (u'bottomLeft' if fila else u'topRight')
            atr = u''
            if col:
                atr += u' xSplit="%d"' % col
            if fila:
                atr += u' ySplit="%d"' % fila
            p.append(u'<pane%s topLeftCell="%s" activePane="%s" state="frozen"/>' % (atr, ref(fila, col), panel))
            p.append(u'<selection pane="%s" activeCell="%s" sqref="%s"/>' % (panel, ref(fila, col), ref(fila, col)))
        p.append(u'</sheetView></sheetViews>')
        p.append(u'<sheetFormatPr defaultRowHeight="15"/>')
        if h.anchos:
            p.append(u'<cols>')
            for c in sorted(h.anchos):
                p.append(u'<col min="%d" max="%d" width="%.2f" customWidth="1"/>' % (c + 1, c + 1, h.anchos[c]))
            p.append(u'</cols>')
        p.append(u'<sheetData>')
        filas = {}
        for (f, c) in h.celdas:
            filas.setdefault(f, []).append(c)
        for f in sorted(set(list(filas.keys()) + list(h.altos.keys()))):
            atr = u''
            if f in h.altos:
                atr = u' ht="%.2f" customHeight="1"' % h.altos[f]
            p.append(u'<row r="%d"%s>' % (f + 1, atr))
            for c in sorted(filas.get(f, [])):
                valor, estilo = h.celdas[(f, c)]
                s = xf_de(estilo, valor)
                r = ref(f, c)
                sa = u' s="%d"' % s if s else u''
                if valor is None or valor == u'':
                    p.append(u'<c r="%s"%s/>' % (r, sa))
                elif isinstance(valor, bool):
                    p.append(u'<c r="%s"%s t="b"><v>%d</v></c>' % (r, sa, 1 if valor else 0))
                elif isinstance(valor, (int, float)) and not isinstance(valor, bool):
                    p.append(u'<c r="%s"%s><v>%s</v></c>' % (r, sa, repr(valor) if isinstance(valor, float) else valor))
                elif isinstance(valor, datetime.datetime):
                    serial = (valor - _FECHA_BASE).total_seconds() / 86400.0
                    p.append(u'<c r="%s"%s><v>%s</v></c>' % (r, sa, repr(serial)))
                elif isinstance(valor, Formula):
                    p.append(u'<c r="%s"%s><f>%s</f></c>' % (r, sa, _xml_escape(valor.texto)))
                else:
                    p.append(u'<c r="%s"%s t="s"><v>%d</v></c>' % (r, sa, comp(_u(valor))))
            p.append(u'</row>')
        p.append(u'</sheetData>')
        if h.filtro:
            p.append(u'<autoFilter ref="%s"/>' % h.filtro)
        if h.combinadas:
            p.append(u'<mergeCells count="%d">' % len(h.combinadas))
            for rango in h.combinadas:
                p.append(u'<mergeCell ref="%s"/>' % rango)
            p.append(u'</mergeCells>')
        if h.validaciones:
            p.append(u'<dataValidations count="%d">' % len(h.validaciones))
            for rango, formula, mensaje in h.validaciones:
                atr = u' showErrorMessage="0"'
                if mensaje:
                    atr += u' showInputMessage="1" prompt="%s"' % _xml_escape(mensaje[:250])
                p.append(u'<dataValidation type="list" allowBlank="1"%s sqref="%s"><formula1>%s</formula1>'
                         u'</dataValidation>' % (atr, rango, _xml_escape(formula)))
            p.append(u'</dataValidations>')
        rels = None
        if h.vinculos:
            p.append(u'<hyperlinks>')
            rel = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships '
                   u'xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
            for i, (r, url) in enumerate(h.vinculos):
                p.append(u'<hyperlink ref="%s" r:id="rIdV%d"/>' % (r, i + 1))
                rel.append(u'<Relationship Id="rIdV%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                           u'relationships/hyperlink" Target="%s" TargetMode="External"/>' % (i + 1, _xml_escape(url)))
            p.append(u'</hyperlinks>')
            rel.append(u'</Relationships>')
            rels = u''.join(rel)
        p.append(u'<printOptions horizontalCentered="1"/>')
        p.append(u'<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>')
        p.append(u'<pageSetup paperSize="9" orientation="%s" fitToWidth="1" fitToHeight="0"/>'
                 % (u'landscape' if h.horizontal else u'portrait'))
        p.append(u'<headerFooter><oddFooter>&amp;L&amp;"Times New Roman,Regular"&amp;8PlanosALF — ALF_BIM'
                 u'&amp;R&amp;"Times New Roman,Regular"&amp;8Página &amp;P de &amp;N</oddFooter></headerFooter>')
        p.append(u'</worksheet>')
        return u''.join(p), rels

    def _content_types(self):
        p = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types '
             u'xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
             u'<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
             u'<Default Extension="xml" ContentType="application/xml"/>'
             u'<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.'
             u'spreadsheetml.sheet.main+xml"/>'
             u'<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.'
             u'spreadsheetml.styles+xml"/>'
             u'<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-'
             u'officedocument.spreadsheetml.sharedStrings+xml"/>'
             u'<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.'
             u'core-properties+xml"/>'
             u'<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-'
             u'officedocument.extended-properties+xml"/>']
        for i in range(len(self.hojas)):
            p.append(u'<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.'
                     u'openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1))
        p.append(u'</Types>')
        return u''.join(p)

    def _core(self):
        ahora = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
        return (u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<cp:coreProperties '
                u'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
                u'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
                u'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>%s</dc:title>'
                u'<dc:creator>%s</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created>'
                u'<dcterms:modified xsi:type="dcterms:W3CDTF">%s</dcterms:modified></cp:coreProperties>'
                % (_xml_escape(self.titulo), _xml_escape(self.autor), ahora, ahora))

    def _workbook_xml(self):
        p = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook '
             u'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
             u'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
             u'<bookViews><workbookView activeTab="0"/></bookViews><sheets>']
        for i, h in enumerate(self.hojas):
            estado = u' state="hidden"' if h.oculta else u''
            p.append(u'<sheet name="%s" sheetId="%d"%s r:id="rId%d"/>' % (_xml_escape(h.nombre), i + 1, estado, i + 1))
        p.append(u'</sheets>')
        nombres = []
        for i, h in enumerate(self.hojas):
            if h.titulos_impresion:
                f1, f2 = h.titulos_impresion
                nombres.append(u'<definedName name="_xlnm.Print_Titles" localSheetId="%d">\'%s\'!$%d:$%d'
                               u'</definedName>' % (i, _xml_escape(h.nombre.replace(u"'", u"''")), f1 + 1, f2 + 1))
            if h.filtro:
                a, b = h.filtro.split(u':')
                ra = re.match(u'([A-Z]+)(\\d+)', a)
                rb = re.match(u'([A-Z]+)(\\d+)', b)
                nombres.append(u'<definedName name="_xlnm._FilterDatabase" localSheetId="%d" hidden="1">\'%s\'!'
                               u'$%s$%s:$%s$%s</definedName>' % (i, _xml_escape(h.nombre.replace(u"'", u"''")),
                                                                ra.group(1), ra.group(2), rb.group(1), rb.group(2)))
        if nombres:
            p.append(u'<definedNames>%s</definedNames>' % u''.join(nombres))
        p.append(u'<calcPr calcId="191029"/></workbook>')
        return u''.join(p)

    def _workbook_rels(self):
        p = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships '
             u'xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
        for i in range(len(self.hojas)):
            p.append(u'<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                     u'relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1))
        n = len(self.hojas)
        p.append(u'<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                 u'relationships/styles" Target="styles.xml"/>' % (n + 1))
        p.append(u'<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
                 u'relationships/sharedStrings" Target="sharedStrings.xml"/>' % (n + 2))
        p.append(u'</Relationships>')
        return u''.join(p)

    @staticmethod
    def _compartidas_xml(compartidas):
        p = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<sst '
             u'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="%d" uniqueCount="%d">'
             % (len(compartidas), len(compartidas))]
        for t in compartidas:
            esp = u' xml:space="preserve"' if (t != t.strip() or u'\n' in t) else u''
            p.append(u'<si><t%s>%s</t></si>' % (esp, _xml_escape(t)))
        p.append(u'</sst>')
        return u''.join(p)

    @staticmethod
    def _estilos_xml(fuentes, rellenos, bordes, formatos, xfs):
        p = [u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet '
             u'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">']
        if formatos:
            p.append(u'<numFmts count="%d">' % len(formatos))
            for codigo, fid in sorted(formatos.items(), key=lambda x: x[1]):
                p.append(u'<numFmt numFmtId="%d" formatCode="%s"/>' % (fid, _xml_escape(codigo)))
            p.append(u'</numFmts>')
        p.append(u'<fonts count="%d">' % len(fuentes))
        for negrita, cursiva, tamano, color, subrayado in fuentes:
            p.append(u'<font>%s%s%s<sz val="%s"/><color rgb="FF%s"/><name val="%s"/><family val="1"/></font>'
                     % (u'<b/>' if negrita else u'', u'<i/>' if cursiva else u'', u'<u/>' if subrayado else u'',
                        tamano, color, FUENTE))
        p.append(u'</fonts>')
        p.append(u'<fills count="%d">' % len(rellenos))
        for r in rellenos:
            if r is None:
                p.append(u'<fill><patternFill patternType="none"/></fill>')
            elif r == u'gray125':
                p.append(u'<fill><patternFill patternType="gray125"/></fill>')
            else:
                p.append(u'<fill><patternFill patternType="solid"><fgColor rgb="FF%s"/><bgColor indexed="64"/>'
                         u'</patternFill></fill>' % r)
        p.append(u'</fills>')
        p.append(u'<borders count="%d">' % len(bordes))
        for con_borde, grueso in bordes:
            if not con_borde:
                p.append(u'<border><left/><right/><top/><bottom/><diagonal/></border>')
            else:
                est = u'medium' if grueso else u'thin'
                lado = u'<%%s style="%s"><color rgb="FF7F7F7F"/></%%s>' % est
                p.append(u'<border>%s%s%s%s<diagonal/></border>' % (lado % (u'left', u'left'), lado % (u'right', u'right'),
                                                                     lado % (u'top', u'top'), lado % (u'bottom', u'bottom')))
        p.append(u'</borders>')
        p.append(u'<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>')
        p.append(u'<cellXfs count="%d">' % len(xfs))
        for f, r, b, nf, hor, ver, ajustar in xfs:
            atr = u' numFmtId="%d" fontId="%d" fillId="%d" borderId="%d" xfId="0"' % (nf, f, r, b)
            if nf:
                atr += u' applyNumberFormat="1"'
            if f:
                atr += u' applyFont="1"'
            if r:
                atr += u' applyFill="1"'
            if b:
                atr += u' applyBorder="1"'
            alin = u''
            if hor or ver or ajustar:
                atr += u' applyAlignment="1"'
                alin = u'<alignment%s%s%s/>' % (u' horizontal="%s"' % hor if hor else u'',
                                                u' vertical="%s"' % ver if ver else u'',
                                                u' wrapText="1"' if ajustar else u'')
            p.append(u'<xf%s>%s</xf>' % (atr, alin) if alin else u'<xf%s/>' % atr)
        p.append(u'</cellXfs>')
        p.append(u'<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>')
        p.append(u'</styleSheet>')
        return u''.join(p)


class Formula(object):
    """Fórmula de Excel (sin el signo =)."""

    def __init__(self, texto):
        self.texto = texto


_RELS_RAIZ = (u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships '
              u'xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
              u'<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
              u'officeDocument" Target="xl/workbook.xml"/>'
              u'<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/'
              u'core-properties" Target="docProps/core.xml"/>'
              u'<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
              u'extended-properties" Target="docProps/app.xml"/></Relationships>')

_APP = (u'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Properties '
        u'xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
        u'<Application>PlanosALF</Application><Company>ALF_BIM</Company></Properties>')


# Estilos de la marca ALF_BIM (Times New Roman siempre)
AZUL = u'2F7CF6'
NEGRO = u'0B0B0B'
TURQUESA = u'0F766E'
GRIS_CLARO = u'F2F2F2'

ESTILOS = {
    u'titulo': Estilo(negrita=True, tamano=16, color=NEGRO, borde=False, horizontal=u'left'),
    u'subtitulo': Estilo(tamano=11, color=u'404040', borde=False, horizontal=u'left'),
    u'marca': Estilo(negrita=True, tamano=10, color=TURQUESA, borde=False, horizontal=u'right'),
    u'encabezado': Estilo(negrita=True, tamano=11, color=u'FFFFFF', relleno=NEGRO, horizontal=u'center',
                          ajustar=True),
    u'encabezado_param': Estilo(negrita=True, tamano=11, color=u'FFFFFF', relleno=TURQUESA, horizontal=u'center',
                                ajustar=True),
    u'encabezado_id': Estilo(negrita=True, tamano=9, color=u'FFFFFF', relleno=u'8C8C8C', horizontal=u'center',
                             ajustar=True),
    u'celda': Estilo(tamano=11),
    u'celda_texto': Estilo(tamano=11, formato=u'@'),
    u'celda_centro': Estilo(tamano=11, horizontal=u'center'),
    u'celda_centro_texto': Estilo(tamano=11, horizontal=u'center', formato=u'@'),
    u'celda_ajuste': Estilo(tamano=11, ajustar=True),
    u'celda_negrita': Estilo(tamano=11, negrita=True),
    u'celda_id': Estilo(tamano=8, color=u'8C8C8C', formato=u'@'),
    u'grupo': Estilo(negrita=True, tamano=11, relleno=u'D9E7FD', color=NEGRO),
    u'nota': Estilo(cursiva=True, tamano=10, color=u'595959', borde=False, ajustar=True, vertical=u'top'),
    u'texto': Estilo(tamano=11, borde=False, ajustar=True, vertical=u'top'),
    u'texto_negrita': Estilo(tamano=11, negrita=True, borde=False, vertical=u'top'),
    u'vinculo': Estilo(tamano=11, color=AZUL, borde=False, subrayado=True),
    u'ok': Estilo(tamano=11, color=u'1E7B34', horizontal=u'center'),
    u'error': Estilo(tamano=11, color=u'C00000', horizontal=u'center'),
}
