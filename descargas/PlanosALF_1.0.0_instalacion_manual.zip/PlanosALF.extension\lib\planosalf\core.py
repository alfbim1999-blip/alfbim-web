# -*- coding: utf-8 -*-
"""Lógica de PlanosALF que no depende de Revit (se prueba fuera de Revit).

- Especialidades y prefijos de lámina (E-, IE-, IS-…), numeración y orden natural.
- Lectura de la hoja LÁMINAS del Excel y plan de creación/actualización.
- Plan de renumeración sin choques.
- Nombres de archivo estandarizados para PDF/DWG.

ALF_BIM — Ing. Anderson Irigoín C.
"""
from __future__ import print_function, division

import re

try:
    import unicodedata
except ImportError:  # pragma: no cover (algunas versiones de IronPython)
    unicodedata = None

from planosalf import xlsx

_u = xlsx._u

# ============================================================================ textos

def normalizar(texto):
    """Minúsculas, sin tildes ni signos: 'Número de lámina' -> 'numerodelamina'."""
    texto = _u(texto).strip().lower()
    if unicodedata is not None:
        texto = unicodedata.normalize('NFKD', texto)
        texto = u''.join(c for c in texto if not unicodedata.combining(c))
    else:
        for a, b in zip(u'áéíóúàèìòùäëïöüâêîôûñç', u'aeiouaeiouaeiouaeiounc'):
            texto = texto.replace(a, b)
    return re.sub(u'[^a-z0-9]', u'', texto)


def clave_natural(texto):
    """Clave de orden natural: 'E-2' antes que 'E-10'."""
    partes = re.split(u'(\\d+)', _u(texto).upper())
    res = []
    for p in partes:
        if p.isdigit():
            res.append((1, int(p), u''))
        elif p:
            res.append((0, 0, p))
    return res


# ============================================================================ especialidades

ESPECIALIDADES_PERU = [
    (u'U', u'Ubicación y localización'),
    (u'T', u'Topografía'),
    (u'PP', u'Plano perimétrico'),
    (u'A', u'Arquitectura'),
    (u'D', u'Detalles arquitectónicos'),
    (u'E', u'Estructuras'),
    (u'IS', u'Instalaciones sanitarias'),
    (u'ACI', u'Agua contra incendio'),
    (u'IE', u'Instalaciones eléctricas'),
    (u'IM', u'Instalaciones mecánicas'),
    (u'IC', u'Instalaciones de comunicaciones'),
    (u'GN', u'Instalaciones de gas'),
    (u'SE', u'Señalización'),
    (u'EV', u'Seguridad y evacuación'),
    (u'EQ', u'Equipamiento'),
]


class Especialidades(object):
    """Tabla de especialidades: código (prefijo) -> nombre, en el orden del expediente."""

    def __init__(self, pares=None):
        self.pares = []
        for codigo, nombre in (pares if pares is not None else ESPECIALIDADES_PERU):
            codigo = _u(codigo).strip().upper()
            if codigo and codigo not in [c for c, _ in self.pares]:
                self.pares.append((codigo, _u(nombre).strip()))

    def codigos(self):
        return [c for c, _ in self.pares]

    def nombre(self, codigo):
        codigo = _u(codigo).strip().upper()
        for c, n in self.pares:
            if c == codigo:
                return n
        return u''

    def orden(self, codigo):
        codigo = _u(codigo).strip().upper()
        for i, (c, _) in enumerate(self.pares):
            if c == codigo:
                return i
        return len(self.pares)

    def codigo_de_texto(self, texto):
        """Acepta el código ('IE') o el nombre ('Instalaciones eléctricas')."""
        t = _u(texto).strip()
        if not t:
            return u''
        if t.upper() in self.codigos():
            return t.upper()
        n = normalizar(t)
        for c, nombre in self.pares:
            if normalizar(nombre) == n:
                return c
        # 'IE - Instalaciones eléctricas'
        m = re.match(u'^([A-Za-zÑñ]+)\\s*[-–:]', t)
        if m and m.group(1).upper() in self.codigos():
            return m.group(1).upper()
        return t.upper() if re.match(u'^[A-Za-zÑñ]{1,5}$', t) else u''

    def de_numero(self, numero):
        """Código de especialidad de un número de lámina ('IE-01' -> 'IE'). Prefiere el código más largo."""
        numero = _u(numero).strip().upper()
        if not numero:
            return u''
        mejor = u''
        for c in self.codigos():
            if numero.startswith(c):
                resto = numero[len(c):]
                if (not resto or not resto[0].isalpha()) and len(c) > len(mejor):
                    mejor = c
        if mejor:
            return mejor
        m = re.match(u'^([A-ZÑ]+)(?![A-ZÑ])', numero)
        return m.group(1) if m else u''


def separar_numero(numero, separador=u'-'):
    """'IE-05' -> ('IE', 5, 2); 'E-101A' -> ('E', 101, 3); '1001' -> ('', 1001, 4). Sin número: (texto, None, 0)."""
    numero = _u(numero).strip()
    m = re.match(u'^(.*?)(\\d+)([^\\d]*)$', numero)
    if not m:
        return numero, None, 0
    prefijo = m.group(1)
    if separador and prefijo.endswith(separador):
        prefijo = prefijo[:-len(separador)]
    prefijo = prefijo.rstrip(u' -_.')
    return prefijo, int(m.group(2)), len(m.group(2))


def formatear_numero(prefijo, n, digitos=2, separador=u'-'):
    prefijo = _u(prefijo).strip()
    cuerpo = _u(str(int(n))).zfill(max(1, int(digitos)))
    return u'%s%s%s' % (prefijo, separador if prefijo else u'', cuerpo)


# parámetros incorporados de la Información del proyecto: nombre del parámetro de Revit (BuiltInParameter) y
# nombres aceptados en el Excel (normalizados), en español (Revit en español usa «Nombre de proyecto») e inglés
ALIAS_PROYECTO = [
    (u'PROJECT_NAME', [u'nombredelproyecto', u'nombredeproyecto', u'proyecto', u'nombreproyecto', u'projectname']),
    (u'PROJECT_NUMBER', [u'numerodelproyecto', u'numerodeproyecto', u'codigodelproyecto', u'numeroproyecto',
                         u'projectnumber']),
    (u'CLIENT_NAME', [u'nombredelcliente', u'nombredecliente', u'cliente', u'entidad', u'propietario', u'clientname']),
    (u'PROJECT_ADDRESS', [u'direcciondelproyecto', u'direcciondeproyecto', u'direccion', u'ubicacion',
                          u'projectaddress']),
    (u'PROJECT_STATUS', [u'estadodelproyecto', u'estadodeproyecto', u'estado', u'projectstatus']),
    (u'PROJECT_ISSUE_DATE', [u'fechadeemisiondelproyecto', u'fechadeemisiondeproyecto', u'projectissuedate']),
    (u'PROJECT_ORGANIZATION_NAME', [u'nombredelaorganizacion', u'nombredeorganizacion', u'organizacion',
                                    u'organizationname']),
    (u'PROJECT_ORGANIZATION_DESCRIPTION', [u'descripciondelaorganizacion', u'descripciondeorganizacion',
                                           u'organizationdescription']),
    (u'PROJECT_BUILDING_NAME', [u'nombredeledificio', u'edificio', u'buildingname']),
    (u'PROJECT_AUTHOR', [u'autor', u'author']),
]

ALIAS_LAMINA = [
    (u'SHEET_DRAWN_BY', [u'dibujadopor', u'dibujo', u'dibujante', u'drawnby', u'cad']),
    (u'SHEET_CHECKED_BY', [u'comprobadopor', u'revisadopor', u'reviso', u'revisor', u'checkedby']),
    (u'SHEET_DESIGNED_BY', [u'disenadopor', u'diseno', u'disenador', u'proyectista', u'designedby']),
    (u'SHEET_APPROVED_BY', [u'aprobadopor', u'aprobo', u'approvedby']),
    (u'SHEET_ISSUE_DATE', [u'fechadeemision', u'fechadeemisiondehoja', u'fechadeemisiondelahoja', u'fecha',
                           u'fechadelamina', u'sheetissuedate']),
]


def clave_alias(nombre, tabla):
    """BuiltInParameter (texto) al que corresponde un nombre de columna, o ''."""
    n = normalizar(nombre)
    for clave, alias in tabla:
        if n in alias:
            return clave
    return u''


# ============================================================================ nombres de archivo

PATRONES_ARCHIVO = [
    u'{Numero}',
    u'{Numero} - {Nombre}',
    u'{NumeroProyecto}_{Numero}',
    u'{Numero}_{Revision}',
    u'{NumeroProyecto}_{Numero} - {Nombre}',
]

CAMPOS_PATRON = [
    (u'Numero', u'Número de la lámina (E-01)'),
    (u'Nombre', u'Nombre de la lámina'),
    (u'Codigo', u'Código de la especialidad (E, IE, IS…)'),
    (u'Especialidad', u'Nombre de la especialidad'),
    (u'Revision', u'Revisión actual de la lámina'),
    (u'FechaRevision', u'Fecha de la revisión actual'),
    (u'Proyecto', u'Nombre del proyecto'),
    (u'NumeroProyecto', u'Número o código del proyecto'),
    (u'Cliente', u'Cliente o entidad'),
    (u'Fecha', u'Fecha de hoy (aaaa-mm-dd)'),
]

_INVALIDOS = re.compile(u'[<>:"/\\\\|?*\x00-\x1f]')
_RESERVADOS = set([u'CON', u'PRN', u'AUX', u'NUL'] + [u'COM%d' % i for i in range(1, 10)] +
                  [u'LPT%d' % i for i in range(1, 10)])


def limpiar_nombre_archivo(nombre, maximo=150):
    nombre = _INVALIDOS.sub(u'_', _u(nombre))
    nombre = re.sub(u'\\s+', u' ', nombre).strip().rstrip(u'.').strip()
    if nombre.upper() in _RESERVADOS:
        nombre = u'_' + nombre
    if len(nombre) > maximo:
        nombre = nombre[:maximo].rstrip(u' ._-')
    return nombre or u'Lamina'


def aplicar_patron(patron, datos):
    """Reemplaza {Campo} por su valor (sin distinguir mayúsculas ni tildes); quita separadores sobrantes."""
    datos_n = dict((normalizar(k), _u(v)) for k, v in datos.items())

    def repl(m):
        return datos_n.get(normalizar(m.group(1)), u'')

    texto = re.sub(u'\\{([^{}]+)\\}', repl, _u(patron))
    texto = re.sub(u'(\\s*-\\s*){2,}', u' - ', texto)
    texto = re.sub(u'_{2,}', u'_', texto)
    texto = re.sub(u'_\\s*-\\s*|\\s*-\\s*_', u'_', texto)
    texto = texto.strip(u' -_.')
    return limpiar_nombre_archivo(texto)


def nombres_unicos(nombres):
    """Agrega ' (2)', ' (3)'… a los nombres repetidos (sin distinguir mayúsculas)."""
    vistos = {}
    res = []
    for n in nombres:
        clave = n.lower()
        if clave in vistos:
            vistos[clave] += 1
            nuevo = u'%s (%d)' % (n, vistos[clave])
            while nuevo.lower() in vistos:
                vistos[clave] += 1
                nuevo = u'%s (%d)' % (n, vistos[clave])
            vistos[nuevo.lower()] = 1
            res.append(nuevo)
        else:
            vistos[clave] = 1
            res.append(n)
    return res


# ============================================================================ Excel de láminas

# columnas fijas de la hoja LÁMINAS (clave interna, encabezado de la plantilla, alias normalizados)
COLUMNAS = [
    (u'orden', u'N.º', [u'n', u'no', u'nro', u'ndeorden', u'orden']),
    (u'especialidad', u'Especialidad', [u'especialidad', u'codigodeespecialidad', u'disciplina']),
    (u'numero', u'Número de lámina', [u'numerodelamina', u'numero', u'numerodehoja', u'nlamina', u'nodelamina',
                                       u'codigodelamina', u'sheetnumber', u'numerodeplano']),
    (u'nombre', u'Nombre de lámina', [u'nombredelamina', u'nombre', u'nombredehoja', u'titulodelamina',
                                       u'sheetname', u'nombredelplano']),
    (u'rotulo', u'Rótulo (familia : tipo)', [u'rotulofamiliatipo', u'rotulo', u'titleblock']),
    (u'vistas', u'Vistas a colocar', [u'vistasacolocar', u'vistas', u'views']),
    (u'uid', u'Id Revit (no editar)', [u'idrevitnoeditar', u'idrevit', u'uniqueid']),
]

# Un parámetro cuyo nombre coincide con una columna fija (p. ej. «Especialidad» del rótulo) va con este prefijo
PREFIJO_PARAMETRO = u'Parámetro: '


def nombre_parametro(encabezado):
    """'Parámetro: Especialidad' -> 'Especialidad'; None si no es una columna de parámetro con prefijo."""
    texto = _u(encabezado).strip()
    if u':' in texto and normalizar(texto.split(u':', 1)[0]) in (u'parametro', u'param'):
        return texto.split(u':', 1)[1].strip()
    return None


def encabezado_parametro(nombre):
    """Encabezado de la columna de un parámetro: con prefijo si chocaría con una columna fija."""
    return (PREFIJO_PARAMETRO + nombre) if clave_columna(nombre) else nombre


CLAVE_BORRAR = u'(borrar)'

# caracteres que Revit no admite en el número ni en el nombre de una lámina
PROHIBIDOS_NUMERO = u'{}[]|;<>?`~'
PROHIBIDOS_NOMBRE = u'\\:{}[]|;<>?`~'


def caracteres_prohibidos(texto, prohibidos):
    return u''.join(sorted(set(c for c in _u(texto) if c in prohibidos)))


def clave_columna(encabezado):
    n = normalizar(encabezado)
    if not n or nombre_parametro(encabezado) is not None:
        return None
    for clave, _, alias in COLUMNAS:
        if n in [normalizar(a) for a in alias]:
            return clave
    return None


def buscar_hoja(hojas, nombres):
    objetivos = [normalizar(n) for n in nombres]
    for h in hojas:
        if normalizar(h.nombre) in objetivos:
            return h
    return None


class FilaExcel(object):
    def __init__(self, fila):
        self.fila = fila            # número de fila en Excel (base 1)
        self.especialidad = u''
        self.numero = u''
        self.nombre = u''
        self.rotulo = u''
        self.vistas = []
        self.uid = u''
        self.parametros = []        # [(nombre, valor_texto)] en el orden del Excel

    def vacia(self):
        return not (self.numero or self.nombre or self.uid)


def leer_hoja_laminas(hoja, formato_fecha=u'%d/%m/%Y'):
    """Devuelve (filas, columnas_parametro, avisos). Busca la fila de encabezados en las 15 primeras filas."""
    fila_enc = None
    for i, fila in enumerate(hoja.filas[:15]):
        claves = [clave_columna(v) for v in fila if v is not None]
        if u'numero' in claves and u'nombre' in claves:
            fila_enc = i
            break
    if fila_enc is None:
        raise xlsx.ExcelError(u'En la hoja «%s» no se encontraron las columnas «Número de lámina» y «Nombre de '
                              u'lámina». Use la plantilla de PlanosALF (botón «Plantilla Excel»).' % hoja.nombre)
    encabezados = hoja.filas[fila_enc]
    columnas = {}
    parametros = []
    avisos = []
    for c, v in enumerate(encabezados):
        texto = xlsx.valor_a_texto(v)
        if not texto:
            continue
        clave = clave_columna(texto)
        if clave and clave not in columnas:
            columnas[clave] = c
        elif clave:
            avisos.append(u'La columna «%s» está repetida: se usa la primera (para escribir un parámetro con ese '
                          u'nombre, titule la columna «%s%s»).' % (texto, PREFIJO_PARAMETRO, texto))
        else:
            parametros.append((c, nombre_parametro(texto) or texto))
    filas = []
    for i in range(fila_enc + 1, len(hoja.filas)):
        datos = hoja.filas[i]

        def valor(clave):
            c = columnas.get(clave)
            if c is None or c >= len(datos):
                return u''
            return xlsx.valor_a_texto(datos[c], formato_fecha)

        f = FilaExcel(i + 1)
        f.especialidad = valor(u'especialidad')
        f.numero = valor(u'numero')
        f.nombre = valor(u'nombre')
        f.rotulo = valor(u'rotulo')
        f.uid = valor(u'uid')
        vistas = valor(u'vistas')
        f.vistas = [v.strip() for v in re.split(u'[;\\n]', vistas) if v.strip()]
        for c, nombre in parametros:
            if c < len(datos):
                texto = xlsx.valor_a_texto(datos[c], formato_fecha)
                if texto:
                    f.parametros.append((nombre, texto))
        if f.vacia():
            if f.especialidad and not f.numero and not f.nombre:
                continue  # fila de la plantilla solo con la especialidad elegida
            if any(x is not None and xlsx.valor_a_texto(x) for x in datos):
                if f.parametros or f.rotulo or f.vistas:
                    avisos.append(u'Fila %d: tiene datos pero no tiene número ni nombre de lámina; se omite.' % (i + 1))
            continue
        filas.append(f)
    return filas, [n for _, n in parametros], avisos


def leer_hoja_proyecto(hoja, formato_fecha=u'%d/%m/%Y'):
    """Pares (parámetro, valor) de la hoja PROYECTO: columnas «Parámetro» y «Valor» (debajo de su encabezado)."""
    res = []
    if hoja is None:
        return res
    inicio, c_nom, c_val = 0, 0, 1
    for i, fila in enumerate(hoja.filas[:15]):
        claves = [normalizar(xlsx.valor_a_texto(v)) for v in fila]
        if u'parametro' in claves and u'valor' in claves:
            inicio, c_nom, c_val = i + 1, claves.index(u'parametro'), claves.index(u'valor')
            break
    for fila in hoja.filas[inicio:]:
        if not fila or len(fila) <= max(c_nom, c_val):
            continue
        nombre = xlsx.valor_a_texto(fila[c_nom])
        valor = xlsx.valor_a_texto(fila[c_val], formato_fecha)
        if nombre and valor:
            res.append((nombre, valor))
    return res


def leer_hoja_especialidades(hoja):
    if hoja is None:
        return None
    inicio = 0
    for i, fila in enumerate(hoja.filas[:15]):
        if fila and normalizar(xlsx.valor_a_texto(fila[0])) in (u'codigo', u'prefijo'):
            inicio = i + 1
            break
    pares = []
    for fila in hoja.filas[inicio:]:
        if not fila or len(fila) < 2:
            continue
        codigo = xlsx.valor_a_texto(fila[0])
        nombre = xlsx.valor_a_texto(fila[1])
        if re.match(u'^[A-Za-zÑñ]{1,5}$', codigo):
            pares.append((codigo.upper(), nombre or codigo.upper()))
    return pares or None


# ============================================================================ plan de importación

class Accion(object):
    CREAR = u'Crear'
    ACTUALIZAR = u'Actualizar'
    SIN_CAMBIOS = u'Sin cambios'
    ERROR = u'Error'

    def __init__(self, fila):
        self.fila = fila
        self.tipo = Accion.SIN_CAMBIOS
        self.uid = u''
        self.numero_actual = u''
        self.numero = u''
        self.nombre_actual = u''
        self.nombre = u''
        self.especialidad = u''
        self.cambios = []       # textos 'Nombre: A -> B'
        self.errores = []
        self.avisos = []
        self.aplicar = True

    def resumen(self):
        partes = list(self.errores) + list(self.cambios) + list(self.avisos)
        return u' · '.join(partes)


def por_uid_numero_cambia(existente, filas, asignados):
    """¿La fila que tomó esta lámina por su Id le pone otro número? (entonces su número actual queda libre)."""
    fila = asignados.get(existente[u'uid'])
    for f in filas:
        if f.fila == fila and f.uid == existente[u'uid']:
            return bool(f.numero) and f.numero.upper() != _u(existente[u'numero']).upper()
    return False


def planificar(filas, existentes, especialidades, separador=u'-', digitos=2):
    """Plan de creación/actualización.

    filas: [FilaExcel]
    existentes: [dict(uid=, numero=, nombre=)] láminas del modelo
    Devuelve [Accion] en el orden del Excel. Los cambios de parámetros, rótulo y vistas los agrega revit_ops.
    """
    por_uid = dict((e[u'uid'], e) for e in existentes)
    por_numero = {}
    for e in existentes:
        por_numero.setdefault(_u(e[u'numero']).upper(), e)

    acciones = []
    asignados = {}  # uid de lámina existente -> fila que la toma
    # 1) destino de cada fila: primero por Id Revit (reserva esas láminas) y luego por número entre las libres
    destinos = {}
    for f in filas:
        if f.uid and f.uid in por_uid:
            e = por_uid[f.uid]
            if e[u'uid'] in asignados:
                destinos[id(f)] = (None, u'La lámina %s ya la toma la fila %d' % (e[u'numero'], asignados[e[u'uid']]))
            else:
                asignados[e[u'uid']] = f.fila
                destinos[id(f)] = (e, u'')
    for f in filas:
        a = Accion(f)
        a.especialidad = especialidades.codigo_de_texto(f.especialidad) if f.especialidad else u''
        destino, error = destinos.get(id(f), (None, u''))
        if error:
            a.errores.append(error)
            a.tipo = Accion.ERROR
        elif destino is None:
            if f.uid:
                a.avisos.append(u'El Id Revit no existe en este modelo (¿Excel de otro proyecto?): se busca por número')
            if f.numero:
                e = por_numero.get(f.numero.upper())
                if e is not None:
                    if e[u'uid'] in asignados:
                        if asignados[e[u'uid']] != f.fila and por_uid_numero_cambia(e, filas, asignados):
                            e = None  # su lámina actual cambia de número en otra fila: esta fila es nueva
                        else:
                            a.errores.append(u'La lámina %s ya la toma la fila %d' % (e[u'numero'],
                                                                                     asignados[e[u'uid']]))
                            a.tipo = Accion.ERROR
                            e = None
                    else:
                        asignados[e[u'uid']] = f.fila
                    destino = e
        if destino is not None and a.tipo != Accion.ERROR:
            a.uid = destino[u'uid']
            a.numero_actual = destino[u'numero']
            a.nombre_actual = destino[u'nombre']
        acciones.append(a)

    # 1b) filas sin número ni Id Revit: se reconocen por nombre dentro de su especialidad, para que volver a
    #     importar el mismo Excel no duplique las láminas que se numeraron solas la primera vez.
    for a in acciones:
        f = a.fila
        if a.tipo == Accion.ERROR or a.uid or f.numero or not f.nombre or not a.especialidad:
            continue
        clave = normalizar(f.nombre)
        for e in existentes:
            if e[u'uid'] in asignados:
                continue
            if normalizar(e[u'nombre']) == clave and especialidades.de_numero(e[u'numero']) == a.especialidad:
                asignados[e[u'uid']] = f.fila
                a.uid = e[u'uid']
                a.numero_actual = e[u'numero']
                a.nombre_actual = e[u'nombre']
                a.avisos.append(u'Reconocida por su nombre: lámina %s del modelo' % e[u'numero'])
                break

    # 2) números finales
    ocupados = {}  # NUMERO.upper() -> descripción de quién lo ocupa
    for a in acciones:
        if a.tipo == Accion.ERROR:
            continue
        num = a.fila.numero or a.numero_actual
        if num:
            clave = num.upper()
            if clave in ocupados:
                a.errores.append(u'Número repetido: %s ya está en %s' % (num, ocupados[clave]))
                a.tipo = Accion.ERROR
            else:
                ocupados[clave] = u'la fila %d' % a.fila.fila
                a.numero = num
    for e in existentes:
        if e[u'uid'] not in asignados:
            clave = _u(e[u'numero']).upper()
            if clave in ocupados:
                # una fila quiere un número que tiene otra lámina del modelo que no está en el Excel
                for a in acciones:
                    if a.numero.upper() == clave and a.tipo != Accion.ERROR:
                        a.errores.append(u'Ya existe la lámina %s «%s» en el modelo (no está en el Excel)'
                                         % (e[u'numero'], e[u'nombre']))
                        a.tipo = Accion.ERROR
            ocupados.setdefault(clave, u'el modelo')

    # 3) numeración automática (filas sin número): siguiente número libre de su especialidad
    maximos = {}
    for clave in ocupados:
        pref, n, dig = separar_numero(clave, separador)
        if n is not None:
            k = pref.upper()
            maximos[k] = max(maximos.get(k, 0), n)
    for a in acciones:
        if a.tipo == Accion.ERROR or a.numero:
            continue
        if not a.especialidad:
            a.errores.append(u'Sin número de lámina: escriba el número o la especialidad para numerarla sola')
            a.tipo = Accion.ERROR
            continue
        n = maximos.get(a.especialidad, 0) + 1
        nuevo = formatear_numero(a.especialidad, n, digitos, separador)
        while nuevo.upper() in ocupados:
            n += 1
            nuevo = formatear_numero(a.especialidad, n, digitos, separador)
        maximos[a.especialidad] = n
        ocupados[nuevo.upper()] = u'la fila %d' % a.fila.fila
        a.numero = nuevo
        a.avisos.append(u'Número asignado: %s' % nuevo)

    # 4) tipo de acción y cambios de número/nombre
    for a in acciones:
        if a.tipo == Accion.ERROR:
            continue
        malos = caracteres_prohibidos(a.numero, PROHIBIDOS_NUMERO)
        malos_nombre = caracteres_prohibidos(a.fila.nombre, PROHIBIDOS_NOMBRE)
        if malos or malos_nombre:
            if malos:
                a.errores.append(u'El número tiene caracteres que Revit no admite: %s' % u' '.join(malos))
            if malos_nombre:
                a.errores.append(u'El nombre tiene caracteres que Revit no admite: %s' % u' '.join(malos_nombre))
            a.tipo = Accion.ERROR
            continue
        if not a.especialidad:
            a.especialidad = especialidades.de_numero(a.numero)
        elif especialidades.de_numero(a.numero) and especialidades.de_numero(a.numero) != a.especialidad:
            a.avisos.append(u'El número %s no empieza con el código de la especialidad %s' % (a.numero, a.especialidad))
        if not a.uid:
            a.tipo = Accion.CREAR
            a.nombre = a.fila.nombre
            if not a.nombre:
                a.errores.append(u'Falta el nombre de la lámina')
                a.tipo = Accion.ERROR
            continue
        a.nombre = a.fila.nombre or a.nombre_actual
        if a.numero != a.numero_actual:
            a.cambios.append(u'Número: %s → %s' % (a.numero_actual, a.numero))
        if a.nombre != a.nombre_actual:
            a.cambios.append(u'Nombre: «%s» → «%s»' % (a.nombre_actual, a.nombre))
        a.tipo = Accion.ACTUALIZAR if a.cambios else Accion.SIN_CAMBIOS
    return acciones


# ============================================================================ renumeración

def planificar_renumeracion(seleccion, todos, inicio=1, incremento=1, digitos=2, separador=u'-',
                            prefijo=None, especialidades=None):
    """Nuevos números para las láminas seleccionadas (en el orden dado).

    seleccion: [(uid, numero_actual)] en el orden final deseado.
    todos: [(uid, numero)] todas las láminas del modelo.
    prefijo: texto (p. ej. 'IE') para usar uno solo; None = conservar la especialidad de cada lámina y numerar
             cada especialidad por separado desde 'inicio'.
    Devuelve (cambios [(uid, actual, nuevo)], errores [texto]).
    """
    if especialidades is None:
        especialidades = Especialidades()
    contadores = {}
    cambios = []
    for uid, actual in seleccion:
        if prefijo is None:
            pref = especialidades.de_numero(actual)
            if not pref:
                pref, _, _ = separar_numero(actual, separador)
        else:
            pref = _u(prefijo).strip().upper()
        clave = pref.upper()
        n = contadores.get(clave, int(inicio))
        contadores[clave] = n + int(incremento)
        cambios.append((uid, actual, formatear_numero(pref, n, digitos, separador)))
    errores = []
    malos = caracteres_prohibidos(u'%s%s' % (prefijo or u'', separador), PROHIBIDOS_NUMERO)
    if malos:
        errores.append(u'El prefijo o el separador tienen caracteres que Revit no admite: %s' % u' '.join(malos))
    elegidos = set(uid for uid, _ in seleccion)
    otros = dict((_u(num).upper(), num) for uid, num in todos if uid not in elegidos)
    vistos = {}
    for uid, actual, nuevo in cambios:
        clave = nuevo.upper()
        if clave in otros:
            errores.append(u'%s → %s: ese número ya lo tiene otra lámina que no está seleccionada (%s)'
                           % (actual, nuevo, otros[clave]))
        if clave in vistos:
            errores.append(u'%s → %s: número repetido en la selección' % (actual, nuevo))
        vistos[clave] = uid
    return cambios, errores


# ============================================================================ índice de planos

def agrupar_por_especialidad(laminas, especialidades):
    """laminas: [dict(numero=, nombre=, ...)] -> [(codigo, nombre_especialidad, [laminas ordenadas])]."""
    grupos = {}
    for l in laminas:
        cod = especialidades.de_numero(l[u'numero'])
        grupos.setdefault(cod, []).append(l)
    res = []
    for cod in sorted(grupos, key=lambda c: (especialidades.orden(c), c)):
        lista = sorted(grupos[cod], key=lambda l: clave_natural(l[u'numero']))
        res.append((cod, especialidades.nombre(cod) or (u'Láminas %s' % cod if cod else u'Otras láminas'), lista))
    return res
