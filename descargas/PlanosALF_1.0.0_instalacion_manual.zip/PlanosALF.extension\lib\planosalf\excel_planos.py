# -*- coding: utf-8 -*-
"""Libros de Excel de PlanosALF: plantilla / lista de láminas e índice de planos (Times New Roman)."""
from __future__ import print_function, division

import datetime

from planosalf import core, xlsx
from planosalf.xlsx import ESTILOS as E

_u = xlsx._u

FILAS_PLANTILLA = 300
FILA_ENCABEZADO = 3   # base 0 -> fila 4 de Excel

# columnas de parámetros comunes del rótulo (se escriben en los parámetros de lámina de Revit en cualquier idioma)
PARAMETROS_COMUNES = [u'Dibujado por', u'Revisado por', u'Diseñado por', u'Aprobado por', u'Fecha de emisión']

PROYECTO_COMUNES = [
    (u'Nombre del proyecto', u'Nombre completo de la obra o del proyecto'),
    (u'Número del proyecto', u'Código, CUI o número del proyecto'),
    (u'Nombre del cliente', u'Entidad o cliente (p. ej. Municipalidad Provincial de Chota)'),
    (u'Dirección del proyecto', u'Ubicación: localidad, distrito, provincia y departamento'),
    (u'Estado del proyecto', u'Expediente técnico, anteproyecto, replanteo…'),
    (u'Fecha de emisión del proyecto', u'Fecha que aparece en el rótulo'),
    (u'Nombre de la organización', u'Consultor o empresa proyectista'),
    (u'Autor', u'Proyectista responsable'),
]

EJEMPLO = [
    (u'E', u'E-01', u'CIMENTACIÓN', u'Planta de cimentación'),
    (u'E', u'E-02', u'DETALLES DE CIMENTACIÓN', u''),
    (u'E', u'E-03', u'ALIGERADO 1.er PISO', u'Planta de techo 1'),
    (u'E', u'', u'ALIGERADO 2.º PISO', u''),
    (u'IS', u'IS-01', u'AGUA FRÍA Y CALIENTE', u'Nivel 1 - Fontanería'),
    (u'IS', u'IS-02', u'DESAGÜE Y VENTILACIÓN', u'Nivel 1 - Sanitarias'),
    (u'IE', u'IE-01', u'ALUMBRADO', u'Nivel 1 - Iluminación'),
    (u'IE', u'IE-02', u'TOMACORRIENTES', u'Nivel 1 - Electricidad'),
    (u'IE', u'IE-03', u'DIAGRAMA UNIFILAR Y CUADRO DE CARGAS', u'Diagrama unifilar; Cuadro de cargas'),
]


def _encabezado_marca(h, titulo, subtitulo, ultima_col):
    h.altos[0] = 26
    ancho_marca = 2 if ultima_col >= 4 else 1
    h.combinar(0, 0, 0, max(0, ultima_col - ancho_marca), titulo, E[u'titulo'])
    h.combinar(0, ultima_col - ancho_marca + 1, 0, ultima_col, u'PlanosALF · ALF_BIM', E[u'marca'])
    h.combinar(1, 0, 1, ultima_col, subtitulo, E[u'subtitulo'])


def libro_laminas(ruta, especialidades, rotulos=None, vistas=None, laminas=None, info_proyecto=None,
                  parametros_extra=None, nombre_proyecto=u'', rotulo_defecto=u'', subtitulo=None):
    """Plantilla vacía (laminas=None) o lista de las láminas del modelo para editarlas en Excel.

    rotulos: ['Familia : Tipo'];  vistas: [(nombre, tipo)] sin colocar;
    laminas: [dict(especialidad, numero, nombre, rotulo, uid, parametros={nombre: valor})];
    info_proyecto: [(parámetro, valor)];  parametros_extra: nombres de columnas adicionales.
    """
    rotulos = list(rotulos or [])
    vistas = list(vistas or [])
    parametros = list(PARAMETROS_COMUNES)
    for p in parametros_extra or []:
        if core.normalizar(p) not in [core.normalizar(x) for x in parametros]:
            parametros.append(p)

    lb = xlsx.LibroNuevo()
    lb.titulo = u'Láminas — PlanosALF'

    # ------------------------------------------------------------------ LÁMINAS
    h = lb.hoja(u'LÁMINAS')
    h.color_pestana = xlsx.NEGRO
    fijas = [c[1] for c in core.COLUMNAS if c[0] != u'uid']
    encabezados = fijas + [p if p in PARAMETROS_COMUNES else core.encabezado_parametro(p) for p in parametros] + \
        [u'Id Revit (no editar)']
    ultima = len(encabezados) - 1
    if laminas is None:
        sub = (u'Una fila por lámina. Las columnas verdes se escriben en el parámetro del mismo nombre (de la lámina, '
               u'de su rótulo o de la Información del proyecto). Celda vacía = no se cambia; «(borrar)» = se vacía.')
    else:
        sub = (u'Láminas de «%s» exportadas el %s. Edite y vuelva a leer este Excel con «Crear desde Excel». '
               u'No cambie la última columna (Id Revit).' % (nombre_proyecto or u'proyecto',
                                                             datetime.datetime.now().strftime(u'%d/%m/%Y %H:%M')))
    if subtitulo:
        sub = subtitulo
    _encabezado_marca(h, u'LISTA DE LÁMINAS' + (u' — ' + nombre_proyecto if nombre_proyecto else u''), sub, ultima)
    h.altos[1] = 30
    h.escribir(2, 0, u'Gris: datos de la lámina · Verde: parámetros del rótulo · Si el número está vacío, PlanosALF '
                     u'numera solo según la especialidad (E-01, E-02…).', E[u'nota'])
    h.combinar(2, 0, 2, ultima)
    h.altos[2] = 18
    estilos_enc = []
    for i, t in enumerate(encabezados):
        if i < len(fijas):
            estilos_enc.append(E[u'encabezado'])
        elif i == ultima:
            estilos_enc.append(E[u'encabezado_id'])
        else:
            estilos_enc.append(E[u'encabezado_param'])
    h.fila(FILA_ENCABEZADO, encabezados, estilos_enc)
    h.altos[FILA_ENCABEZADO] = 32
    anchos = [6, 14, 16, 46, 30, 34] + [16] * len(parametros) + [12]
    for i, a in enumerate(anchos):
        h.anchos[i] = a
    h.fijar = (FILA_ENCABEZADO + 1, 4)

    datos = laminas if laminas is not None else []
    total = max(FILAS_PLANTILLA, len(datos) + 50)
    for i in range(total):
        f = FILA_ENCABEZADO + 1 + i
        fila = [None] * len(encabezados)
        if i < len(datos):
            l = datos[i]
            fila[0] = i + 1
            fila[1] = l.get(u'especialidad', u'')
            fila[2] = l.get(u'numero', u'')
            fila[3] = l.get(u'nombre', u'')
            fila[4] = l.get(u'rotulo', u'')
            fila[5] = l.get(u'vistas', u'')
            pv = l.get(u'parametros', {})
            for j, p in enumerate(parametros):
                fila[len(fijas) + j] = pv.get(p, u'')
            fila[ultima] = l.get(u'uid', u'')
        estilos = ([E[u'celda_centro'], E[u'celda_centro_texto'], E[u'celda_centro_texto'], E[u'celda_texto'],
                    E[u'celda'], E[u'celda_texto']] + [E[u'celda_texto']] * len(parametros) + [E[u'celda_id']])
        h.fila(f, fila, estilos)
    ult_fila = FILA_ENCABEZADO + total
    h.filtro = u'A%d:%s%d' % (FILA_ENCABEZADO + 1, xlsx.col_letra(ultima), ult_fila)
    h.titulos_impresion = (FILA_ENCABEZADO, FILA_ENCABEZADO)
    n_esp = len(especialidades.pares)
    h.lista(u'B%d:B%d' % (FILA_ENCABEZADO + 2, ult_fila), u'ESPECIALIDADES!$A$5:$A$%d' % (4 + max(n_esp, 1) + 20),
            u'Código de la especialidad (E, IS, IE…). Si deja vacío el número, se numera solo.')
    if rotulos:
        h.lista(u'E%d:E%d' % (FILA_ENCABEZADO + 2, ult_fila), u'MODELO!$A$5:$A$%d' % (4 + len(rotulos)),
                u'Rótulo de las láminas NUEVAS. Vacío = rótulo por defecto.')

    # ------------------------------------------------------------------ PROYECTO
    hp = lb.hoja(u'PROYECTO')
    hp.color_pestana = xlsx.TURQUESA
    _encabezado_marca(hp, u'INFORMACIÓN DEL PROYECTO', u'Se escribe en «Información del proyecto» de Revit (la '
                      u'leen los rótulos de todas las láminas). Celda vacía = no se cambia.', 2)
    hp.fila(3, [u'Parámetro', u'Valor', u'Para qué sirve'], [E[u'encabezado'], E[u'encabezado'], E[u'encabezado']])
    hp.anchos.update({0: 34, 1: 60, 2: 52})
    hp.fijar = (4, 0)
    filas_p = []
    usados = set()
    info = [tuple(x) + (u'',) * (3 - len(x)) for x in (info_proyecto or [])]   # (nombre, valor, clave_bip)
    for nombre, ayuda in PROYECTO_COMUNES:
        clave = core.clave_alias(nombre, core.ALIAS_PROYECTO)
        valor = u''
        for n, v, c in info:
            if (clave and (c == clave or core.clave_alias(n, core.ALIAS_PROYECTO) == clave)) or \
                    core.normalizar(n) == core.normalizar(nombre):
                valor = v
                usados.add(core.normalizar(n))
        filas_p.append((nombre, valor, ayuda))
        usados.add(core.normalizar(nombre))
    for n, v, c in info:
        if core.normalizar(n) not in usados and not (c and c in [core.clave_alias(x, core.ALIAS_PROYECTO)
                                                                  for x, _ in PROYECTO_COMUNES]):
            filas_p.append((n, v, u'Parámetro del proyecto'))
            usados.add(core.normalizar(n))
    if info_proyecto is None:
        for n, ayuda in [(u'Departamento', u'Parámetro de la Información del proyecto (si su plantilla lo tiene)'),
                         (u'Provincia', u'Parámetro de la Información del proyecto (si su plantilla lo tiene)'),
                         (u'Distrito', u'Parámetro de la Información del proyecto (si su plantilla lo tiene)')]:
            filas_p.append((n, u'', ayuda))
    for i, (n, v, ayuda) in enumerate(filas_p + [(u'', u'', u'')] * 10):
        hp.fila(4 + i, [n, v, ayuda], [E[u'celda_negrita'], E[u'celda_texto'], E[u'nota']])

    # ------------------------------------------------------------------ ESPECIALIDADES
    he = lb.hoja(u'ESPECIALIDADES')
    he.color_pestana = xlsx.AZUL
    _encabezado_marca(he, u'ESPECIALIDADES', u'Código (prefijo de la lámina) y nombre. El orden de esta lista es el '
                      u'orden del índice de planos. Puede agregar o cambiar códigos.', 2)
    he.fila(3, [u'Código', u'Especialidad', u'Ejemplo de lámina'], [E[u'encabezado']] * 3)
    he.anchos.update({0: 12, 1: 40, 2: 20})
    he.fijar = (4, 0)
    for i, (c, n) in enumerate(especialidades.pares + [(u'', u'')] * 20):
        he.fila(4 + i, [c, n, core.formatear_numero(c, 1) if c else u''],
                [E[u'celda_centro_texto'], E[u'celda'], E[u'celda_centro']])
    # nota: los códigos van en A5:A… (la lista desplegable de LÁMINAS apunta ahí)

    # ------------------------------------------------------------------ MODELO
    hm = lb.hoja(u'MODELO')
    hm.color_pestana = u'8C8C8C'
    _encabezado_marca(hm, u'DATOS DEL MODELO', u'Rótulos cargados en el modelo y vistas que todavía no están en '
                      u'ninguna lámina. Copie el texto en «Vistas a colocar» (varias separadas por «;»). Si dos vistas se llaman '
                      u'igual, va el tipo entre corchetes: «Nivel 1 [Plano de techo]».', 3)
    hm.fila(3, [u'Rótulos del modelo (familia : tipo)', u'', u'Vistas sin colocar (texto para copiar)', u'Tipo de vista'],
            [E[u'encabezado'], None, E[u'encabezado'], E[u'encabezado']])
    hm.anchos.update({0: 44, 1: 3, 2: 56, 3: 22})
    for i, r in enumerate(rotulos):
        marca = u'  (por defecto)' if r == rotulo_defecto else u''
        hm.escribir(4 + i, 0, r, E[u'celda'])
        if marca:
            hm.escribir(4 + i, 1, u'◄', E[u'ok'])
    if not rotulos:
        hm.escribir(4, 0, u'(abra un modelo con rótulos y vuelva a crear la plantilla)', E[u'nota'])
    repetidas = set()
    vistos_n = set()
    for n, t in vistas:
        if core.normalizar(n) in vistos_n:
            repetidas.add(core.normalizar(n))
        vistos_n.add(core.normalizar(n))
    for i, (n, t) in enumerate(vistas):
        texto = (u'%s [%s]' % (n, t)) if core.normalizar(n) in repetidas else n
        hm.fila(4 + i, [texto, t], [E[u'celda'], E[u'celda']], col_inicio=2)
    hm.fijar = (4, 0)

    # ------------------------------------------------------------------ INSTRUCCIONES
    hi = lb.hoja(u'INSTRUCCIONES')
    hi.cuadricula = False
    hi.anchos.update({0: 4, 1: 110})
    hi.horizontal = False
    hi.escribir(0, 1, u'PlanosALF — cómo usar este Excel', E[u'titulo'])
    hi.altos[0] = 26
    pasos = [
        (u'1. Hoja LÁMINAS', u'Una fila por lámina. Elija la especialidad (E, IS, IE…) y escriba el número (E-01) y el '
         u'nombre (CIMENTACIÓN). Si deja vacío el número, PlanosALF lo asigna solo: el siguiente libre de esa '
         u'especialidad, con el formato de la Configuración (E-01, E-02…).'),
        (u'2. Rótulo', u'Solo para láminas NUEVAS: «Familia : Tipo» tal como aparece en la hoja MODELO. Vacío = el '
         u'rótulo por defecto que elija al importar.'),
        (u'3. Vistas a colocar', u'Nombres de vistas, tablas o leyendas separados por «;». Se colocan ordenadas dentro '
         u'del rótulo (dejando libre la franja del rótulo). Una vista de planta solo puede estar en una lámina.'),
        (u'4. Columnas verdes', u'Cada columna se escribe en el parámetro con ese mismo nombre: primero en la lámina, '
         u'luego en el rótulo (familia de rótulo de la lámina) y al final en la Información del proyecto. Puede agregar '
         u'columnas con los nombres de los parámetros de su rótulo (p. ej. «Escala», «Especialista», «CIP»). '
         u'«Dibujado por», «Revisado por», «Diseñado por», «Aprobado por» y «Fecha de emisión» funcionan con Revit en '
         u'español o en inglés.'),
        (u'5. Celdas vacías', u'Una celda vacía NO cambia el valor actual. Para vaciar un parámetro escriba «(borrar)».'),
        (u'6. Hoja PROYECTO', u'Datos comunes del rótulo (proyecto, entidad, ubicación…). Se escriben una sola vez en '
         u'la Información del proyecto de Revit.'),
        (u'7. Hoja ESPECIALIDADES', u'Códigos y nombres de las especialidades del expediente. Su orden es el del índice '
         u'de planos.'),
        (u'8. Leer el Excel', u'En Revit: pestaña PlanosALF → «Crear desde Excel». Antes de cambiar nada verá una '
         u'vista previa con cada lámina a crear o actualizar, los errores y los avisos. Todo queda en un solo paso de '
         u'«Deshacer».'),
        (u'9. Editar láminas existentes', u'«Láminas a Excel» exporta las láminas del modelo a este mismo formato (con '
         u'la columna Id Revit). Cambie números, nombres o datos del rótulo en Excel y vuelva a leerlo.'),
        (u'Formato', u'Guarde siempre como «Libro de Excel (.xlsx)». Puede tener el Excel abierto mientras lo lee '
         u'PlanosALF, pero los cambios deben estar guardados.'),
    ]
    for i, (t, d) in enumerate(pasos):
        hi.escribir(2 + 2 * i, 1, t, E[u'texto_negrita'])
        hi.escribir(3 + 2 * i, 1, d, E[u'texto'])
        hi.altos[3 + 2 * i] = 32 if len(d) > 110 else 18
    fin = 3 + 2 * len(pasos) + 1
    hi.escribir(fin, 1, u'PlanosALF %s · gratuito · www.alfbim.com · andersonirigoin@gmail.com' % _version(),
                E[u'vinculo'])
    hi.vinculo(fin, 1, u'https://www.alfbim.com')

    # ------------------------------------------------------------------ EJEMPLO
    hx = lb.hoja(u'EJEMPLO')
    hx.color_pestana = u'BFBFBF'
    _encabezado_marca(hx, u'EJEMPLO (no se lee)', u'Así se llena la hoja LÁMINAS. La 4.ª fila no tiene número: '
                      u'PlanosALF le asigna E-04.', 5)
    hx.fila(3, fijas, [E[u'encabezado']] * len(fijas))
    for i, (esp, num, nom, vis) in enumerate(EJEMPLO):
        hx.fila(4 + i, [i + 1, esp, num, nom, u'', vis],
                [E[u'celda_centro'], E[u'celda_centro'], E[u'celda_centro'], E[u'celda'], E[u'celda'],
                 E[u'celda_ajuste']])
    for i, a in enumerate([6, 14, 16, 46, 30, 40]):
        hx.anchos[i] = a

    lb.guardar(ruta)
    return ruta


def _version():
    try:
        from planosalf import config
        return config.VERSION
    except Exception:
        return u''


def libro_indice(ruta, info, grupos, columnas_archivo=None, especialidades=None):
    """Índice de planos.

    info: dict(proyecto=, numero=, cliente=, direccion=, fecha=)
    grupos: [(codigo, nombre_especialidad, [dict(numero, nombre, revision, fecha_revision, archivos={col: nombre})])]
    columnas_archivo: ['PDF', 'DWG'] (opcional)
    """
    columnas_archivo = list(columnas_archivo or [])
    lb = xlsx.LibroNuevo()
    lb.titulo = u'Índice de planos'
    h = lb.hoja(u'ÍNDICE DE PLANOS')
    h.horizontal = bool(columnas_archivo)
    h.cuadricula = False
    enc = [u'N.º', u'Lámina', u'Nombre de la lámina', u'Revisión', u'Fecha de revisión'] + \
          [u'Archivo %s' % c for c in columnas_archivo]
    ultima = len(enc) - 1
    h.altos[0] = 26
    h.combinar(0, 0, 0, ultima, u'ÍNDICE DE PLANOS', xlsx.Estilo(negrita=True, tamano=16, borde=False,
                                                                  horizontal=u'center'))
    fila = 1
    for etiqueta, clave in [(u'Proyecto', u'proyecto'), (u'Código', u'numero'), (u'Entidad / cliente', u'cliente'),
                            (u'Ubicación', u'direccion')]:
        valor = _u(info.get(clave, u''))
        if valor:
            h.combinar(fila, 0, fila, 1, etiqueta + u':', xlsx.Estilo(negrita=True, borde=False, horizontal=u'left'))
            h.combinar(fila, 2, fila, ultima, valor, xlsx.Estilo(borde=False, ajustar=True))
            if len(valor) > 90:
                h.altos[fila] = 30
            fila += 1
    h.combinar(fila, 0, fila, 1, u'Fecha:', xlsx.Estilo(negrita=True, borde=False, horizontal=u'left'))
    h.combinar(fila, 2, fila, ultima, _u(info.get(u'fecha', datetime.datetime.now().strftime(u'%d/%m/%Y'))),
               xlsx.Estilo(borde=False, horizontal=u'left'))
    fila += 2
    fila_enc = fila
    h.fila(fila, enc, E[u'encabezado'])
    h.altos[fila] = 22
    fila += 1
    n = 0
    for codigo, nombre_esp, laminas in grupos:
        titulo = (u'%s (%s)' % (nombre_esp.upper(), codigo)) if codigo else nombre_esp.upper()
        titulo += u' — %d lámina%s' % (len(laminas), u'' if len(laminas) == 1 else u's')
        h.combinar(fila, 0, fila, ultima, titulo, E[u'grupo'])
        fila += 1
        for l in laminas:
            n += 1
            valores = [n, l.get(u'numero', u''), l.get(u'nombre', u''), l.get(u'revision', u''),
                       l.get(u'fecha_revision', u'')]
            arch = l.get(u'archivos', {})
            valores += [arch.get(c, u'') for c in columnas_archivo]
            estilos = [E[u'celda_centro'], E[u'celda_centro'], E[u'celda_ajuste'], E[u'celda_centro'],
                       E[u'celda_centro']] + [E[u'celda']] * len(columnas_archivo)
            h.fila(fila, valores, estilos)
            fila += 1
    h.combinar(fila, 0, fila, 2, u'Total: %d lámina%s' % (n, u'' if n == 1 else u's'),
               xlsx.Estilo(negrita=True, horizontal=u'right'))
    for c in range(3, ultima + 1):
        h.escribir(fila, c, None, xlsx.Estilo())
    fila += 2
    h.escribir(fila, 0, u'Generado con PlanosALF (gratuito) — www.alfbim.com',
               xlsx.Estilo(cursiva=True, tamano=9, color=u'7F7F7F', borde=False))
    anchos = [6, 12, 56, 10, 14] + [30] * len(columnas_archivo)
    for i, a in enumerate(anchos):
        h.anchos[i] = a
    h.titulos_impresion = (fila_enc, fila_enc)
    lb.guardar(ruta)
    return ruta
