# -*- coding: utf-8 -*-
"""Comandos de la pestaña PlanosALF (cada botón llama a una función de este módulo)."""
from __future__ import print_function, division

import datetime
import os
import traceback

from Autodesk.Revit import DB
from pyrevit import forms, revit, script

from planosalf import config, core, excel_planos, revit_ops, ui, xlsx

_u = xlsx._u
TITULO = u'PlanosALF'


# ============================================================================ utilidades

def documento(obligatorio=True):
    try:
        doc = revit.doc
    except Exception:
        doc = None
    if doc is not None and doc.IsFamilyDocument:
        if obligatorio:
            forms.alert(u'Abra un modelo de proyecto (no una familia).', title=TITULO, exitscript=True)
        return None
    if doc is None and obligatorio:
        forms.alert(u'Abra un modelo de Revit primero.', title=TITULO, exitscript=True)
    return doc


def ejecutar(funcion):
    """Ejecuta un comando mostrando los errores de forma clara."""
    try:
        funcion()
    except SystemExit:
        raise
    except (xlsx.ExcelError, revit_ops.ErrorPlanos) as ex:
        forms.alert(_u(ex), title=TITULO)
    except revit_ops.Cancelado:
        forms.alert(u'Cancelado. No se cambió nada en el modelo.', title=TITULO, warn_icon=False)
    except Exception as ex:
        registrar_error()
        out = salida(u'PlanosALF — error')
        out.print_md(u'## Ocurrió un error inesperado')
        out.print_md(u'Nada quedó a medias: los cambios en el modelo se deshacen cuando hay un error. '
                     u'Envíe esta ventana a **%s** para corregirlo.' % config.CORREO)
        out.print_code(_u(traceback.format_exc()))
        detalle = _u(traceback.format_exc())
        try:
            forms.alert(u'Ocurrió un error inesperado:\n\n%s' % _u(ex), title=TITULO,
                        sub_msg=u'Despliegue «Detalle» y envíelo a %s.' % config.CORREO, expanded=detalle[-3000:])
        except TypeError:
            forms.alert(u'Ocurrió un error inesperado:\n\n%s\n\n%s' % (_u(ex), detalle[-1500:]), title=TITULO)


def registrar_error():
    """Guarda el último error en %APPDATA%\\ALF_BIM\\PlanosALF (y junto a la extensión en modo desarrollo)."""
    import io
    texto = u'%s\nPlanosALF %s\n%s' % (datetime.datetime.now().isoformat(), config.VERSION,
                                       _u(traceback.format_exc()))
    rutas = [os.path.join(config.carpeta_usuario(), u'ultimo_error.txt')]
    raiz = os.path.dirname(config.CARPETA_EXT)
    if os.path.isfile(os.path.join(raiz, u'_DEV')):
        rutas.append(os.path.join(raiz, u'_ultimo_error.txt'))
    for r in rutas:
        try:
            with io.open(r, 'w', encoding='utf-8') as f:
                f.write(texto)
        except Exception:
            pass


def guardar_como(nombre, carpeta=u'', titulo=u'Guardar Excel'):
    try:
        return forms.save_file(file_ext='xlsx', default_name=nombre, init_dir=carpeta or u'', title=titulo)
    except TypeError:
        return forms.save_file(file_ext='xlsx', default_name=nombre, init_dir=carpeta or u'')


def elegir_excel(carpeta=u''):
    try:
        return forms.pick_file(file_ext='xlsx', init_dir=carpeta or u'', title=u'Elija el Excel de láminas')
    except TypeError:
        return forms.pick_file(file_ext='xlsx', init_dir=carpeta or u'')


def carpeta_modelo(doc):
    try:
        if doc is not None and doc.PathName and os.path.isdir(os.path.dirname(doc.PathName)):
            return _u(os.path.dirname(doc.PathName))
    except Exception:
        pass
    return config.carpeta_documentos()


def nombre_modelo(doc):
    try:
        return _u(doc.Title).replace(u'.rvt', u'')
    except Exception:
        return u'proyecto'


def preguntar_abrir(ruta, mensaje):
    if forms.alert(mensaje + u'\n\n%s\n\n¿Abrirlo ahora?' % ruta, title=TITULO, yes=True, no=True, warn_icon=False):
        ui.abrir(ruta)


def seleccion_laminas(doc):
    """UniqueId de las láminas seleccionadas en el Navegador de proyectos."""
    res = set()
    try:
        for eid in revit.uidoc.Selection.GetElementIds():
            el = doc.GetElement(eid)
            if isinstance(el, DB.ViewSheet):
                res.add(_u(el.UniqueId))
    except Exception:
        pass
    return res


def salida(titulo):
    """Ventana de resultados de pyRevit con la letra de la marca (Times New Roman)."""
    out = script.get_output()
    out.set_title(titulo)
    try:
        out.add_style(u'body, p, li, td, th, h1, h2, h3 { font-family: "Times New Roman", serif !important; }')
    except Exception:
        pass
    return out


def enlace(out, lamina, texto=None):
    try:
        return out.linkify(lamina.Id, title=texto or _u(lamina.SheetNumber))
    except Exception:
        return texto or _u(lamina.SheetNumber)


# ============================================================================ plantilla y láminas a Excel

def plantilla_excel():
    doc = documento(obligatorio=False)
    cfg = config.cargar()
    esp = cfg.especialidades()
    rotulos, vistas, info = [], [], None
    if doc is not None:
        rotulos = [t for t, _ in revit_ops.rotulos(doc)]
        en_laminas = revit_ops.vistas_en_laminas(doc)
        for v, tipo in revit_ops.vistas_colocables(doc):
            multiple = revit_ops.vista_multiple(v)
            if multiple or revit_ops.eid_int(v.Id) not in en_laminas:
                vistas.append((_u(v.Name), tipo))
        info = revit_ops.info_proyecto(doc)
    ruta = guardar_como(u'Plantilla_Laminas_PlanosALF.xlsx', carpeta_modelo(doc) if doc else u'',
                        u'Guardar la plantilla de láminas')
    if not ruta:
        return
    excel_planos.libro_laminas(ruta, esp, rotulos=rotulos, vistas=vistas, info_proyecto=info,
                               rotulo_defecto=cfg.get(u'rotulo_defecto', u''),
                               nombre_proyecto=revit_ops.info_para_indice(doc)[u'proyecto'] if doc else u'')
    cfg[u'ultimo_excel'] = ruta
    cfg.guardar()
    extra = u'' if doc else u'\n(Sin modelo abierto: las listas de rótulos y vistas van vacías.)'
    preguntar_abrir(ruta, u'Plantilla creada.' + extra)


def laminas_a_excel():
    doc = documento()
    cfg = config.cargar()
    esp = cfg.especialidades()
    datos, extra = revit_ops.datos_laminas(doc, esp)
    if not datos:
        forms.alert(u'El modelo no tiene láminas. Use «Plantilla Excel» para empezar.', title=TITULO)
        return
    nombre = core.limpiar_nombre_archivo(u'Laminas - %s' % nombre_modelo(doc)) + u'.xlsx'
    ruta = guardar_como(nombre, carpeta_modelo(doc), u'Guardar las láminas en Excel')
    if not ruta:
        return
    rotulos = [t for t, _ in revit_ops.rotulos(doc)]
    en_laminas = revit_ops.vistas_en_laminas(doc)
    vistas = []
    for v, tipo in revit_ops.vistas_colocables(doc):
        multiple = revit_ops.vista_multiple(v)
        if multiple or revit_ops.eid_int(v.Id) not in en_laminas:
            vistas.append((_u(v.Name), tipo))
    excel_planos.libro_laminas(ruta, esp, rotulos=rotulos, vistas=vistas, laminas=datos, parametros_extra=extra,
                               info_proyecto=revit_ops.info_proyecto(doc), nombre_proyecto=nombre_modelo(doc),
                               rotulo_defecto=cfg.get(u'rotulo_defecto', u''))
    cfg[u'ultimo_excel'] = ruta
    cfg.guardar()
    preguntar_abrir(ruta, u'%d lámina(s) exportadas a Excel.' % len(datos))


# ============================================================================ crear desde Excel

def crear_desde_excel():
    doc = documento()
    cfg = config.cargar()
    ultimo = _u(cfg.get(u'ultimo_excel') or u'')
    ruta = elegir_excel(os.path.dirname(ultimo) if ultimo else carpeta_modelo(doc))
    if not ruta:
        return
    hojas = xlsx.leer_libro(ruta)
    hoja = core.buscar_hoja(hojas, [u'LÁMINAS', u'LAMINAS', u'Láminas', u'Hojas', u'Planos', u'Lista de láminas'])
    if hoja is None:
        for h in hojas:
            try:
                core.leer_hoja_laminas(h)
                hoja = h
                break
            except xlsx.ExcelError:
                continue
    if hoja is None:
        raise xlsx.ExcelError(u'No se encontró una hoja con las columnas «Número de lámina» y «Nombre de lámina».\n\n'
                              u'Use el botón «Plantilla Excel» para crear el formato.')
    fmt = cfg.get(u'formato_fecha') or u'%d/%m/%Y'
    filas, columnas_param, avisos_excel = core.leer_hoja_laminas(hoja, fmt)
    pares_esp = core.leer_hoja_especialidades(core.buscar_hoja(hojas, [u'ESPECIALIDADES']))
    esp = core.Especialidades(pares_esp) if pares_esp else cfg.especialidades()
    proyecto = core.leer_hoja_proyecto(core.buscar_hoja(hojas, [u'PROYECTO']), fmt)
    if not filas and not proyecto:
        forms.alert(u'El Excel no tiene láminas ni datos del proyecto para leer.\n\nHoja leída: %s' % hoja.nombre,
                    title=TITULO)
        return

    existentes = [dict(uid=_u(s.UniqueId), numero=_u(s.SheetNumber), nombre=_u(s.Name))
                  for s in revit_ops.laminas(doc)]
    acciones = core.planificar(filas, existentes, esp, _u(cfg.get(u'separador', u'-')), int(cfg.get(u'digitos', 2)))
    rotulos = revit_ops.rotulos(doc)
    revit_ops.detallar(doc, acciones, rotulos, revit_ops.vistas_colocables(doc), revit_ops.vistas_en_laminas(doc))
    # datos del proyecto que realmente cambian
    proyecto_cambia = []
    for nombre, valor in proyecto:
        p = revit_ops.param_de_proyecto(doc, nombre)
        if p is None:
            avisos_excel.append(u'PROYECTO: no existe el parámetro «%s» en la Información del proyecto.' % nombre)
        elif not revit_ops.mismo_valor(p, valor):
            proyecto_cambia.append((nombre, valor))

    v = ui.VentanaImportar(ruta, acciones, [t for t, _ in rotulos], _u(cfg.get(u'rotulo_defecto') or u''),
                           len(proyecto_cambia), avisos_excel, cfg)
    v.ShowDialog()
    if not v.resultado:
        return
    r = v.resultado
    simbolo = None
    if r[u'rotulo']:
        simbolo, _ = revit_ops.buscar_rotulo(rotulos, r[u'rotulo'])
    opciones = dict(crear=r[u'crear'], actualizar=r[u'actualizar'], vistas=r[u'vistas'], rotulo_defecto=simbolo,
                    franja_pct=float(cfg.get(u'franja_rotulo_pct', 20.0)), margen_pct=float(cfg.get(u'margen_pct', 3.0)),
                    proyecto=proyecto_cambia if r[u'proyecto'] else [])
    total = len([a for a in acciones if a.aplicar and ((a.tipo == core.Accion.CREAR and r[u'crear']) or
                                                        (a.tipo == core.Accion.ACTUALIZAR and r[u'actualizar']))])
    with forms.ProgressBar(title=u'PlanosALF: láminas ({value} de {max_value})', cancellable=True) as pb:
        def progreso(i, n):
            pb.update_progress(i, max(1, n))
            return pb.cancelled
        resultados, avisos_proyecto = revit_ops.aplicar_plan(doc, acciones, opciones, progreso)
        cancelado = pb.cancelled

    cfg[u'ultimo_excel'] = ruta
    cfg[u'crear_nuevas'] = r[u'crear']
    cfg[u'actualizar'] = r[u'actualizar']
    cfg[u'colocar_vistas'] = r[u'vistas']
    cfg[u'info_proyecto'] = r[u'proyecto']
    if r[u'rotulo']:
        cfg[u'rotulo_defecto'] = r[u'rotulo']
    cfg.guardar()

    # informe
    out = salida(u'PlanosALF — láminas desde Excel')
    creadas = [x for x in resultados if x[0].tipo == core.Accion.CREAR and not x[3]]
    actualizadas = [x for x in resultados if x[0].tipo == core.Accion.ACTUALIZAR and not x[3]]
    errores = [x for x in resultados if x[3]]
    out.print_md(u'## PlanosALF · láminas desde Excel')
    out.print_md(u'**Excel:** %s' % ruta)
    out.print_md(u'**%d creada(s) · %d actualizada(s) · %d con error**%s' % (
        len(creadas), len(actualizadas), len(errores), u' · *cancelado por el usuario*' if cancelado else u''))
    if r[u'proyecto'] and proyecto_cambia:
        out.print_md(u'Información del proyecto: %d dato(s) escritos.' % (len(proyecto_cambia) - len(avisos_proyecto)))
    filas_tabla = []
    for a, lam, avisos, error in resultados:
        filas_tabla.append([_u(a.fila.fila), a.tipo if not error else u'Error',
                            enlace(out, lam) if lam is not None and not error else a.numero, a.nombre,
                            error or u'; '.join(avisos)])
    if filas_tabla:
        out.print_table(table_data=filas_tabla, columns=[u'Fila', u'Acción', u'Lámina', u'Nombre', u'Observaciones'])
    if avisos_proyecto:
        out.print_md(u'**Información del proyecto:**')
        for t in avisos_proyecto:
            out.print_md(u'- ' + t)
    no_aplicadas = [a for a in acciones if a.tipo == core.Accion.ERROR]
    if no_aplicadas:
        out.print_md(u'**Filas del Excel con error (no se aplicaron):**')
        for a in no_aplicadas:
            out.print_md(u'- Fila %d: %s' % (a.fila.fila, u'; '.join(a.errores)))
    if total and not resultados and not cancelado:
        out.print_md(u'No se aplicó ninguna lámina.')
    out.print_md(u'---\n*PlanosALF %s · gratuito · www.alfbim.com*' % config.VERSION)


# ============================================================================ renumerar

def renumerar():
    doc = documento()
    cfg = config.cargar()
    esp = cfg.especialidades()
    hojas = revit_ops.laminas(doc)
    if not hojas:
        forms.alert(u'El modelo no tiene láminas.', title=TITULO)
        return
    marcadas = seleccion_laminas(doc)
    items = [dict(uid=_u(s.UniqueId), numero=_u(s.SheetNumber),
                  nombre=_u(s.Name) + (u'  (marcador)' if s.IsPlaceholder else u''), sel=_u(s.UniqueId) in marcadas)
             for s in hojas]
    todos = [(i[u'uid'], i[u'numero']) for i in items]
    v = ui.VentanaRenumerar(items, todos, cfg)
    v.ShowDialog()
    if not v.resultado:
        return
    r = v.resultado
    hechos, errores, avisos = revit_ops.renumerar(doc, r[u'cambios'], r[u'param_total'], esp)
    a = r[u'ajustes']
    cfg[u'renum_inicio'] = a[u'inicio']
    cfg[u'renum_incremento'] = a[u'incremento']
    cfg[u'renum_param_total'] = r[u'param_total']
    cfg.guardar()
    if errores or avisos:
        out = salida(u'PlanosALF — renumerar')
        if errores:
            out.print_md(u'## Renumerar: no se cambió ninguna lámina')
            out.print_md(u'Para no dejar números a medias, PlanosALF no aplica nada si una lámina falla:')
        else:
            out.print_md(u'## Renumerar: %d lámina(s) renumeradas' % hechos)
        for e in errores + avisos:
            out.print_md(u'- ' + e)
    else:
        forms.alert(u'%d lámina(s) renumeradas.' % hechos, title=TITULO, warn_icon=False)


# ============================================================================ exportar

def exportar():
    doc = documento()
    cfg = config.cargar()
    esp = cfg.especialidades()
    hojas = [s for s in revit_ops.laminas(doc, incluir_marcadores=False)]
    if not hojas:
        forms.alert(u'El modelo no tiene láminas para exportar.', title=TITULO)
        return
    marcadas = seleccion_laminas(doc)
    items = []
    for s in hojas:
        datos = revit_ops.datos_patron(doc, s, esp)
        items.append(dict(uid=_u(s.UniqueId), numero=_u(s.SheetNumber), nombre=_u(s.Name), codigo=datos[u'Codigo'],
                          revision=datos[u'Revision'], datos_patron=datos,
                          sel=(_u(s.UniqueId) in marcadas) if marcadas else True))
    items.sort(key=lambda i: (esp.orden(i[u'codigo']), core.clave_natural(i[u'numero'])))
    carpeta_def = os.path.join(carpeta_modelo(doc), u'Planos PDF-DWG')
    v = ui.VentanaExportar(items, revit_ops.configuraciones_dwg(doc), cfg, carpeta_def)
    v.ShowDialog()
    if not v.resultado:
        return
    cfg.guardar()
    por_uid = dict((_u(s.UniqueId), s) for s in hojas)
    elegidos = [i for i in items if i[u'uid'] in set(v.resultado[u'uids'])]
    carpeta = _u(cfg[u'carpeta_exportacion'])

    def subcarpeta(codigo):
        if not cfg.get(u'subcarpetas') or not codigo:
            return u''
        return core.limpiar_nombre_archivo(u'%s - %s' % (codigo, esp.nombre(codigo) or u'Láminas'))

    # nombres únicos por carpeta
    nombres = {}
    por_carpeta = {}
    for i in elegidos:
        por_carpeta.setdefault(subcarpeta(i[u'codigo']), []).append(i)
    for sub, lista in por_carpeta.items():
        unicos = core.nombres_unicos([core.aplicar_patron(cfg[u'patron_archivo'], i[u'datos_patron']) for i in lista])
        for i, n in zip(lista, unicos):
            nombres[i[u'uid']] = n

    tareas = []   # (tipo, [items], carpeta_relativa, nombre)
    if cfg.get(u'pdf'):
        modo = cfg.get(u'modo_pdf')
        if modo == u'especialidad':
            grupos = []
            for i in elegidos:
                if not grupos or grupos[-1][0] != i[u'codigo']:
                    grupos.append((i[u'codigo'], []))
                grupos[-1][1].append(i)
            for cod, lista in grupos:
                n = core.limpiar_nombre_archivo((u'%s - %s' % (cod, esp.nombre(cod))) if cod else u'Otras láminas')
                tareas.append((u'PDF', lista, subcarpeta(cod), n))
        elif modo == u'uno':
            proyecto = revit_ops.info_para_indice(doc)[u'proyecto'] or nombre_modelo(doc)
            tareas.append((u'PDF', elegidos, u'', core.limpiar_nombre_archivo(u'Planos - %s' % proyecto, 120)))
        else:
            for i in elegidos:
                tareas.append((u'PDF', [i], subcarpeta(i[u'codigo']), nombres[i[u'uid']]))
    if cfg.get(u'dwg'):
        for i in elegidos:
            tareas.append((u'DWG', [i], subcarpeta(i[u'codigo']), nombres[i[u'uid']]))

    archivos = {}   # uid -> {PDF: ruta relativa, DWG: ...}
    errores = []
    hechos = []
    cancelado = False
    opc_pdf = revit_ops.opciones_pdf(cfg) if cfg.get(u'pdf') else None
    opc_dwg = revit_ops.opciones_dwg(doc, cfg) if cfg.get(u'dwg') else None
    inicio = datetime.datetime.now()
    if tareas:
        with forms.ProgressBar(title=u'PlanosALF: exportando ({value} de {max_value})', cancellable=True) as pb:
            for k, (tipo, lista, sub, nombre) in enumerate(tareas):
                if pb.cancelled:
                    cancelado = True
                    break
                pb.update_progress(k, len(tareas))
                destino = os.path.join(carpeta, sub) if sub else carpeta
                try:
                    if tipo == u'PDF':
                        ruta = revit_ops.exportar_pdf(doc, [por_uid[i[u'uid']].Id for i in lista], destino, nombre,
                                                      opc_pdf, cfg.get(u'sobrescribir', True))
                    else:
                        ruta = revit_ops.exportar_dwg(doc, por_uid[lista[0][u'uid']].Id, destino, nombre, opc_dwg,
                                                      cfg.get(u'sobrescribir', True))
                    rel = os.path.relpath(ruta, carpeta)
                    hechos.append((tipo, rel, lista))
                    for i in lista:
                        archivos.setdefault(i[u'uid'], {})[tipo] = rel
                except Exception as ex:
                    errores.append((tipo, nombre, _u(ex)))
            pb.update_progress(len(tareas), len(tareas))

    ruta_indice = u''
    if cfg.get(u'indice_excel'):
        datos = revit_ops.datos_indice(doc, [por_uid[i[u'uid']] for i in elegidos])
        for d in datos:
            d[u'archivos'] = archivos.get(d[u'uid'], {})
        columnas = [t for t in (u'PDF', u'DWG') if cfg.get(t.lower())]
        info = revit_ops.info_para_indice(doc)
        info[u'fecha'] = datetime.date.today().strftime(u'%d/%m/%Y')
        ruta_indice = os.path.join(carpeta, u'Índice de planos.xlsx')
        try:
            excel_planos.libro_indice(ruta_indice, info, core.agrupar_por_especialidad(datos, esp), columnas, esp)
        except xlsx.ExcelError as ex:
            errores.append((u'Índice', u'Índice de planos.xlsx', _u(ex)))
            ruta_indice = u''

    segundos = (datetime.datetime.now() - inicio).total_seconds()
    out = salida(u'PlanosALF — exportar')
    out.print_md(u'## PlanosALF · exportación de láminas')
    out.print_md(u'**Carpeta:** %s' % carpeta)
    n_pdf = len([h for h in hechos if h[0] == u'PDF'])
    n_dwg = len([h for h in hechos if h[0] == u'DWG'])
    out.print_md(u'**%d PDF · %d DWG · %d error(es)** · %d lámina(s) · %.0f s%s' % (
        n_pdf, n_dwg, len(errores), len(elegidos), segundos, u' · *cancelado*' if cancelado else u''))
    if ruta_indice:
        out.print_md(u'Índice de planos: %s' % ruta_indice)
    if errores:
        out.print_table(table_data=[[t, n, e] for t, n, e in errores], columns=[u'Formato', u'Archivo', u'Error'],
                        title=u'Errores')
    if hechos:
        out.print_table(table_data=[[t, r, u', '.join(i[u'numero'] for i in l)] for t, r, l in hechos],
                        columns=[u'Formato', u'Archivo', u'Láminas'])
    out.print_md(u'---\n*PlanosALF %s · gratuito · www.alfbim.com*' % config.VERSION)
    if cfg.get(u'abrir_carpeta') and (hechos or ruta_indice):
        ui.abrir(carpeta)


# ============================================================================ índice de planos

def indice_planos():
    doc = documento()
    cfg = config.cargar()
    esp = cfg.especialidades()
    hojas = []
    b = revit_ops.bip(u'SHEET_SCHEDULED')
    for s in revit_ops.laminas(doc, incluir_marcadores=True):
        p = s.get_Parameter(b) if b is not None else None
        if p is not None and p.AsInteger() == 0:
            continue  # «Aparece en la lista de planos» desactivado
        hojas.append(s)
    if not hojas:
        forms.alert(u'El modelo no tiene láminas.', title=TITULO)
        return
    nombre = core.limpiar_nombre_archivo(u'Indice de planos - %s' % nombre_modelo(doc)) + u'.xlsx'
    ruta = guardar_como(nombre, carpeta_modelo(doc), u'Guardar el índice de planos')
    if not ruta:
        return
    info = revit_ops.info_para_indice(doc)
    info[u'fecha'] = datetime.date.today().strftime(u'%d/%m/%Y')
    datos = revit_ops.datos_indice(doc, hojas)
    excel_planos.libro_indice(ruta, info, core.agrupar_por_especialidad(datos, esp), None, esp)
    preguntar_abrir(ruta, u'Índice de planos creado con %d lámina(s).' % len(datos))


# ============================================================================ configuración y ayuda

def configuracion():
    doc = documento(obligatorio=False)
    cfg = config.cargar()
    rotulos = [t for t, _ in revit_ops.rotulos(doc)] if doc is not None else []
    v = ui.VentanaConfig(cfg, rotulos)
    v.ShowDialog()


def ayuda():
    if not ui.abrir_manual():
        forms.alert(u'No se pudo abrir el manual. Visite %s' % config.WEB, title=TITULO)


def acerca():
    ui.VentanaAcerca().ShowDialog()
