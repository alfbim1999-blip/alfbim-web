# -*- coding: utf-8 -*-
"""PlanosALF — Configuración."""
import os
import sys

# En modo desarrollo (archivo _DEV junto a la extensión) se recarga siempre el código de lib\planosalf
_raiz = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
if os.path.isfile(os.path.join(_raiz, '_DEV')):
    for _m in [k for k in list(sys.modules) if k == 'planosalf' or k.startswith('planosalf.')]:
        del sys.modules[_m]

from planosalf import comandos  # noqa: E402

comandos.ejecutar(comandos.configuracion)
