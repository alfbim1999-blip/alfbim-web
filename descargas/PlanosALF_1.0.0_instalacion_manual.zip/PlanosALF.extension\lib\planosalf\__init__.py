# -*- coding: utf-8 -*-
"""PlanosALF — láminas en lote para Revit (ALF-04 de la línea ALF_BIM).

Crea láminas desde Excel, llena los rótulos, renumera y exporta en lote a PDF/DWG con nombres estandarizados.
© 2026 Ing. Anderson Irigoín C. — ALF_BIM · www.alfbim.com
"""
__version__ = '1.0.0'
